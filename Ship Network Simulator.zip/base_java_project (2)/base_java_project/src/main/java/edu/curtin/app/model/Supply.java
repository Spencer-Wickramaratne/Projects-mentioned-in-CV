package edu.curtin.app.model;
//carries data for cargo requests receieved froom Scenario
public class Supply 
{
    private final Cargo cargo;
    private final String originId;
    private final String destinationId;

    public Supply(int size, String type, String originId, String destinationId) {
        this.cargo = new Cargo(size, type);
        this.originId = originId;
        this.destinationId = destinationId;}

   //helper emthod to get the name fo the cargo being requested
    public String getType() {
        return cargo.getType();
    }

    public Cargo getCargo() { return cargo; }
    //returns the ID of the port where the cargo should be piccked up
    public String getOriginId() { return originId; 
    }

    //returns the ID ofthe port the cargo should be delievered
    public String getDestinationId() { return destinationId; }
}
