package edu.curtin.app.operate;

import edu.curtin.app.Scenario;
import edu.curtin.app.model.*;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

//main apsect of the simulation and contorls the timing and coordinantes between the Scenario(input) class and LakeActivty(logic) class 

public class SceneSimulator {
    private static final Logger logger = Logger.getLogger(SceneSimulator.class.getName());

    private final Scenario scenario;
    private final LakeActivity model;
    private final MessageParseFactory factory;
     
    /*constructor uses dependency injection to receive required compnonents to ensure this class isnt tihgtly coupled to certian implementations */
    public SceneSimulator(Scenario scenario, LakeActivity model, MessageParseFactory factory) {
        this.scenario = scenario;
        this.model = model;
        this.factory = factory;
    }

     /*execution loop that rusn the simulation hour by hour and processes all the pending messages frm Scenario and tirggers the model
     update(progress()) and pauses fro  second simulating 1 hour */
    public void run() {
        try {
            /*loop until user rpesses enter */
            while (System.in.available() == 0) {
                String msg;

                /*fetch every message fro the current  siulation hour */
                while ((msg = scenario.nextMessage()) != null) {
                    //  log all received messages to journal
                    model.notifyObservers("SCENARIO MSG: " + msg);
                    //use the facotry to translate string into model changes
                    factory.process(msg, model); }

                model.progress();

                try {
                    //control simualtion speed 1 second = 1 hour
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    return;
        }
            }
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Input error occurred", e);
        }
    }
}