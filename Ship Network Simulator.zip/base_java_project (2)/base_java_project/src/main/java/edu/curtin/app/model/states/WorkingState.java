package edu.curtin.app.model.states;

import edu.curtin.app.model.Ship;

// handles the 5 hour loading/unloadng process at the port
public class WorkingState implements ShipStateInterface { 
    private int hoursRemaining = 5; 
    private final boolean loading; 
    private final ShipStateInterface nextState; 
    private String cargoType = "None"; // Store the cargo name

    public WorkingState(boolean loading, ShipStateInterface nextState, Ship ship) { 
        this.loading = loading; 
        this.nextState = nextState; 
        
        // capture the cargo type immediately upon entering this state
        if (ship.getCargo() != null) {
            this.cargoType = ship.getCargo().getType();
        }
    } 
    @Override 
    public String getStateName() { 
        return "WorkingState"; 
    }



    public boolean isLoading() {
        return loading;
    }

    public String getCargoType() {
        return cargoType;
    }

    @Override 
    public void update(Ship ship)
     { 
        //decreemnt the timer each simulation hour
        hoursRemaining--; 
        if (hoursRemaining <= 0) { 
            // If  unloading, the cargo is removed
            if (!loading) {
                ship.setCargo(null); 
            }
            ship.setState(nextState); 
        } 
    } 



    @Override 
    public String getDescription() {  
        return (loading ? "Loading" : "Unloading") + " (" + hoursRemaining + "h left)";  
    } 
}