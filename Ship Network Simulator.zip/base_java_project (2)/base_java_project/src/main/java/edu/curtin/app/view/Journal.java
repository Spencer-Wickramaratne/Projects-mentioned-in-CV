package edu.curtin.app.view;

import edu.curtin.app.model.*;
 import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;

//an observer that records all simulation events to the test file journal.txt
public class Journal implements SimObserverInterface 
{
    private static final String FILE_NAME = "journal.txt";
    private static final Logger logger = Logger.getLogger(Journal.class.getName());

    //wipes an old file when new simuation starts
    public Journal() 
    {
        // initialize file (overwrite previous session)
        try (PrintWriter out = new PrintWriter(new FileWriter(FILE_NAME, false))) {
            out.println("** Simulation Started **");
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Error initializing journal file", e);
        }
    }

    @Override
    public void update(int hour, String message) {
        // formats and logs all simulation events and scenario messages
        log("[" + hour + "h] " + message);
    }

    @Override
      public void refreshDisplay(int hour, LakeActivity model) {
        // Acts as a timeunit separator in the journal
        log("--- Hour: " + hour + " ---"); }

    private void log(String line) 
    {
        // append mode + immediate flush for real time compliance
        try (PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(FILE_NAME, true)))) {
            out.println(line);
            out.flush(); // ensure the data is written to disk imemediately
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Error writing to journal file", e);
        }
    }
}