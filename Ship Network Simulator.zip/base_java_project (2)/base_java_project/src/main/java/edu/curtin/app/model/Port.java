package edu.curtin.app.model;

//represents a port which is a fixed geographical location on the lake
public class Port
 {
    private final String id;
    private final int x, y;

    public Port(String id, int x, int y) {
        this.id = id;
        this.x = x;
        this.y = y;
    }
    public String getId() { return id; }//used as a key in hashmaps in LakeAcitvity for faster lookupss
     public int getX() { return x; }
    public int getY() { return y; }
}
