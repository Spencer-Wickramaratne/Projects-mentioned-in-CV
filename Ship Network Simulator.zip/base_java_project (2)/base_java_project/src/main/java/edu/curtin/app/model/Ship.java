package edu.curtin.app.model;

import edu.curtin.app.model.states.*;

//represents a ship entity in the simulation
public class Ship {
    private final int id;
    private int x, y;
    private int seaWorthiness = 4;
    private ShipStateInterface state = new IdleState();
    private ShipStateInterface previousState = null; // To reseume after repair missions
    private Cargo currentCargo = null;

    public Ship(int id, int x, int y) {
        this.id = id;
        this.x = x;
        this.y = y;
    }
    //delegate the update logic to the currenrt state object which is the core of the state pattern
    public void update() {
        state.update(this);
    }

    public void setState(ShipStateInterface newState) {
        this.state = newState;
    }
    public boolean isAvailable() {//check fr available ships
        boolean isIdle = state instanceof IdleState;
         boolean isBusyMoving = false;
        
        if (state instanceof MovingState) {
            MovingState ms = (MovingState) state;
            if (!(ms.getNextState() instanceof IdleState)) {
                isBusyMoving = true;}
        }
        
        // eligible if idle or moving but not busy with a active suppply chain also if seaworthy
        return (isIdle || (state instanceof MovingState && !isBusyMoving)) && seaWorthiness > 1;
} 

    // getters and setters
    public int getId() { return id; }
    public int getX() { return x; }
     public int getY() { return y; }
     public void setX(int x) { this.x = x; }
    public void setY(int y) { this.y = y; }
     public int getSeaWorthiness() { return seaWorthiness; }
    public void setSeaWorthiness(int s) { this.seaWorthiness = s; }
    public ShipStateInterface getState() { return state; }
    public Cargo getCargo() { return currentCargo; }
    public void setCargo(Cargo c) { this.currentCargo = c; }
     public void saveState() { this.previousState = state; }
    public void resumeState() { 
        if (previousState != null) {
            this.state = previousState; 
        }
    }
}