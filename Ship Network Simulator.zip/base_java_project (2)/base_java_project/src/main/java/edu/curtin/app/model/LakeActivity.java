package edu.curtin.app.model;
import edu.curtin.app.model.states.*;
import edu.curtin.app.generic.LakeGrid;
import java.util.*;
// Core of the Lake simulation and holds data of ships,ports,storms and rules of the lake
public class LakeActivity 
{
     private final int width, height;
    private final Map<String, Port> ports = new HashMap<>();
     private final LakeGrid<Port> portGrid; 
     private final List<Ship> ships = new ArrayList<>();
    private final Set<Storm> storms = new HashSet<>();
     private final List<SimObserverInterface> observers = new ArrayList<>();
    private final ShipFactory shipFactory;
    private int currentHour = 0;
    // Counter used to genertae unique IDs for replacement ships sequentially
    private int nextShipId = 100;
    //trackers tod etect changes between hours for logging
     private final Map<String, Port> previousPorts = new HashMap<>();
    private final Map<String, String> previousStates = new HashMap<>();
    //sets up the simulation environment and dependency injection is used for ShipFactory
    public LakeActivity(int w, int h, ShipFactory shipFactory)
     {
        this.width = w;
        this.height = h;
        this.shipFactory = shipFactory;
        this.portGrid = new LakeGrid<>(w, h);
    }
    //returns port at a specifc coordinate using LakeGrid utility
    public Port getPortAt(int x, int y) {
        return portGrid.get(x, y); }
    //regitsers a port in a map for ID lookup and a grid for coordinate llookup
    public void addPort(Port p) { 
        ports.put(p.getId(), p); 
        portGrid.set(p.getX(), p.getY(), p); 
    }
   
    // logic to process sea worthiness,movement and notifyingg
   public void progress() 
   {List<Ship> newShipsToAdd = new ArrayList<>();
    
    // 1)sea worthiness and storm phase
    for (int i = ships.size() - 1; i >= 0; i--)
     {
        Ship s = ships.get(i);
        String shipId = String.valueOf(s.getId());
        Port currentPort = getPortAt(s.getX(), s.getY());
        
        //shipss are safe in ports and SW resets to 4
        if (currentPort != null) {
            s.setSeaWorthiness(4); 
        } 
        else 
        {   //check if ship is in active storm zones
            for (Storm storm : storms) {
                if (storm.isInStorm(s.getX(), s.getY())) 
                {
                    s.setSeaWorthiness(s.getSeaWorthiness() - 1);
                    String result = (s.getSeaWorthiness() > 1) ? "Status: Operational" : "Status: Critical";
                    notifyObservers("Ship " + shipId + " hit by storm! SW: " + s.getSeaWorthiness() + " (" + result + ")"); }
            }
        }
        //handles sinking where SW=0  and disablling where SW =1 and emergency retunr where SW= 2 or 3
        if (s.getSeaWorthiness() <= 0)
         {
            String cargoType = (s.getCargo() != null) ? s.getCargo().getType() : "None";
            notifyObservers("Ship " + shipId + " has SUNK! (Lost Cargo: " + cargoType + ")");

            for (Ship other : ships)
            {
                ShipStateInterface state = other.getState();
                // check if ship is currrnetly repairing
                if (state instanceof RepairingState) {
                    RepairingState rs = (RepairingState) state;
                    if (rs.getTargetShip().equals(s)) {
                        // abandoned mission notification
                        notifyObservers("Ship " + other.getId() + " abandoned repair mission (Target Sunk)");
                        other.resumeState(); }
                }
                // Check if ship is moving to repair 
                else if (state instanceof MovingState) {
                    MovingState ms = (MovingState) state;
                    if (ms.getNextState() instanceof RepairingState) {
                        RepairingState rs = (RepairingState) ms.getNextState();
                        if (rs.getTargetShip().equals(s)) {
                            notifyObservers("Ship " + other.getId() + " abandoned repair mission (Target Sunk)");
                            other.resumeState(); // go back to what it was doing before
                        }}
                }
            }
            ships.remove(i);
            handleShipReplacement(newShipsToAdd);//replace sunk ships
            previousPorts.remove(shipId);
            previousStates.remove(shipId);
        } 
        else if (s.getSeaWorthiness() == 1 && !(s.getState() instanceof DisabledState))
       {
            s.setState(new DisabledState());
            notifyObservers("Ship " + shipId + " is DISABLED at (" + s.getX() + "," + s.getY() + ")");
            requestRescue(s);//trigger a rescue mission
        } 
        else if ((s.getSeaWorthiness() == 2 || s.getSeaWorthiness() == 3) && s.getState() instanceof IdleState && currentPort == null) 
        {//low SW ships return to port automaticaly
            moveToSafety(s);}
    }

    // 2)movement and observer refresh phase
    for (Ship s : ships)
     {
        String shipId = String.valueOf(s.getId());
         ShipStateInterface prevState = s.getState();
        String prevStateName = (prevState != null) ? prevState.getStateName() : "";

        s.update(); //trigeer state behaviour
        ShipStateInterface currentState = s.getState();
         String currentStateName = (currentState != null) ? currentState.getStateName() : "";

        // completed repair misison notification
        if ("RepairingState".equals(prevStateName) && !"RepairingState".equals(currentStateName)) {
            notifyObservers("Ship " + shipId + " completed repair mission");
        }
        previousStates.put(shipId, currentStateName);
        
        //deteect and log arrival and departure from ports
        Port currentPort = getPortAt(s.getX(), s.getY());
        Port prevPort = previousPorts.get(shipId);

        if (prevPort != null && currentPort != null && !prevPort.getId().equals(currentPort.getId())) 
        {
            notifyObservers("Ship " + shipId + " departed from Port " + prevPort.getId());
            logArrival(s, currentPort);
            previousPorts.put(shipId, currentPort);
        } 
        else if (prevPort == null && currentPort != null) 
        {
            logArrival(s, currentPort);
            previousPorts.put(shipId, currentPort);} 
        else if (prevPort != null && currentPort == null) 
         {
            notifyObservers("Ship " + shipId + " departed from Port " + prevPort.getId());
            previousPorts.remove(shipId); }
    }

    for (Ship newShip : newShipsToAdd) {
        ships.add(newShip); }
    for (SimObserverInterface o : observers) { 
        o.refreshDisplay(currentHour, this);  }
    storms.clear();//clear storms at the end of the hour
    currentHour++;
}
    //formats a detailed log message when a sip touches a port
    private void logArrival(Ship s, Port p) {
    String cargo = "None";
    String action = "neither";

    // check the if ship is currently in a WorkingState (loading orr unloading)
    if (s.getState() instanceof WorkingState) 
    {
        WorkingState ws = (WorkingState) s.getState();
        action = ws.isLoading() ? "loading" : "unloading";
        // use the cargo type preserved insidde the state
        cargo = ws.getCargoType();
    } 
    //  if the ship has cargo but isn't in WorkingState yet
    if (cargo.equals("None") && s.getCargo() != null)
     {
        cargo = s.getCargo().getType();}
    notifyObservers(String.format("Ship %d arrived at Port %s, Action: %s, Cargo: %s", s.getId(), p.getId(), action, cargo));
}
    //forces low SW ship to seek nearest port
    private void moveToSafety(Ship s) {
        Port safety = null;
        if (!ports.isEmpty()) 
        { safety = ports.values().iterator().next();}
        if (safety != null) 
        {
            notifyObservers("Ship " + s.getId() + " health low (" + s.getSeaWorthiness() + "). Returning to port.");
            s.setState(new MovingState(safety.getX(), safety.getY(), new IdleState()));}
    }
    //assigns supply miision to avaulable ship and filters out idle ships
  public void handleSupplyRequest(Supply supply) {
    Ship available = null;
    boolean found = false;
    
    // find an eligibele ship
   for (int i = 0; i < ships.size() && !found; i++) {
        Ship s = ships.get(i);
        if (s.isAvailable()) {
            available = s;
            found = true; }
    }

    //  process the request
    if (available == null) {
        notifyObservers("Supply request for " + supply.getCargo().getType() + " ignored: No ships available.");
    } else {
        Port origin = ports.get(supply.getOriginId());
        Port dest = ports.get(supply.getDestinationId());
        if (origin != null && dest != null) 
        {
            // first set the cargo on the ship so WorkingState can captrue the type
            available.setCargo(supply.getCargo());
            notifyObservers("Ship " + available.getId() + " assigned to supply request. Moving to Port " + origin.getId());
            
            // passing available as the 3rd argument to both WorkingState constructors
            available.setState(new MovingState(origin.getX(), origin.getY(),// state 1: mmove to origin
            new WorkingState(true,// state 2: load at origin
              new MovingState(dest.getX(), dest.getY(),// state 3: move to sestination
            new WorkingState(false, new IdleState(), available)),  available)));// state 4: ulnload  then go Idle
        } 
        else {
            notifyObservers("Supply request for " + supply.getCargo().getType() + " ignored: Invalid Port IDs (" + supply.getOriginId() + " to " + supply.getDestinationId() + ")");}
    }
}
   //diverst healthy ship to rescue disabled one
    private void requestRescue(Ship disabled) {
    Ship rescuer = null;
    boolean found = false;
    for (Ship s : ships) {
        if (!found && !s.equals(disabled)) {
            boolean isDisabled = s.getState() instanceof DisabledState;
            boolean isRepairing = s.getState() instanceof RepairingState;
            boolean isMovingToRepair = false;
            if (s.getState() instanceof MovingState) {
                MovingState ms = (MovingState) s.getState();
                if (ms.getNextState() instanceof RepairingState)
                 {
                    isMovingToRepair = true;}
            }
            if (!isDisabled && !isRepairing && !isMovingToRepair) {
                rescuer = s;
                found = true;}
        }
    }

    if (rescuer != null) {
        notifyObservers("Ship " + rescuer.getId() + " diverted to rescue Ship " + disabled.getId());
        rescuer.saveState(); 
        Port safety = null;
        if (!ports.isEmpty()) {
            safety = ports.values().iterator().next();
        }
        if (safety != null) {
            rescuer.setState(new MovingState(disabled.getX(), disabled.getY(),new RepairingState(disabled, safety, rescuer.getState())));}
    }
}
    //replace sunk ships at a port
    private void handleShipReplacement(List<Ship> toAdd) {
        Port p = null;
        if (!ports.isEmpty()) {
            p = ports.values().iterator().next();
        }
        if (p != null) {
            int uniqueId = nextShipId++;
            Ship newShip = shipFactory.createShip(uniqueId, p.getX(), p.getY());
            toAdd.add(newShip);
            notifyObservers("Replacement ship " + newShip.getId() + " constructed at Port " + p.getId());
        }
    }
    public void addObserver(SimObserverInterface o) { observers.add(o); }
    public void notifyObservers(String msg) { 
        for (SimObserverInterface o : observers) {
            o.update(currentHour, msg);} }
    public void addShip(Ship s) { ships.add(s); }
   public void addStorm(Storm s) {storms.add(s);  }
    public int getWidth() { return width; }
     public int getHeight() { return height; }
     public Collection<Port> getPorts() { return ports.values(); }
    public List<Ship> getShips() { return ships; }
    public Set<Storm> getStorms() { return storms; }
}