package edu.curtin.app.model.states;

import edu.curtin.app.model.Ship;

// Represents a ship that is currently doing nothing and waiting for commands. 
  
public class IdleState implements ShipStateInterface { 
    @Override 
    public void update(Ship ship) { 
        // dooes nothing just sits at current coordinates. 
    } 

    @Override 
    public String getDescription() 
    {  
        return "IDLE";  
    } 
     @Override 
    public String getStateName() { return "IdleState"; }
}