package edu.curtin.app.model.states;

import edu.curtin.app.model.Ship;

// represents ship trvaelling towards specicfic coordinates
public class MovingState implements ShipStateInterface 
{ 
    private int targetX, targetY; 
    private final ShipStateInterface nextState; 

    //a nextState is entred to enable a chain of states
    public MovingState(int tx, int ty, ShipStateInterface nextState) 
    { 
        this.targetX = tx; 
        this.targetY = ty; 
        this.nextState = nextState; 
    } 

    // providese access to the state the ship will enter upon arrival
    public ShipStateInterface getNextState() {
        return nextState;
    }
     @Override 
    public String getStateName() 
    { 
        return "MovingState";
     }

    @Override 
    public void update(Ship ship) 
    { 
        int curX = ship.getX(); 
        int curY = ship.getY(); 

        //if arrived immendiatwly transiton to the next scheduled behaviour
        if (curX == targetX && curY == targetY) 
        { 
            ship.setState(nextState);
            return; 
        } 

        // move 1 step in any direction (horizontal, vertical or diagonal)
        if (curX < targetX) { 
            curX++; 
        } else if (curX > targetX) 
        { 
            curX--; 
        } 

        if (curY < targetY)     
        { 
            curY++; 
        } else if (curY > targetY)
        { 
            curY--; 
        } 
         
        ship.setX(curX); 
        ship.setY(curY); 
        
        //douuble check if this step resulted in arrival
        if (curX == targetX && curY == targetY)
        { 
            ship.setState(nextState);
        } 
    } 

    @Override 
    public String getDescription() 
    { 
        String desc = "Moving to (" + targetX + "," + targetY + ")";
        if (nextState instanceof RepairingState)   
        {
            desc += " for Repair Mission"; 
        }
        return desc;


    }
}