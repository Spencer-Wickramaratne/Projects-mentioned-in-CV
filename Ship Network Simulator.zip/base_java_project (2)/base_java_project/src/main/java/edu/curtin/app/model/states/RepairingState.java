package edu.curtin.app.model.states;

import edu.curtin.app.model.Ship;
import edu.curtin.app.model.Port;

//represents  a ship performing a rescue or repair on another ship
public class RepairingState implements ShipStateInterface
 { 
    private final Ship disabledShip; 
    private final Port safetyPort;
    private final ShipStateInterface nextState; 

    //tracks the target ship and next state so rescuer can resume its previous task afte repair is done
    public RepairingState(Ship disabledShip, Port safetyPort, ShipStateInterface nextState) 
    
    { 
        this.disabledShip = disabledShip; 
        this.safetyPort = safetyPort;
        this.nextState = nextState; 
    } 

    public Ship getTargetShip() {
        return disabledShip;
    }

    @Override 
    public void update(Ship ship)
     { 
        // Upon arriving the disabled ship is immediately repaired to a rating of 3.
        disabledShip.setSeaWorthiness(3); 
        
        // Move the rescued ship to a port so it resumes movement
        if (safetyPort != null) 
        {
            disabledShip.setState(new MovingState(
                safetyPort.getX(), 
                safetyPort.getY(), 
                new IdleState()
            ));
        }

        // The rescuer resumes whatever it was doing before the rescue (saved in nextState)
        ship.setState(nextState);
    } 

    @Override 
    public String getDescription() { 
        return "Repairing Ship " + disabledShip.getId(); 
    } 
     @Override 
    public String getStateName() { 
        return "RepairingState"; 
    }
}