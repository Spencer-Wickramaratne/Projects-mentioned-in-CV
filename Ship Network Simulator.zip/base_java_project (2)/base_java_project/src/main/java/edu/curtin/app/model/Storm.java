package edu.curtin.app.model;
import java.util.Objects;

//defines a circular area that damages the ships as in a storm
public class Storm 
{
    private final int x, y, radius;

    public Storm(int x, int y, int radius) {
        this.x = x;
        this.y = y;
        this.radius = radius;
    }
    //check to see if a point is within the storm's circle using the formula (x−x1)^2+(y−y1)^2 <=r^2.
    public boolean isInStorm(int x1, int y1) {
        return Math.pow(x - x1, 2) + Math.pow(y - y1, 2) <= Math.pow(radius, 2);
    }

    @Override
    public boolean equals(Object o){
     boolean isEqual = false;

        // are they the exact same reference?
        if (this == o) {
            isEqual = true;
        } 
        //  is the other objcet actually an instance of Storm?
        else if (o instanceof Storm) {
            Storm storm = (Storm) o;
            // ccompare all  fields
            isEqual = (x == storm.x && y == storm.y && radius == storm.radius);
        }
        return isEqual;
  }

    @Override
    public int hashCode() {
        // required when overriding equals so HashSet work correctly
        return Objects.hash(x, y, radius);
    }
}
