package edu.curtin.app.model;

/*interface for the observer pattern and allows LakeActivity to talk to  the veiw(Dsiplay) and log(Journal)
wihtout eactly knowing what they are */

public interface SimObserverInterface {
    //triggered when a specific event occurs
    void update(int hour, String message);

    /*triggered once per simulation step to redraw the entire state and passes the full LakeActivity
    so observer can iterate through all ships and ports to create a visual representation*/
    void refreshDisplay(int hour, LakeActivity model);
}
