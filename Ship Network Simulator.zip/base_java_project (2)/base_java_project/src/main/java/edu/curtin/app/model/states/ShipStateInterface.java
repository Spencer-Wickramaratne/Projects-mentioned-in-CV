package edu.curtin.app.model.states;

import edu.curtin.app.model.Ship;

// common interface for all ship behaviourss and enables state pattern
public interface ShipStateInterface {
    //defines what a ship does during a simulation step
    void update(Ship ship);

    //retunrs a human readable name for the current state for logging
    String getDescription();
    // rreturns class identifier name for logging tracking
    String getStateName();
}
