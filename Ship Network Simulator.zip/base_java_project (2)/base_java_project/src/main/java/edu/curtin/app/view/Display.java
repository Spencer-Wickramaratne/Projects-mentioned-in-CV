package edu.curtin.app.view;

import edu.curtin.app.model.*;

// an observer that renders the simulation intot he terminal
public class Display implements SimObserverInterface {
    @Override
    public void update(int hour, String message) 
    {}//visual display doesnt need to log every message

     /*draws a test based map of the lake and iterates thorigh the grid printing sysmbols for water(~~)
    and storms(!!) and ports by their IDs and ships*/
    @Override
    public void refreshDisplay(int hour, LakeActivity model) 
    {
        // ANSI clear Screen
        System.out.print("\033[2J\033[H"); 
        System.out.println("Hour: " + hour);

        for (int y = 0; y < model.getHeight(); y++) {
            for (int x = 0; x < model.getWidth(); x++)
            {
                String point = "~~ ";
                
                boolean isStorm = false;
                for(Storm storm : model.getStorms()) {
                    if(!isStorm && storm.isInStorm(x, y)) {
                        isStorm = true;}
                }

                if (isStorm) {
                    point = "\033[31m!! \033[m"; // red storm marks
                }

                Port p = model.getPortAt(x, y);
                if (p != null) {
                    point = String.format("%-3s", p.getId()); }

                for (Ship s : model.getShips())
                {
                    if (s.getX() == x && s.getY() == y) {
                        // iif ship is in a storm show ID with red background
                        if (isStorm) {
                            point = String.format("\033[41m%-3d\033[m", s.getId());
                        } 
                        else {
                            point = String.format("%-3d", s.getId());}
                    }
                }
                System.out.print(point);
            }
            System.out.println();
        }
    }
}