package edu.curtin.app.model.states;

import edu.curtin.app.model.Ship;

// represents ship with sea worthiness 1 and that cannot move on its own

public class DisabledState implements ShipStateInterface { 
    @Override 
    public void update(Ship ship) { 
        // cant move waiting for rescue 
    } 
    
    @Override 
    public String getDescription() { 
        return "DISABLED"; 
    } 
    @Override 
    public String getStateName() { return "DisabledState"; }
}