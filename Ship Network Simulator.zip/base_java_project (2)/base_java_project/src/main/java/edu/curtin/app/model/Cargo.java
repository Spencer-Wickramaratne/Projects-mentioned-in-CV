package edu.curtin.app.model;
//represents the goods a ship carries
public class Cargo 
{
    private final int size;
    private final String type;

    public Cargo(int size, String type) {
        this.size = size;
        this.type = type;
    }
    public int getSize() { return size; }
    public String getType() { return type; }
}
