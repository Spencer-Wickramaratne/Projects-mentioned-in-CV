package edu.curtin.app.model;

import java.util.logging.Level;
import java.util.logging.Logger;

/*decouples the raw Scenario strings from the LakeAcitvity and implements facotory pattern to parse
and exceucte Scenario commands */
public class MessageParseFactory 
{
    private static final Logger logger = Logger.getLogger(MessageParseFactory.class.getName());

    public void process(String msg, LakeActivity model) {
        if (msg == null) {
            return;
        }
        String[] parts = msg.split(" ");
        try {
            switch (parts[0]) {
                case "port":
                    model.addPort(new Port(parts[1], Integer.parseInt(parts[2]), Integer.parseInt(parts[3])));
                    break;
                case "ship":
                    model.addShip(new Ship(Integer.parseInt(parts[1]), Integer.parseInt(parts[2]), Integer.parseInt(parts[3])));
                    break;
                case "supply":
                    model.handleSupplyRequest(new Supply(Integer.parseInt(parts[1]), parts[2], parts[3], parts[4]));
                    break;
                case "storm":
                    model.addStorm(new Storm(Integer.parseInt(parts[1]), Integer.parseInt(parts[2]), Integer.parseInt(parts[3])));
                    break;
                default:
                    model.notifyObservers("Invalid message: " + msg);
            }
        } catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
            logger.log(Level.WARNING, () -> "Failed to parse message: " + msg);
            model.notifyObservers("Malformed message ignored: " + msg);
        }
    }
}