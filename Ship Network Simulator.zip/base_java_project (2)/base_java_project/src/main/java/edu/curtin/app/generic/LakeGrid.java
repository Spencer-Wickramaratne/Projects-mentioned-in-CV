package edu.curtin.app.generic;

import java.util.ArrayList;
import java.util.List;

/* Generic grid utility for the lake  and used to store static objects like Ports at specific coordinates.*/
public class LakeGrid<T> 
{
    private List<List<T>> grid;
    private int width;
    private int height;

    /*initliases a nested arraylist structure and useingn a generic type <T> allows the grifi to reused for anything*/
    public LakeGrid(int width, int height) 
    {
        this.width = width;
        this.height = height;
        this.grid = new ArrayList<>(height);
        
        //populate the grid with null values initlally
        for(int i = 0; i < height; i++) 
        {
            List<T> row = new ArrayList<>(width);
            for(int j = 0; j < width; j++) 
            {
                row.add(null);
            }
            grid.add(row);
        }
    }

    //places an obejct at aspecific coordinate
    public void set(int x, int y, T value) 
    {
        if (x >= 0 && x < width && y >= 0 && y < height) 
        {
            grid.get(y).set(x, value);
        }
    }
    //retrives an obejct from a specific coordinate
    public T get(int x, int y) 
    {
        T result = null;
        if (x >= 0 && x < width && y >= 0 && y < height) 
        {
            result = grid.get(y).get(x);
        }
        return result;
    }
    
    //getters fro grid dimensions
    public int getWidth() { return width; }
    public int getHeight() { return height; }
}