package edu.curtin.app;

import edu.curtin.app.model.ShipFactory;
import edu.curtin.app.operate.SceneSimulator;
import edu.curtin.app.model.*;
import edu.curtin.app.view.*;

public class App {
    /*the  main entry point for the simulation of the lake */

    public static void main(String[] args)
     {
         // initialse the data source
        Scenario scenario = new Scenario();
        
        // initialse the factory which ddecouples the model from specific instantiation logidc of ships
         ShipFactory shipFactory = new ShipFactory();
        
        // initalise the mdoel where dimensions and the factory are passed via the constructor(Dependenncy injection)
        LakeActivity model = new LakeActivity(scenario.getWidth(), scenario.getHeight(), shipFactory);
        
        // initlaise the observers which allows muitliple vuews (terminall and file) to react to mdoel changes.
        model.addObserver(new Display());
        model.addObserver(new Journal());
        
        // initlaise th controller and MessageParseFacory handles raw string form Scenario and turning them into mdoel actions
        MessageParseFactory factory = new MessageParseFactory();
        SceneSimulator scene = new SceneSimulator(scenario, model, factory);
        
        System.out.println("Simulation running and press ENTER to stop.");
        scene.run();
    }
}