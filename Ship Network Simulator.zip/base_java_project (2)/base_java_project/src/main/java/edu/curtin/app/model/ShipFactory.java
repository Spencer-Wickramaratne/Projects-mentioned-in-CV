package edu.curtin.app.model;

/*implements the facotry pattern for ship objects and this decouples LakeActivity from the specific ship
constructor in the event of diffferent types of ships are made*/

public class ShipFactory {
    //useful fro when the simualtion needs to create replacement ships
    public Ship createShip(int id, int x, int y) {
        return new Ship(id, x, y);
    }
}