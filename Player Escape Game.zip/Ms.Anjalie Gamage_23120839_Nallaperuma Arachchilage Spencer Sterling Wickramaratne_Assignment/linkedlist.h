/* linkedlist.h */
#ifndef LINKEDLIST_H
#define LINKEDLIST_H

#include "map_data.h" 

/* Function pointer for freeing the data stored in a node */
typedef void (*FreeDataFunc)(void *data);

/* Initialize a new linked list */
LinkedList *list_create(void);

/* Add a new node to the head of the list (stack behavior for UNDO) */
void list_push(LinkedList *list, void *data);

/* Remove and return the data from the head of the list */
void *list_pop(LinkedList *list);

/* Check if the list is empty */
int list_is_empty( LinkedList *list);

/* Free all nodes and their data in the list */
void list_destroy(LinkedList *list, FreeDataFunc free_func);

#endif /* LINKEDLIST_H */
