/* game.c */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "game.h"
#include "terminal.h"/*uses the already implemented code in the supplementary video as permitted with slight changes*/
#include "newSleep.h" /*uses the already implemented code in the supplementary video as permitted*/
#include "color.h" /*uses the already implemented code in the supplementary video as permitted*/

/* Helper Functions(marked as static to maintain encapsulation)*/

/* Helper to map integer from file to character on map  */
static char int_to_char(int val) {
    char result = CHAR_EMPTY;
    switch (val) {
        case 0: result = CHAR_EMPTY; break;
        case 1: result = CHAR_WALL; break;
        case 2: result = CHAR_WATER; break;
        case 3: result = CHAR_TRAPDOOR; break;
        case 4: result = CHAR_TRAP; break;
        case 5: result = CHAR_PLAYER; break;
        case 6: result = CHAR_GOAL; break;
    }
    return result;
}

/* Custom helper to free only the map array (used by game_destroy and free_record_data) */
static void game_destroy_map(char **map, int rows, int cols) {
    int i;
    /* Use 'cols' parameter to suppress the -Wunused-parameter warning */
    (void)cols; 
    if (map) {
        /* Rows includes the top and bottom border (+2) */
        for (i = 0; i < rows + 2; i++) {
            free(map[i]);
        }
        free(map);
    }
}

/* Creates a deep copy of the map for the UNDO feature (Single Return) */
static char **deep_copy_map( char **original_map, int rows, int cols) {
    char **copy = NULL;
    int i;
    int j;
    int map_rows = rows + 2;
    int map_cols = cols + 2;
    int success = 0; 
    
    copy = (char **)malloc(map_rows * sizeof(char *));
    if (copy) {
        success = 1;
        for (i = 0; i < map_rows && success; i++) {
            copy[i] = (char *)malloc(map_cols * sizeof(char));
            if (!copy[i]) {
                perror("Failed to allocate copy map columns");
                /* Cleanup previous allocations */
                for (j = 0; j < i; j++) {
                    free(copy[j]);
                }
                free(copy);
                copy = NULL; 
                success = 0;
            } else {
                /* Copy the whole row, including borders */
                memcpy(copy[i], original_map[i], map_cols * sizeof(char));
            }
        }
    } else {
        perror("Failed to allocate copy map rows");
    }
    
    return copy;
}

/* Frees the GameRecord data (the deep copy of the map). Correctly uses stored rows/cols. */
void free_record_data(void *data) {
    GameRecord *record = (GameRecord *)data; 

    if (record) {
        /* Use the stored dimensions for safe cleanup */
        if (record->prev_map_state) {
            /* Uses record->rows and record->cols */
            game_destroy_map(record->prev_map_state, record->rows, record->cols);
        }
        free(record);
    }
}

/* Helper to remove all trapdoors after the trap is triggered */
static void game_remove_trapdoors(GameState *state) {
    int r;
    int c;
    for (r = 1; r <= state->rows; r++) {
        for (c = 1; c <= state->cols; c++) {
            if (state->map[r][c] == CHAR_TRAPDOOR) {
                state->map[r][c] = CHAR_EMPTY;
            }
        }
    }
}

/* --- Game State Management --- */

/* Allocates and initializes GameState (Single Return) */
GameState *game_init( char *filename) {
    GameState *state = NULL;
    
    state = (GameState *)malloc(sizeof(GameState));
    if (state) {
        /* Initialize all pointers/values */
        state->map = NULL;
        state->rows = 0;
        state->cols = 0;
        state->player_r = 0;
        state->player_c = 0;
        state->trap_set_off = 0;
        state->game_over = 0;

        if (game_load_map(filename, state) == 0) {
            /* Loading failed, clean up the allocated state struct */
            free(state);
            state = NULL;
        }
    } else {
        perror("Failed to allocate GameState");
    }
    
    return state;
}

/* Frees all memory allocated within the GameState struct */
void game_destroy(GameState *state) {
    if (state) {
        if (state->map) {
            /* Use helper to free map, passing current dimensions */
            game_destroy_map(state->map, state->rows, state->cols);
        }
        /* Free the GameState structure itself */
        free(state);
    }
}

/* Loads the map from the text file and allocates the map array (Single Return) */
int game_load_map( char *filename, GameState *state) {
    FILE *file = NULL;
    int temp_rows, temp_cols;
    int i, j, value;
    int r, c;
    int success = 0;
    
    file = fopen(filename, "r");
    if (!file) {
        perror(filename);
    } else if (fscanf(file, "%d %d", &temp_rows, &temp_cols) != 2) {
        perror("Error: Map file format invalid (missing dimensions)");
    } else {
        state->rows = temp_rows;
        state->cols = temp_cols;
        
        /* Allocate the map: +2 for the border rows/columns */
        state->map = (char **)malloc((state->rows + 2) * sizeof(char *));
        if (!state->map) {
            perror("Failed to allocate map rows");
        } else {
            success = 1;
            for (i = 0; i < state->rows + 2 && success; i++) {
                state->map[i] = (char *)malloc((state->cols + 2) * sizeof(char));
                if (!state->map[i]) {
                    perror("Failed to allocate map columns");
                    for (j = 0; j < i; j++) {
                        free(state->map[j]);
                    }
                    free(state->map);
                    state->map = NULL;
                    success = 0;
                }
            }
            
            if (success) {
                /* Populate the map and border */
                for (r = 0; r < state->rows + 2 && success; r++) {
                    for (c = 0; c < state->cols + 2 && success; c++) {
                        if (r == 0 || r == state->rows + 1 || 
                            c == 0 || c == state->cols + 1) 
                        {
                            state->map[r][c] = CHAR_BORDER;
                        } else {
                            /* Read map data */
                            if (fscanf(file, "%d", &value) != 1) {
                                perror("Error: Map data insufficient or invalid");
                                game_destroy_map(state->map, state->rows, state->cols);
                                state->map = NULL;
                                success = 0;
                            } else {
                                state->map[r][c] = int_to_char(value);
                                
                                if (state->map[r][c] == CHAR_PLAYER) {
                                    state->player_r = r;
                                    state->player_c = c;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    if (file) {
        fclose(file);
    }

    return success;
}

/* Prints the map to the terminal with background colors */
void game_print_map( GameState *state) {
    int r;
    int c;

    for (r = 0; r < state->rows + 2; r++) {
        for (c = 0; c < state->cols + 2; c++) {
            char object = state->map[r][c];
            
            /* Apply color based on the object character */
            
            /* 1. Player submerged (game over) */
            if (object == CHAR_PLAYER && state->game_over == 2) {
                setBackground("blue");
                printf("%c", object);
                setBackground("reset");
            }
            /* 2. Goal (Always green background) */
            else if (object == CHAR_GOAL) {
                setBackground("green"); 
                printf("%c", object);
                setBackground("reset"); 
            }
            /* 3. Water */
            else if (object == CHAR_WATER) {
                setBackground("blue"); 
                printf("%c", object);
                setBackground("reset"); 
            } 
            /* 4. Trap */
            else if (object == CHAR_TRAP && state->trap_set_off == 0) {
                setBackground("red"); 
                printf("%c", object);
                setBackground("reset"); 
            } 
            /* 5. Everything else */
            else {
                /* All other objects (P, O, X, *, ' ') use default color */
                printf("%c", object);
            }
        }
        printf("\n");
    }
    fflush(stdout);
}

/* --- Game Logic and Undo --- */

/* Saves the current game state (deep copy) onto the undo linked list. */
void game_save_state( GameState *state, LinkedList *undo_list) {
    GameRecord *record = NULL;
    char **map_copy = NULL; /* Initialize to NULL for safety */

    /* Only proceed if state and undo_list are valid */
    if (state && undo_list) {
        
        /* 1. Deep copy the map first */
        map_copy = deep_copy_map((char **)state->map, state->rows, state->cols);
        
        /* Only proceed if the map copy succeeded */
        if (map_copy) {
            /* 2. Allocate and populate the record structure */
            record = (GameRecord *)malloc(sizeof(GameRecord)); 
            
            /* Only push to list if the record allocation succeeded */
            if (record) {
                record->prev_map_state = map_copy;
                record->prev_player_r = state->player_r;
                record->prev_player_c = state->player_c;
                record->prev_trap_set_off = state->trap_set_off;
                /* Store map dimensions for safe cleanup */
                record->rows = state->rows; 
                record->cols = state->cols;

                /* 3. Push the record pointer onto the generic linked list */
                list_push(undo_list, record); 
            } else {
                /* Allocation of record failed. We must clean up the map_copy 
                   that was successfully created in the step above. */
                perror("Failed to allocate game record"); 
                game_destroy_map(map_copy, state->rows, state->cols); 
            }
        }
        /* If map_copy failed, no further action is needed as map_copy is NULL */
    }
    
    
}

/* Restores the previous state from the undo list. ( */
int game_undo(GameState *state, LinkedList *undo_list) {
    GameRecord *record = NULL; 
    char **old_map;
    int success = 0;
    
    /* Cannot undo past the first state (count == 1). */
    if (list_is_empty(undo_list) || undo_list->count == 1) {
        printf("\n\t*** Cannot UNDO further (initial state) ***\n");
    } else {
        record = (GameRecord *)list_pop(undo_list); 
        if (record) {
            old_map = state->map;
            game_destroy_map(old_map, state->rows, state->cols);

            /* Restore state from record */
            state->map = record->prev_map_state;
            state->player_r = record->prev_player_r;
            state->player_c = record->prev_player_c;
            state->trap_set_off = record->prev_trap_set_off;
            
            state->map[state->player_r][state->player_c] = CHAR_PLAYER;

            free(record); 
            state->game_over = 0; 
            success = 1;
        }
    }
    
    return success;
}

/* Moves the player and handles collisions/triggers (Single Return) */
int game_move_player(GameState *state, LinkedList *undo_list, char input) {
    int new_r = state->player_r;
    int new_c = state->player_c;
    char target_object;
    int valid_move = 0;
    int player_r_old = state->player_r;
    int player_c_old = state->player_c;
    int moved_key = 0;

    switch (input) {
        case 'w': new_r--; moved_key = 1; break;
        case 's': new_r++; moved_key = 1; break;
        case 'a': new_c--; moved_key = 1; break;
        case 'd': new_c++; moved_key = 1; break;
        default: break; 
    }
    
    /* Only proceed if it was a movement key */
    if (moved_key) {
        /* Check boundary condition */
        if (new_r >= 1 && new_r <= state->rows &&
            new_c >= 1 && new_c <= state->cols) 
        {
            target_object = state->map[new_r][new_c];

            /* Check for collisions */
            if (target_object != CHAR_WALL && 
                target_object != CHAR_TRAPDOOR) 
            {
                /* Movement is valid! Save state before the move */
                game_save_state(state, undo_list);
                valid_move = 1;

                /* 1. Clear player's old position */
                state->map[player_r_old][player_c_old] = CHAR_EMPTY;

                /* 2. Check for triggers at the target position */
                if (target_object == CHAR_TRAP) {
                    state->trap_set_off = 1;
                    game_remove_trapdoors(state);
                    newSleep(0.3); 
                } else if (target_object == CHAR_GOAL) {
                    state->game_over = 1; /* Win condition */
                } else if (target_object == CHAR_WATER) {
                    state->game_over = 2; /* Loss condition */
                }

                /* 3. Update player position */
                state->player_r = new_r;
                state->player_c = new_c;

                /* 4. Place player character at new position */
                state->map[new_r][new_c] = CHAR_PLAYER;
            }
        }
    }
    
    return valid_move;
}

/* Spreads water one step using the brute-force floodfill method */
void game_spread_water(GameState *state) {
    int r;
    int c;
    int *new_water_coords = NULL;
    int coord_count = 0;
    int max_coords = (state->rows * state->cols) * 4; 
    int i;
    int new_r;
    int new_c;
    int dr[] = {-1, 1, 0, 0}; /* Up, Down */
    int dc[] = {0, 0, -1, 1}; /* Left, Right */
    int k;
    int success = 0;

    if (!state->trap_set_off || state->game_over != 0) {
        return;
    }

    new_water_coords = (int *)malloc(max_coords * 2 * sizeof(int)); 
    if (new_water_coords) {
        success = 1;
    } else {
        perror("Failed to allocate memory for new water coords");
        /* No return needed, success = 0 handles the skipping of Pass 1 and 2 */
    }

    if (success) {
        /* Pass 1: Find all locations where water should spread */
        for (r = 1; r <= state->rows; r++) {
            for (c = 1; c <= state->cols; c++) {
                if (state->map[r][c] == CHAR_WATER) {
                    
                    for (k = 0; k < 4; k++) {
                        new_r = r + dr[k];
                        new_c = c + dc[k];

                        /* Check bounds and ensure it's not a Wall */
                        if (new_r >= 1 && new_r <= state->rows &&
                            new_c >= 1 && new_c <= state->cols &&
                            state->map[new_r][new_c] != CHAR_WALL) 
                        {
                            /* If it's not already water, mark for potential spread */
                            if (state->map[new_r][new_c] != CHAR_WATER) {
                                /* Store the coordinates */
                                new_water_coords[coord_count * 2] = new_r;
                                new_water_coords[coord_count * 2 + 1] = new_c;
                                coord_count++;
                            }
                        }
                    }
                }
            }
        }

        /* Pass 2: Apply the new water to the map */
        for (i = 0; i < coord_count; i++) {
            new_r = new_water_coords[i * 2];
            new_c = new_water_coords[i * 2 + 1];

            if (state->map[new_r][new_c] == CHAR_PLAYER) {
                /* Spread Loss: Player submerges */
                state->game_over = 2; 
            } 
            
            /* Only spread water if the target is NOT the player AND NOT the goal. */
            if (state->map[new_r][new_c] != CHAR_PLAYER && 
                state->map[new_r][new_c] != CHAR_GOAL) 
            {
                state->map[new_r][new_c] = CHAR_WATER; 
            }
        }
    }

    free(new_water_coords);
    
    newSleep(0.05); 
}
