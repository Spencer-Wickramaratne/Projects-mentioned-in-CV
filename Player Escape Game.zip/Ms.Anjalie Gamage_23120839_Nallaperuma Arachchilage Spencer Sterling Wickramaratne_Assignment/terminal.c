/* terminal.c */
#include <stdio.h>
#include <stdlib.h>
#include <termios.h> 
#include <unistd.h>  
#include "terminal.h"

/*
 * Clears the terminal screen and resets the cursor position using system calls.
 */
void terminal_clear_screen(TerminalState *ts) {
    if (ts->first_call) {
        /* Initial clear to start fresh */
        system("clear");
        ts->first_call = 0;
    } else {
        /* Move cursor to row 0, column 0 for a smooth overwrite */
        system("tput cup 0 0");
    }
    fflush(stdout); 
}

/*
 * Disables terminal buffer and echo (sets raw mode).
 * Returns 1 on success, 0 on failure. 
 */
int disableBuffer(TerminalState *ts)
{
    struct termios mode;
    int result = 0;

    if (tcgetattr(STDIN_FILENO, &ts->original_termios) == -1) {
        perror("tcgetattr failed");
    } else {
        /* Make a copy to modify */
        mode = ts->original_termios; 

        /* Disable Echo and Canonical (line buffering) mode */
        mode.c_lflag &= ~(ECHO | ICANON);
        
        /* Apply the new settings immediately */
        if (tcsetattr(STDIN_FILENO, TCSANOW, &mode) == -1) {
            perror("tcsetattr disableBuffer failed");
        } else {
            result = 1;
        }
    }
    return result;
}

/*
 * Enables terminal buffer and echo (restores original mode). 
 */
void enableBuffer(TerminalState *ts)
{
    /* Restore the original settings stored in ts->original_termios */
    if (tcsetattr(STDIN_FILENO, TCSANOW, &ts->original_termios) == -1) {
        perror("tcsetattr enableBuffer failed");
    }
    
}