/* linkedlist.c */
#include <stdio.h>
#include <stdlib.h>
#include "linkedlist.h"

/*
 * Initialize a new LinkedList structure and return a pointer to it.
 * The list itself is dynamically allocated. (Single Return)
 */
LinkedList *list_create(void) {
    LinkedList *list = NULL;
    
    list = (LinkedList *)malloc(sizeof(LinkedList));
    if (list) {
        list->head = NULL;
        list->count = 0;
    } else {
        perror("Failed to allocate new list");
    }
    
    return list;
}

/*
 * Adds a new node to the head of the list, storing the generic data pointer.
 */
void list_push(LinkedList *list, void *data) {
    LinkedListNode *new_node;

    if (!list) {
        return;
    }

    new_node = (LinkedListNode *)malloc(sizeof(LinkedListNode));
    if (!new_node) {
        perror("Failed to allocate new list node");
        return;
    }
    
    new_node->data = data;
    new_node->next = list->head;
    list->head = new_node;
    list->count++;
}

/*
 * Removes and returns the generic data pointer from the head of the list.
 * Frees the node structure, but NOT the data it points to. 
 */
void *list_pop(LinkedList *list) {
    LinkedListNode *temp;
    void *data = NULL;

    if (list && list->head != NULL) {
        temp = list->head;
        data = temp->data; /* Retrieve the generic data pointer */
        list->head = temp->next;
        free(temp); /* Free the node itself */
        list->count--;
    }

    return data; /* Return the pointer to the stored data (GameRecord) */
}

/*
 * Checks if the linked list is empty.
 */
int list_is_empty(LinkedList *list) {
    return (list == NULL || list->head == NULL);
}

/*
 * Frees all nodes in the list and frees the data they contain using the
 * provided free_func.
 * Finally, frees the list structure itself.
 */
void list_destroy(LinkedList *list, FreeDataFunc free_func) {
    LinkedListNode *current;
    LinkedListNode *next;

    if (!list) {
        return;
    }

    current = list->head;
    while (current != NULL) {
        next = current->next;
        /* Free the data first using the provided function */
        if (free_func && current->data) {
            free_func(current->data);
        }
        free(current); /* Free the node */
        current = next;
    }

    /* Free the list structure itself */
    free(list); 
}
