#ifndef MAP_DATA_H
#define MAP_DATA_H

/* Game object characters  */
#define CHAR_BORDER '*'
#define CHAR_PLAYER 'P'
#define CHAR_GOAL 'G'
#define CHAR_TRAP '@'
#define CHAR_WATER '~'
#define CHAR_TRAPDOOR 'X'
#define CHAR_WALL 'O'
#define CHAR_EMPTY ' '



/* Structure to hold the dynamic game map and state */
typedef struct {
    char **map;      /* The 2D dynamically allocated map array */
    int rows;        /* Playable map rows (excluding border) */
    int cols;        /* Playable map columns (excluding border) */
    int player_r;    /* Player row index (including border) */
    int player_c;    /* Player column index (including border) */
    int trap_set_off;/* Flag: 0 if trap is present, 1 if set off */
    int game_over;   /* Flag: 0 for playing, 1 for win, 2 for lose */
} GameState;

/* Generic Linked List Node */
typedef struct LinkedListNode {
    void *data;
    struct LinkedListNode *next;
} LinkedListNode;

/* Generic Linked List */
typedef struct {
    LinkedListNode *head;
    int count;
} LinkedList;

/* Structure to store game state for the UNDO feature */
typedef struct {
    char **prev_map_state; /* A deep copy of the map */
    int prev_player_r;
    int prev_player_c;
    int prev_trap_set_off;
    int rows; 
    int cols; 
} GameRecord; 

#endif /* MAP_DATA_H */
