#ifndef TERMINAL_H
#define TERMINAL_H

#include <termios.h>

/* New struct to hold the terminal state for restoration and clear screen logic */
typedef struct {
    struct termios original_termios;
    int first_call; /* Used to manage terminal_clear_screen behavior  */
} TerminalState;

void terminal_clear_screen(TerminalState *ts);

/* Functions now take the state struct to manage internal state (termios) */
int disableBuffer(TerminalState *ts);
void enableBuffer(TerminalState *ts);

#endif