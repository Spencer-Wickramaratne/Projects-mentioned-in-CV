#ifndef GAME_H
#define GAME_H

#include "map_data.h"
#include "linkedlist.h" /* For LinkedList */

/* Function to handle all memory allocation for the game state */
GameState *game_init( char *filename);

/* Function to free all dynamically allocated memory within the GameState */
void game_destroy(GameState *state);

/* Function to read the map file and populate the map and state */
int game_load_map( char *filename, GameState *state);

/* Function to print the map with colors */
void game_print_map( GameState *state);

/* Function to handle player movement and updates the map */
int game_move_player(GameState *state, LinkedList *undo_list, char input);

/* Function to perform the Floodfill algorithm */
void game_spread_water(GameState *state);

/* Function to save the current state for UNDO */
void game_save_state( GameState *state, LinkedList *undo_list);

/* Function to restore the previous state from UNDO list */
int game_undo(GameState *state, LinkedList *undo_list);

/* Free function for the GameRecord data  */
void free_record_data(void *data);

#endif /* GAME_H */
