/* main.c */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h> 
#include "game.h"
#include "linkedlist.h"
#include "terminal.h" 
#include "newSleep.h" 

#define ARG_COUNT 2

/* Helper function to print the game commands */
static void print_game_instructions(void) {
    printf("\n");
    printf("Press 'w' to move UP\n");
    printf("Press 's' to move DOWN\n");
    printf("Press 'a' to move LEFT\n");
    printf("Press 'd' to move RIGHT\n");
    printf("Press 'u' to UNDO\n");
    printf("Press 'q' to QUIT\n");
    fflush(stdout);
}

/* Main entry point of the program (Single Return) */
int main(int argc, char *argv[]) {
    GameState *state = NULL;
    LinkedList *undo_list = NULL;
    TerminalState ts = {0}; /* Initialize TerminalState struct ( */
    char input;
    int running = 1;
    int return_code = 0; /* Final return code */

    /* 1. Argument Validation */
    if (argc != ARG_COUNT) {
        printf("Usage: %s <map_text_file>\n", argv[0]);
        return_code = 0; /* Keep 0 for successful exit after printing usage */
    } else {

        /* 2. Initialization and File I/O */
        state = game_init(argv[1]); 
        if (!state) {
            return_code = 1;
        } else {
            undo_list = list_create();
            if (!undo_list) {
                perror("Failed to create undo list");
                game_destroy(state);
                return_code = 1;
            } else if (!disableBuffer(&ts)) { 
                /* Failed to set terminal mode */
                list_destroy(undo_list, free_record_data); 
                game_destroy(state);
                return_code = 1;
            } else {
            
                /* 3. Main Game Loop */
                ts.first_call = 1; /* Ensure first_call is set for clear_screen logic */
                while (state->game_over == 0 && running) {
                    terminal_clear_screen(&ts); 
                    
                    /* Display Map and Instructions */
                    game_print_map(state);
                    print_game_instructions(); 

                    /* Read single character input without 'Enter' */
                    if (read(STDIN_FILENO, &input, 1) < 1) {
                        running = 0; 
                    }

                    if (input == 'q') {
                        running = 0; 
                    } else if (input == 'u') {
                        game_undo(state, undo_list);
                    } else if (input == 'w' || input == 's' || input == 'a' || input == 'd') {
                        if (game_move_player(state, undo_list, input)) {
                            if (state->trap_set_off) {
                                game_spread_water(state);
                            }
                        }
                    } else {
                        /* Ignore all other characters */
                    }
                    
                    if (state->game_over != 0) {
                        running = 0;
                    }
                }

                /* 4. Game Over and Cleanup */
                
                /*  Restore terminal mode FIRST */
                enableBuffer(&ts); /* Pass &ts */
                
                /* Use asystem clear to wipe the final game state and menu */
                system("clear");
                
                /* Print final map and result */
                game_print_map(state);
                
               
                if (state->game_over == 1) {
                    printf("\n\t*** YOU WIN! The Goal is yours! ***\n");
                } else if (state->game_over == 2) { 
                    printf("\n\t*** YOU LOSE! Submerged by the Water! ***\n");
                } else {
                    printf("\n\t*** Game session closed. ***\n");
                }
                
               
                printf("\n"); 
                
                /* Free all dynamically allocated memory */
                list_destroy(undo_list, free_record_data); 
                game_destroy(state); 
                return_code = 0;
            }
        }
    }

    return return_code;
}
