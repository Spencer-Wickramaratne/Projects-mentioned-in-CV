/*
 * FILE: Mission.java
 * AUTHOR: N.A.Spencer.S.Wickramaratne
 * USERNAME: 23120839
 * UNIT: COMP2010
 * PURPOSE: This file defines the Mission class, which represents a space mission
 * with details like name, code, destination, launch year, success rate,
 * manned status, and an array to hold assigned Astronaut objects.
 * It provides methods to access and modify mission details, and manage its astronauts.
 * Last Mod: 2025-05-17
 */

/*
 * Class name: Mission
 * Purpose: Represents a space mission with its details and assigned astronauts.
 */
public class Mission {

   
    private String missionName;      
    private String missionCode;       
    private String destinationPlanet; 
    private int launchYear;           
    private double successRate;      
    private boolean mannedMission;    
    private Astronaut[] astronauts;   
    /*
     * Constructor comment block
     * NAME: Mission
     * PURPOSE: To create a new Mission object and initialize its fields.
     * IMPORTS:
     * pMissionName (String): The name of the mission.
     * pMissionCode (String): The code of the mission.
     * pDestinationPlanet (String): The destination planet.
     * pLaunchYear (int): The launch year.
     * pSuccessRate (double): The success rate.
     * pMannedMission (boolean): Whether it's a manned mission.
     * EXPORTS: A new Mission object.
     * Assertions:
     * Pre: Valid (though validation handled in MissionController) parameter values are provided.
     * Post: A new Mission object is created with the provided details and an empty astronaut array.
     */
    public Mission(String pMissionName, String pMissionCode, String pDestinationPlanet, int pLaunchYear, double pSuccessRate, boolean pMannedMission) {
        
        this.missionName = pMissionName;
        this.missionCode = pMissionCode;
        this.destinationPlanet = pDestinationPlanet;
        this.launchYear = pLaunchYear;
        this.successRate = pSuccessRate;
        this.mannedMission = pMannedMission;
        /*
         * Initialize the astronauts array to hold a fixed size of 5 Astronaut objects.
         * Initially, all elements in the array will be null.
         */
        this.astronauts = new Astronaut[5];
    }

    /*
     * Method comment block (Public Interface Method)
     * NAME: addAstronaut
     * PURPOSE: To add an Astronaut object to the mission's astronaut array at a specific index.
     * IMPORTS:
     * pAstronaut (Astronaut): The Astronaut object to add.
     * inIndex (int): The index in the array where the astronaut should be placed (0-4).
     * EXPORTS: None.
     * Assertions:
     * Pre: The inIndex is within the valid range of the astronauts array (0 to 4).
     * The pAstronaut object is not null.
     * Post: If the conditions are met, the pAstronaut object is placed at the specified index
     * in the astronauts array.
     */
    public void addAstronaut(Astronaut pAstronaut, int inIndex) {
        
        if (inIndex >= 0 && inIndex < this.astronauts.length && pAstronaut != null) {
            /*
             * If the index is valid and the astronaut is not null, assign the astronaut
             * object to the specified position in the array.
             */
            this.astronauts[inIndex] = pAstronaut;
        }
    }

    /*
     * Method comment block (Private Helper Method)
     * NAME: clearAstronauts
     * PURPOSE: To remove all assigned astronauts from the mission by re-initializing the array.
     * IMPORTS: None.
     * EXPORTS: None.
     * Assertions:
     * Pre: None. Can be called at any time.
     * Post: The astronauts array is re-created with 5 null elements, effectively removing all
     * previously assigned astronauts.
     */
    public void clearAstronauts() {
        
        this.astronauts = new Astronaut[5];
    }

    /*
     * Method comment block (Public Accessor Methods)
     * NAME: getMissionName
     * PURPOSE: To provide access to the mission name.
     * IMPORTS: None.
     * EXPORTS: The mission name (String).
     * Assertions:
     * Pre: The Mission object has been properly initialized.
     * Post: The current value of the 'missionName' field is returned.
   
     */
    public String getMissionName() {
        
        return this.missionName;
    }

    /*
     * Method comment block (Public Accessor Methods)
     * NAME: getMissionCode
     * PURPOSE: To provide access to the mission code.
     * IMPORTS: None.
     * EXPORTS: The mission code (String).
     * Assertions:
     * Pre: The Mission object has been properly initialized.
     * Post: The current value of the 'missionCode' field is returned.
     */
    public String getMissionCode() {
        
        return this.missionCode;
    }

    /*
     * Method comment block (Public Accessor Methods)
     * NAME: getDestinationPlanet
     * PURPOSE: To provide access to the destination planet.
     * IMPORTS: None.
     * EXPORTS: The destination planet (String).
     * Assertions:
     * Pre: The Mission object has been properly initialized.
     * Post: The current value of the 'destinationPlanet' field is returned.
     */
    public String getDestinationPlanet() {
        
        return this.destinationPlanet;
    }

    /*
     * Method comment block (Public Accessor Methods)
     * NAME: getLaunchYear
     * PURPOSE: To provide access to the launch year.
     * IMPORTS: None.
     * EXPORTS: The launch year (int).
     * Assertions:
     * Pre: The Mission object has been properly initialized.
     * Post: The current value of the 'launchYear' field is returned.
     */
    public int getLaunchYear() {
        
        return this.launchYear;
    }

    /*
     * Method comment block (Public Accessor Methods)
     * NAME: getSuccessRate
     * PURPOSE: To provide access to the success rate.
     * IMPORTS: None.
     * EXPORTS: The success rate (double).
     * Assertions:
     * Pre: The Mission object has been properly initialized.
     * Post: The current value of the 'successRate' field is returned.
     */
    public double getSuccessRate() {
        
        return this.successRate;
    }

    /*
     * Method comment block (Public Accessor Methods)
     * NAME: isMannedMission
     * PURPOSE: To check if the mission is a manned mission.
     * IMPORTS: None.
     * EXPORTS: A boolean value; true if manned, false if unmanned.
     * Assertions:
     * Pre: The Mission object has been properly initialized.
     * Post: The current value of the 'mannedMission' field is returned.
     */
    public boolean isMannedMission() {
        
        return this.mannedMission;
    }

    /*
     * Method comment block (Public Accessor Methods)
     * NAME: getAstronauts
     * PURPOSE: To provide access to the array of astronauts assigned to the mission.
     * IMPORTS: None.
     * EXPORTS: The astronauts array (Astronaut[]).
     * Assertions:
     * Pre: The Mission object has been properly initialized.
     * Post: A reference to the 'astronauts' array is returned.
     */
    public Astronaut[] getAstronauts() {
        
        return this.astronauts;
    }

    /*
     * Method comment block (Public Mutator Methods)
     * NAME: setMissionName
     * PURPOSE: To modify the mission name.
     * IMPORTS:
     * pMissionName (String): The new mission name.
     * EXPORTS: None.
     * Assertions:
     * Pre: The Mission object has been properly initialized.
     * pMissionName is a valid non-empty string (validation handled in MissionController).
     * Post: The 'missionName' field is updated to the new value.
     */
    public void setMissionName(String pMissionName) {
        
        this.missionName = pMissionName;
    }

    /*
     * Method comment block (Public Mutator Methods)
     * NAME: setDestinationPlanet
     * PURPOSE: To modify the destination planet.
     * IMPORTS:
     * pDestinationPlanet (String): The new destination planet.
     * EXPORTS: None.
     * Assertions:
     * Pre: The Mission object has been properly initialized.
     * pDestinationPlanet is a valid non-empty string (validation handled in MissionController).
     * Post: The 'destinationPlanet' field is updated to the new value.
     */
    public void setDestinationPlanet(String pDestinationPlanet) {
        
        this.destinationPlanet = pDestinationPlanet;
    }

    /*
     * Method comment block (Public Mutator Methods)
     * NAME: setLaunchYear
     * PURPOSE: To modify the launch year.
     * IMPORTS:
     * pLaunchYear (int): The new launch year.
     * EXPORTS: None.
     * Assertions:
     * Pre: The Mission object has been properly initialized.
     * pLaunchYear is a valid integer within the allowed range (validation handled in MissionController).
     * Post: The 'launchYear' field is updated to the new value.
     */
    public void setLaunchYear(int pLaunchYear) {
       
        this.launchYear = pLaunchYear;
    }

    /*
     * Method comment block (Public Mutator Methods)
     * NAME: setSuccessRate
     * PURPOSE: To modify the success rate.
     * IMPORTS:
     * pSuccessRate (double): The new success rate.
     * EXPORTS: None.
     * Assertions:
     * Pre: The Mission object has been properly initialized.
     * pSuccessRate is a valid double within the allowed range (validation handled in MissionController).
     * Post: The 'successRate' field is updated to the new value.
     */
    public void setSuccessRate(double pSuccessRate) {
       
        this.successRate = pSuccessRate;
    }

    /*
     * Method comment block (Public Mutator Methods)
     * NAME: setMannedMission
     * PURPOSE: To modify the manned status of the mission.
     * IMPORTS:
     * pMannedMission (boolean): The new manned status.
     * EXPORTS: None.
     * Assertions:
     * Pre: The Mission object has been properly initialized.
     * Post: The 'mannedMission' field is updated. If the mission becomes unmanned,
     * the astronaut array is cleared.
     */
    public void setMannedMission(boolean pMannedMission) {
        /*
         * Assign the imported new manned status to the 'mannedMission' instance variable.
         */
        this.mannedMission = pMannedMission;
        /*
         * Check if the new status indicates an unmanned mission.
         */
        if (!this.mannedMission) {
            
            clearAstronauts();
        }
    }

    /*
     * Method comment block (Public Interface Method)
     * NAME: toString
     * PURPOSE: To provide a user-friendly String representation of the Mission object's state.
     * IMPORTS: None.
     * EXPORTS: A String containing the mission's key details.
     * Assertions:
     * Pre: The Mission object has been properly initialized.
     * Post: A formatted String describing the mission is returned.
     */
    public String toString() { 
        /*
         * Declare a String variable to hold the manned status description.
         */
        String mannedStatus;
        
        if (this.mannedMission) {
            mannedStatus = "Manned";
        } else {
            mannedStatus = "Unmanned";
        }

        return "Mission: " + this.missionName + " (" + this.missionCode + ")" +
               "\n  Destination: " + this.destinationPlanet +
               "\n  Launch Year: " + this.launchYear +
               "\n  Success Rate: " + String.format("%.1f%%", this.successRate) + // Formats to one decimal place
               "\n  Type: " + mannedStatus;
    }

    /*
     * Method comment block (Public Interface Method)
     * NAME: equals
     * PURPOSE: To compare this Mission object with another object for equality based on their mission code.
     * IMPORTS:
     * inObject (Object): The object to compare against.
     * EXPORTS: A boolean value; true if the objects are considered equal, false otherwise.
     * Assertions:
     * Pre: The current Mission object has been properly initialized.
     * Post: Returns true if the inObject is a Mission with the same mission code (case-insensitive),
     * false otherwise.
    
     */
    public boolean equals(Object inObject) { 
        
        boolean isEqual = false;
        /*
         * Declare a variable of type Mission, initialized to null. This will hold
         * the incoming object after it's checked and cast to Mission.
         */
        Mission pMission = null;

        /*
         * Check if the imported object is actually an instance of the Mission class.
         * This prevents ClassCastException if a non-Mission object is passed.
         */
        if (inObject instanceof Mission) {
            
            pMission = (Mission) inObject;
            
            if (this.missionCode.equalsIgnoreCase(pMission.getMissionCode())) {
                
                isEqual = true;
            }
        }
        
        return isEqual;
    }
}
