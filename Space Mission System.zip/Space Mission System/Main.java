/*
 * AUTHOR: N.A.Spencer.S.Wickramaratne
 * USERNAME:23120839
 * UNIT: COMP2010
 * PURPOSE: This file contains the main entry point of the Space Exploration Mission Management System program.
 * It initializes the MissionController, handles loading data from the CSV file,
 * displays the main menu to the user, and processes user input to call the
 * appropriate functionalities in the MissionController. It also handles saving
 * data before the program exits.
 * Last Mod: 2025-05-17
 * 
 * Imports the IOException class, needed to catch potential errors during file operations
 * performed by the MissionController.
 */
import java.io.IOException;
/*
 * Imports the Scanner class, used for reading input from the console (System.in).
 */
import java.util.Scanner;

/*
 * Class name: Main
 * Purpose: The entry point for the Space Exploration Mission Management System application.
 */
public class Main {

    /*
     * Using a constant makes the filename easy to change in one place if needed.
     */
    private static final String DATA_FILE = "data.csv"; 

    /*
     * Method comment block (Public Static Method)
     * NAME: main
     * PURPOSE: The entry point of the Java application. Initializes the mcon object,
     * loads data, runs the main menu loop, and saves data on exit.
     * IMPORTS:
     * args (String[]): Command line arguments (not used in this program).
     * EXPORTS: None.
     * Assertions:
     * Pre: The program is executed from the command line or an IDE.
     * Post: The program runs the mission management system based on user interaction
     * until the user chooses to exit. Data is saved on successful exit.
     */
    public static void main(String[] args) {
        
        MissionController mcon = new MissionController();
       
        Scanner scanner = new Scanner(System.in);
        /*
         * Attempt to load mission data from the specified CSV file when the program starts.
         */
        System.out.println("Attempting to load missions from " + DATA_FILE + "...");
        /*
         * Use a try-catch block to handle potential IOExceptions that might occur
         * during the file loading process (e.g., file not found, read errors).
         */
        try {
            /*
             * Call the loadMissions method of the MissionController, passing the data file name.
             * This method is declared to throw IOException, so it must be called within a try block.
             */
            mcon.loadMissions(DATA_FILE);
        } catch (IOException e) {
            /*
             * If an IOException occurs during loading, print an informative error message to System.err.
             * System.err is typically used for error output.
             * e.getMessage() provides a description of the specific error.
             */
            System.err.println("Error loading missions from " + DATA_FILE + ": " + e.getMessage());
            System.err.println("Please ensure '" + DATA_FILE + "' exists in the same directory as the compiled Java code and is accessible.");
            System.err.println("Starting with an empty mission list.");
        }

       
        boolean running = true;

        while (running) {
           
            displayMenu();
            
            System.out.print("Enter your choice: ");
            
            String cStr = scanner.nextLine();
           
            int choice = -1;

            /*
             * Use a try-catch block to handle potential NumberFormatException if the user
             * enters non-integer input for the menu choice.
             */
            try {
                /*
                 * Attempt to convert the input string to an integer.
                 */
                choice = Integer.parseInt(cStr);
            } catch (NumberFormatException e) {
                /*
                 * If conversion fails, print an error message. The loop will then repeat.
                 */
                System.out.println("Invalid input. Please enter a number (1-9).");
                /*
                 * Use a single return path at the end of the loop iteration.
                 * The loop condition will be checked again.
                 */
            }

            switch (choice) {
                case 1:
                    
                    mcon.displayAllMissions();
                   
                    break;
                case 2:
                    mcon.displayMannedMissions();
                    break;
                case 3:
                    mcon.displayUnmannedMissions();
                    break;
                case 4:
                   
                    mcon.viewMissionAstronauts(scanner);
                    break;
                case 5:
                   
                    mcon.addMission(scanner);
                    break;
                case 6:
                   
                    mcon.editMission(scanner);
                    break;
                case 7:
                    
                    mcon.summarizeSuccessRates();
                    break;
                case 8:
                   
                    mcon.astronautsOfNationality(scanner);
                    break;
                case 9:
                    /*
                     * Attempt to save the current mission data to the CSV file before exiting.
                     */
                    System.out.println("Attempting to save missions to " + DATA_FILE );
                    try {
                        // Call the saveMissions method on your MissionController object (mcon)
                        // Pass the filename (DATA_FILE constant) as the argument
                        mcon.saveMissions(DATA_FILE);
                        System.out.println("Missions saved successfully.Goodbye!"); // Confirmation message after successful save
                    } catch (IOException e) {
                        // Handle potential IOException during saving
                        System.err.println("Error saving missions to " + DATA_FILE + ": " + e.getMessage());
                       
                    }
                    running = false;
                    break; 
                default:
                    
                    System.out.println("Invalid option. Please enter a number between 1 and 9.");
                    
            }
           
            if (running) { 
                System.out.println("\nPress Enter to continue...");
                scanner.nextLine();
            }
        }
        scanner.close();

    }

    /*
     * Method comment block (Private Static Method)
     * NAME: displayMenu
     * PURPOSE: Prints the main menu options to the console for the user.
     * IMPORTS: None.
     * EXPORTS: None.
     * Assertions:
     * Pre: None.
     * Post: The menu text is printed to the standard output.
     */
    private static void displayMenu() {
        
        System.out.println("\n=======================================");
        System.out.println("Welcome to Mission Command and Control");
        System.out.println("Your options for this system are listed below");
        System.out.println("1> View all Missions");
        System.out.println("2> View all manned missions.");
        System.out.println("3> View all unmanned missions.");
        System.out.println("4> View a mission's astronauts.");
        System.out.println("5> Add a new mission.");
        System.out.println("6> Edit an existing mission.");
        System.out.println("7> Summary of missions' success rates (average, highest, lowest).");
        System.out.println("8> List astronauts for a given nationality.");
        System.out.println("9> Exit Mission Command and Control");
        System.out.println("=======================================");
        
    }
}
