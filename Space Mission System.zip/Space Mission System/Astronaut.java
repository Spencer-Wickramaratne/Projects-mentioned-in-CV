/*
 * FILE: Astronaut.java
 * AUTHOR: N.A.Spencer.S.Wickramaratne
 * USERNAME: 23120839
 * UNIT: COMP2010
 * PURPOSE: This file defines the Astronaut class, which represents an individual astronaut
 * with their personal details such as name, role, age, and nationality.
 * It provides methods to access these details and compare Astronaut objects.
 * Last Mod: 2025-05-17
 */

/*
 * Class name: Astronaut
 * Purpose: Represents an astronaut with personal attributes.
 */
public class Astronaut {

    /*
     * Declaration of class fields (private as per coding standard)
     */
    private String name;       
    private String role;       
    private int age;           
    private String nationality;

    /*
     
     * NAME: Astronaut
     * PURPOSE: To create a new Astronaut object and initialize its fields.
     * IMPORTS:
     * Name (String): The name of the astronaut.
     * pRole (String): The role of the astronaut.
     * pAge (int): The age of the astronaut.
     * pNationality (String): The nationality of the astronaut.
     * EXPORTS: A new Astronaut object.
     * Assertions:
     * Pre: Valid (though not explicitly validated in constructor as per assignment flow)
     * String values for name, role, and nationality are provided.
     * A valid integer for age is provided.
     * Post: A new Astronaut object is created with the provided details.
     */
    public Astronaut(String pName, String pRole, int pAge, String pNationality) {
       
        this.name = pName;
        this.role = pRole;
        this.age = pAge;
        this.nationality = pNationality;
    }

    /*
     * Method comment block (Public Accessor Methods)
     * NAME: getName
     * PURPOSE: To provide access to the name of the astronaut.
     * IMPORTS: None.
     * EXPORTS: The name (String) of this Astronaut object.
     * Assertions:
     * Pre: The Astronaut object has been properly initialized.
     * Post: The current value of the 'name' field is returned.
     */
    public String getName() {
      
        return this.name;
    }

    /*
     * Method comment block (Public Accessor Methods)
     * NAME: getRole
     * PURPOSE: To provide access to the role of the astronaut.
     * IMPORTS: None.
     * EXPORTS: The role (String) of this Astronaut object.
     * Assertions:
     * Pre: The Astronaut object has been properly initialized.
     * Post: The current value of the 'role' field is returned.
   
     */
    public String getRole() {
        
        return this.role;
    }

    /*
     * NAME: getAge
     * PURPOSE: To provide access to the age of the astronaut.
     * IMPORTS: None.
     * EXPORTS: The age (int) of this Astronaut object.
     * Assertions:
     * Pre: The Astronaut object has been properly initialized.
     * Post: The current value of the 'age' field is returned.
     */
    public int getAge() {
        
        return this.age;
    }

    /*
     * NAME: getNationality
     * PURPOSE: To provide access to the nationality of the astronaut.
     * IMPORTS: None.
     * EXPORTS: The nationality (String) of this Astronaut object.
     * Assertions:
     * Pre: The Astronaut object has been properly initialized.
     * Post: The current value of the 'nationality' field is returned.
     */
    public String getNationality() {
        
        return this.nationality;
    }

    /* 
     * NAME: toString
     * PURPOSE: To provide a user-friendly String representation of the Astronaut object's state.
     * IMPORTS: None.
     * EXPORTS: A String containing the astronaut's name, role, age, and nationality.
     * Assertions:
     * Pre: The Astronaut object has been properly initialized.
     * Post: A formatted String describing the astronaut is returned.
     
     */
    public String toString() { 
        
        return "Name: " + this.name + ", Role: " + this.role + ", Age: " + this.age + ", Nationality: " + this.nationality;
    }

    /*
     * NAME: equals
     * PURPOSE: To compare this Astronaut object with another object for equality based on their attributes.
     * IMPORTS:
     * inObject (Object): The object to compare against.
     * EXPORTS: A boolean value; true if the objects are considered equal, false otherwise.
     * Assertions:
     * Pre: The current Astronaut object has been properly initialized.
     * Post: Returns true if the inObject is an Astronaut with the same name, role, age, and nationality,
     * false otherwise.
     */
    public boolean equals(Object inObject) { 
        
        boolean isEqual = false;
        /*
         * Declare a variable of type Astronaut, initialized to null. This will hold
         * the incoming object after it's checked and cast to Astronaut.
         */
        Astronaut pAstronaut = null;

        /*
         * Check if the imported object is actually an instance of the Astronaut class.
         * This prevents ClassCastException if a non-Astronaut object is passed.
         */
        if (inObject instanceof Astronaut) {
            
            pAstronaut = (Astronaut) inObject;
            
            if (this.name.equals(pAstronaut.getName()) &&
                this.role.equals(pAstronaut.getRole()) &&
                this.age == pAstronaut.getAge() &&
                this.nationality.equals(pAstronaut.getNationality())) {
                
                isEqual = true;
            }
        }
        
        return isEqual;
    }
}
