/* 

 * FILE: MissionController.java
 * AUTHOR: N.A.Spencer.S.Wickramaratne
 * USERNAME: 23120839
 * UNIT: COMP2010
 * PURPOSE: This file defines the MissionController class, which acts as the central
 * manager for all Mission objects. It handles loading and saving missions
 * from/to a CSV file, and provides methods for all the required
 * functionalities like viewing, adding, editing, summarizing, and listing
 * missions and astronauts based on user input.
 * Last Mod: 2025-05-17
 */

/*
 * Imports the BufferedReader class, used for efficient reading of text from input streams.
 * It buffers characters to provide efficient reading of lines.
 */
import java.io.BufferedReader;
/*
 * Imports the FileInputStream class, used for reading raw bytes from a file.
 * It is the starting point for reading from a file.
 */

import java.io.FileInputStream;
/*
 * Imports the FileOutputStream class, used for writing raw bytes to a file.
 * It is the starting point for writing to a file.

 */
import java.io.FileOutputStream;
/*
 * Imports the InputStreamReader class, which bridges byte streams to character streams.
 * It reads bytes and decodes them into characters using a specified charset.
 * Used here to read characters from the FileInputStream.

 */
import java.io.InputStreamReader;
/*
 * Imports the PrintWriter class, used for writing formatted representations of objects to a text-output stream.
 * It provides convenient methods for writing lines and formatting output.
 * Used here to write characters to the FileOutputStream.

 */
import java.io.PrintWriter;
/*
 * Imports the IOException class, which is a general class of exceptions produced by failed or interrupted I/O operations.
 * Methods that perform file operations often declare that they might throw this exception.

 */
import java.io.IOException;
/*
 * Imports the Scanner class, used for reading input from various sources, including the console (System.in).
 * It provides methods to parse primitive types and strings.

 */
import java.util.Scanner;

/*
 * Class name: MissionController
 * Purpose: Manages a collection of Mission objects, handling file I/O, user interaction,

 */
public class MissionController {

    private Mission[] missions;
    private int missionCount;

    /*
     * Constructor comment block
     * NAME: MissionController
     * PURPOSE: To create a new MissionController object and initialize its fields.
     * IMPORTS: None.
     * EXPORTS: A new MissionController object.
     * Assertions:
     * Pre: None.
     * Post: A new MissionController object is created with an empty missions array
     * and missionCount initialized to 0.
     */
    public MissionController() {
        this.missions = new Mission[150]; // Maximum of 150 missions
        this.missionCount = 0;
    }

    /*
     * Method comment block (Public Interface Method)
     * NAME: loadMissions
     * PURPOSE: Reads mission data from a CSV file and populates the missions array.
     * IMPORTS:
     * filename (String): The name of the CSV file to read from.
     * EXPORTS: None.
     * Assertions:
     * Pre: filename is a valid path where the program has read permmissions.
     * Post: The missioons array is populated with data read from the file.
     * Handles potential IOExceptions. Skips wrong lines with error messages.
     * Throws IOException if file operations fail.
     */

    public void loadMissions(String filename) throws IOException {
        int initialCount = this.missionCount;
        try (FileInputStream fileStream = new FileInputStream(filename);
             InputStreamReader isr = new InputStreamReader(fileStream);
             BufferedReader bufRdr = new BufferedReader(isr)) {

            bufRdr.readLine(); // Skip header

            String line;
            while ((line = bufRdr.readLine()) != null) {
                String[] data = line.split(",");
                if (data.length < 6) {
                    System.err.println("Ignoring line (too few fields): " + line);   
                }

                String missionCode = data[1].trim();
                if (data[0].trim().isEmpty() || missionCode.isEmpty() || data[2].trim().isEmpty()) {
                    System.err.println("Ignoring line (empty essential fields): " + line);
                   
                }
                if (findMissionByCode(missionCode) != null) {
                    System.err.println("Ignoring duplicate mission code: " + missionCode);    
                }

                try {
                    int launchYear = Integer.parseInt(data[3].trim());
                    double successRate = Double.parseDouble(data[4].trim());
                    boolean mannedMission = Boolean.parseBoolean(data[5].trim());

                    if (launchYear < 1900 || launchYear > 2100 || successRate < 0.0 || successRate > 100.0) {
                         System.err.println("Ignoring line (invalid year or rate): " + line);
                        
                    }

                    Mission mission = new Mission(data[0].trim(), missionCode, data[2].trim(), launchYear, successRate, mannedMission);

                    if (mannedMission && data.length > 6 && !data[6].trim().isEmpty()) {
                        String[] astronautsData = data[6].trim().split("\\|");
                        for (int i = 0; i < astronautsData.length && i < 5; i++) {
                            String[] astronautInfo = astronautsData[i].split(":");
                            if (astronautInfo.length == 4) {
                                try {
                                    int astroAge = Integer.parseInt(astronautInfo[2].trim());
                                     if (!astronautInfo[0].trim().isEmpty() && !astronautInfo[1].trim().isEmpty() && !astronautInfo[3].trim().isEmpty() && astroAge > 0) {
                                        mission.addAstronaut(new Astronaut(astronautInfo[0].trim(), astronautInfo[1].trim(), astroAge, astronautInfo[3].trim()), i);
                                    } else { System.err.println("Ignoring astronaut (invalid fields): " + astronautsData[i]); }
                                } catch (NumberFormatException e) { System.err.println("Ignoring astronaut (age format error): " + astronautsData[i]); }
                            } else { System.err.println("Ignoring astronaut data segment: " + astronautsData[i]); }
                        }
                    }

                    if (this.missionCount < this.missions.length) {
                        this.missions[this.missionCount++] = mission;
                    } else { System.err.println("Mission array full. Could not load: " + mission.getMissionName()); }

                } catch (NumberFormatException e) { System.err.println("Ignoring line (number/boolean format error): " + line); }
            }
            System.out.println("Missions loaded. New: " + (this.missionCount - initialCount));

        } catch (IOException e) {
            System.err.println("Error loading missions: " + e.getMessage());
            throw e;
        }
    }

    /*
     * Method comment block (Public Interface Method)
     * NAME: saveMissions
     * PURPOSE: Writes the current mission data from the missions array to a specified CSV file.
     * IMPORTS:
     * filename (String): The name of the CSV file to write to.
     * EXPORTS: None.
     * Assertions:
     * Pre: The filename is a valid path where the program has write permissions.
     * Post: The current state of the missions array is written to the file in CSV format.
     * Handles potential IOExceptions. Resource closing is handled explicitly in catch blocks.
     * Throws IOException if file operations fail.
  
     */

    public void saveMissions(String filename) throws IOException {
        try (FileOutputStream fileStream = new FileOutputStream(filename);
             PrintWriter pw = new PrintWriter(fileStream)) {

            pw.println("Mission Name,Mission Code,Destination Planet,Launch Year,Success Rate,Manned Mission,Astronauts");

            for (int i = 0; i < this.missionCount; i++) {
                Mission mission = this.missions[i];
                pw.print(mission.getMissionName() + "," + mission.getMissionCode() + "," +mission.getDestinationPlanet() + "," +
                         mission.getLaunchYear() + "," +mission.getSuccessRate() + "," +mission.isMannedMission());

                if (mission.isMannedMission()) {
                    pw.print(",");
                    boolean firstAstronaut = true;
                    for (Astronaut astronaut : mission.getAstronauts()) {
                        if (astronaut != null) {
                            if (!firstAstronaut) {
                                pw.print("|");
                            }
                            pw.print(astronaut.getName() + ":" +
                                     astronaut.getRole() + ":" +
                                     astronaut.getAge() + ":" +
                                     astronaut.getNationality());
                            firstAstronaut = false;
                        }
                    }
                }
                pw.println();
            }

            System.out.println("Missions saved successfully to " + filename);

        } catch (IOException e) {
            System.err.println("An IOException occurred during file saving: " + e.getMessage());
            throw e;
        }
    }

    /*
     * Method comment block (Private Helper Method)
     * NAME: findMissionByCode
     * PURPOSE: Searches the missions array for a mission with a specific mission code.
     * IMPORTS:
     * missionCode (String): The mission code to search for.
     * EXPORTS: The Mission object if found, or null if no mission with that code exists.
     * Assertions:
     * Pre: The missions array is populated with mission data.
     * Post: Returns a reference to the Mission object if its code matches the search code (case-insensitive),
     * otherwise returns null.
     */
    private Mission findMissionByCode(String missionCode) {
        for (int i = 0; i < this.missionCount; i++) {
            if (this.missions[i].getMissionCode().equalsIgnoreCase(missionCode)) {
                return this.missions[i];
            }
        }
        return null;
    }

    /*
     * Method comment block (Public Interface Method)
     * NAME: displayAllMissions
     * PURPOSE: Prints details of all missions.
     * IMPORTS: None. EXPORTS: None.
     * Assertions: Pre: missions array is populated. Post: Mission details printed.
     */
    public void displayAllMissions() {
        System.out.println("\n--- All Missions ---");
        if (this.missionCount == 0) {
            System.out.println("No missions available.");
            return;
        }
        for (int i = 0; i < this.missionCount; i++) {
            System.out.println((i + 1) + ". " + this.missions[i].toString());
            if (this.missions[i].isMannedMission()) {
                displayMissionAstronautsDetails(this.missions[i]);
            }
            System.out.println("--------------------");
        }
    }

    /*
     * Method comment block (Public Interface Method)
     * NAME: displayMannedMissions
     * PURPOSE: Prints details of all manned missions.
     * IMPORTS: None. EXPORTS: None.
     * Assertions: Pre: missions array populated. Post: Manned mission details printed.
     */
    public void displayMannedMissions() {
        boolean yesMan= false;
        System.out.println("\n--- Manned Missions ---");
        for (int i = 0; i < this.missionCount; i++) {
            if (this.missions[i].isMannedMission()) {
                System.out.println(this.missions[i].toString());
                displayMissionAstronautsDetails(this.missions[i]);
                System.out.println("--------------------");
                yesMan= true;
            }
        }
        if (!yesMan) {
            System.out.println("No manned missions available.");
        }
    }

    /*
     * Method comment block (Public Interface Method)
     * NAME: displayUnmannedMissions
     * PURPOSE: Prints details of all unmanned missions.
     * IMPORTS: None. EXPORTS: None.
     * Assertions: Pre: missions array populated. Post: Unmanned mission details printed.
     */
    public void displayUnmannedMissions() {
        boolean unMan= false;
        System.out.println("\n--- Unmanned Missions ---");
        for (int i = 0; i < this.missionCount; i++) {
            if (!this.missions[i].isMannedMission()) {
                System.out.println(this.missions[i].toString());
                System.out.println("--------------------");
                unMan= true;
            }
        }
        if (!unMan) {
            System.out.println("No unmanned missions available.");
        }
    }

    /*
     * Method comment block (Private Helper Method)
     * NAME: displayMissionAstronautsDetails
     * PURPOSE: Prints details of astronauts for a given mission.
     * IMPORTS: mission (Mission). EXPORTS: none.
     * Assertions: Pre: mission object is not null. Post: Astronaut details printed.
     */
    private void displayMissionAstronautsDetails(Mission mission) {
        if (!mission.isMannedMission()) {
            System.out.println("  Mission " + mission.getMissionName() + " is unmanned.");
            return;
        }

        boolean hasAstronauts = false;
        System.out.println("  Astronauts for " + mission.getMissionName() + " (" + mission.getMissionCode() + "):");
        for (Astronaut astronaut : mission.getAstronauts()) {
            if (astronaut != null) {
                System.out.println("    - " + astronaut.toString());
                hasAstronauts = true;
            }
        }
        if (!hasAstronauts) {
            System.out.println("    No astronauts assigned yet.");
        }
    }

    /*
     * Method comment block (Public Interface Method)
     * NAME: viewMissionAstronauts
     * PURPOSE: Prompts for mission code and displays astronauts.
     * IMPORTS: scanner (Scanner). EXPORTS: none.
     * Assertions: Pre: scanner open, missions array populated. Post: Astronauts displayed or not found message.
     */
    public void viewMissionAstronauts(Scanner scanner) {
        System.out.println("\n--- View Mission's Astronauts ---");
        System.out.print("Enter Mission Code: ");
        String missionCode = scanner.nextLine().trim();

        Mission mission = findMissionByCode(missionCode);

        if (mission == null) {
            System.out.println("Mission with code " + missionCode + " not found.");
        } else {
            displayMissionAstronautsDetails(mission);
        }
    }

    /*
     * Method comment block (Public Interface Method)
     * NAME: addMission
     * PURPOSE: Guides user to add a new mission (shortened with basic error handling).
     * IMPORTS: scanner (Scanner). EXPORTS: none.
     * Assertions: Includes basic validation for array capacity and number formats.
     */
    public void addMission(Scanner scanner) {
        System.out.println("\n--- Add New Mission ---");

        if (this.missionCount >= this.missions.length) {
            System.out.println("Mission storage is full. Cannot add more missions.");
            return;
        }

        String missionCode;
        boolean codeIsUnique = false;
        do {
            System.out.print("Enter Mission Code: ");
            missionCode = scanner.nextLine().trim();
            if (missionCode.isEmpty()) {
                System.out.println("Mission code cannot be empty.");
            } else if (findMissionByCode(missionCode) != null) {
                System.out.println("Mission code already exists. Please enter a unique code.");
            } else {
                codeIsUnique = true;
            }
        } while (!codeIsUnique || missionCode.isEmpty());

        System.out.print("Enter Mission Name: ");
        String missionName = scanner.nextLine().trim();

        System.out.print("Enter Destination Planet: ");
        String destinationPlanet = scanner.nextLine().trim();

        int launchYear = 0;
        boolean validYear = false;
        while (!validYear) {
            System.out.print("Enter Launch Year: ");
            try {
                launchYear = Integer.parseInt(scanner.nextLine().trim());
                validYear = true;
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid integer for the year.");
            }
        }

        double successRate = 0.0;
        boolean validRate = false;
        while (!validRate) {
            System.out.print("Enter Success Rate (0.0-100.0): ");
            try {
                successRate = Double.parseDouble(scanner.nextLine().trim());
                validRate = true;
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid number for the success rate.");
            }
        }

        boolean mannedMission = false;
        boolean validManned = false;
        while (!validManned) {
             System.out.print("Is this a Manned Mission? (true/false): ");
             String mannedInput = scanner.nextLine().trim().toLowerCase();
             if (mannedInput.equals("true")) {
                 mannedMission = true;
                 validManned = true;
             } else if (mannedInput.equals("false")) {
                 mannedMission = false;
                 validManned = true;
             } else {
                 System.out.println("Invalid input. Please enter 'true' or 'false'.");
             }
        }


        // Create new Mission object
        Mission newMission = new Mission(missionName, missionCode, destinationPlanet, launchYear, successRate, mannedMission);

        if (mannedMission) {
            System.out.println("Enter astronauts (name or 'done'). Up to 5:");
            for (int i = 0; i < 5; i++) {
                System.out.print("Astronaut " + (i + 1) + " Name: ");
                String astroNameInput = scanner.nextLine().trim();

                if (astroNameInput.equalsIgnoreCase("done") || astroNameInput.isEmpty()) {
                     if (astroNameInput.isEmpty()) {
                         System.out.println("Astronaut name cannot be empty, stopping astronaut entry.");
                    }
                    break;
                }

                System.out.print("Enter astronaut's role: ");
                String astroRole = scanner.nextLine().trim();

                int astroAge = 0;
                boolean validAstroAge = false;
                while(!validAstroAge){
                    System.out.print("Enter astronaut's age: ");
                    try {
                        astroAge = Integer.parseInt(scanner.nextLine().trim());
                        validAstroAge = true;
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid input. Please enter a valid integer for the age.");
                    }
                }


                System.out.print("Enter astronaut's nationality: ");
                String astroNationality = scanner.nextLine().trim();


                newMission.addAstronaut(new Astronaut(astroNameInput, astroRole, astroAge, astroNationality), i);
            }
        }

        if (this.missionCount < this.missions.length) {
             this.missions[this.missionCount] = newMission;
            this.missionCount++;
            System.out.println("Mission added successfully!");
        } else {
            System.out.println("Mission array is full. Could not add the mission.");
        }
    }


    /*
     * Method comment block (Public Interface Method)
     * NAME: editMission
     * PURPOSE: Allows user to select and edit an existing mission.
     * IMPORTS: scanner (Scanner). EXPORTS: none.
     * Assertions: Pre: scanner open, missions array populated. Post: Mission edited if found.
     */
    public void editMission(Scanner scanner) {
        System.out.println("\n--- Edit Existing Mission ---");
        System.out.print("Enter the Mission Code of the mission to edit: ");
        String missionCodeToEdit = scanner.nextLine().trim();

        Mission missionToEdit = findMissionByCode(missionCodeToEdit);

        if (missionToEdit == null) {
            System.out.println("Mission with code " + missionCodeToEdit + " not found.");
            return;
        }

        System.out.println("Found Mission: " + missionToEdit.getMissionName() + " (" + missionToEdit.getMissionCode() + ")");
        System.out.println("What would you like to edit?");
        System.out.println("1. Mission Name");
        System.out.println("2. Destination Planet");
        System.out.println("3. Launch Year");
        System.out.println("4. Success Rate");
        System.out.println("5. Manned Status and Astronauts");
        System.out.println("0. Back to Main Menu (No changes)");

        int choice = -1;
        boolean validChoice = false;
        while(!validChoice){
            System.out.print("Enter your choice: ");
            try {
                choice = Integer.parseInt(scanner.nextLine().trim());
                if (choice >= 0 && choice <= 5) {
                    validChoice = true;
                } else {
                    System.out.println("Invalid choice. Please enter a number between 0 and 5.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid integer.");
            }
        }


        switch (choice) {
            case 1:
                System.out.print("Enter new Mission Name: ");
                missionToEdit.setMissionName(scanner.nextLine().trim());
                System.out.println("Mission name updated.");
                break;
            case 2:
                System.out.print("Enter new Destination Planet: ");
                missionToEdit.setDestinationPlanet(scanner.nextLine().trim());
                System.out.println("Destination planet updated.");
                break;
            case 3:
                 int newLaunchYear = 0;
                 boolean validYear = false;
                 while(!validYear){
                     System.out.print("Enter new Launch Year: ");
                     try {
                         newLaunchYear = Integer.parseInt(scanner.nextLine().trim());
                         validYear = true;
                     } catch (NumberFormatException e) {
                         System.out.println("Invalid input. Please enter a valid integer for the year.");
                     }
                 }
                 missionToEdit.setLaunchYear(newLaunchYear);
                System.out.println("Year updated.");
                break;
            case 4:
                double newSuccessRate = 0.0;
                boolean validRate = false;
                while(!validRate){
                     System.out.print("Enter new Success Rate (0.0-100.0): ");
                     try {
                         newSuccessRate = Double.parseDouble(scanner.nextLine().trim());
                         validRate = true;
                     } catch (NumberFormatException e) {
                         System.out.println("Invalid input. Please enter a valid number for the success rate.");
                     }
                }
                missionToEdit.setSuccessRate(newSuccessRate);
                System.out.println("Rate updated.");
                break;
            case 5:
                 boolean newMannedStatus = false;
                 boolean validManned = false;
                 while (!validManned) {
                      System.out.print("Is this a Manned Mission? (true/false): ");
                      String mannedInput = scanner.nextLine().toLowerCase();
                      if (mannedInput.equals("true")) {
                          newMannedStatus = true;
                          validManned = true;
                      } else if (mannedInput.equals("false")) {
                          newMannedStatus = false;
                          validManned = true;
                      } else {
                          System.out.println("Invalid input. Please enter 'true' or 'false'.");
                      }
                 }

                missionToEdit.setMannedMission(newMannedStatus);

                if (newMannedStatus) {
                    missionToEdit.clearAstronauts();
                    System.out.println("Enter up to 5 astronauts (name or 'done'):");
                    for (int i = 0; i < 5; i++) {
                        System.out.print("Astronaut " + (i + 1) + " Name: ");
                        String astroName = scanner.nextLine().toLowerCase();
                        if (astroName.equals("done") ) {
                            break;
                        }
                        System.out.print("Enter astronaut's role: ");
                        String astroRole = scanner.nextLine();

                        int astroAge = 0;
                        boolean validAstroAge = false;
                         while(!validAstroAge){
                             System.out.print("Enter astronaut's age: ");
                             try {
                                 astroAge = Integer.parseInt(scanner.nextLine());
                                 validAstroAge = true;
                             } catch (NumberFormatException e) {
                                 System.out.println("Invalid input. Please enter a valid integer for the age.");
                             }
                         }

                        System.out.print("Enter astronaut's nationality: ");
                        String astroNationality = scanner.nextLine();
                        missionToEdit.addAstronaut(new Astronaut(astroName, astroRole, astroAge, astroNationality), i);
                    }
                }
                System.out.println("Manned status and astronauts updated.");
                break;
            case 0:
                System.out.println("No changes made.");
                break;
            default:
                // Should not be reached due to input validation loop
                System.out.println("Invalid choice.");
                break;
        }
    }


    /*
     * Method comment block (Public Interface Method)
     * NAME: summarizeSuccessRates
     * PURPOSE: Calculates and prints summary statistics for mission success rates.
     * IMPORTS: none. EXPORTS: none.
     * Assertions: Pre: missions array is populated. Post: Summary printed.

     */
    public void summarizeSuccessRates() {
        if (this.missionCount == 0) {
            System.out.println("\nNo missions available to summarize success rates.");
            return;
        }

        double tRate = 0;
        double hRate = -1.0;/* value lower than any possible success rate 0-100), the very first mission's rate will always be greater than -1.0, 
        so highestRate is correctly updated to that first rate. Then, the loop correctly finds the maximum among the remaining rates. */
        double lRate = 101.0;/*a value higher than any possible success rate 0-100), the very first mission's rate will always be less than 101.0, 
        so lowestRate is correctly updated to that first rate. Then, the loop correctly finds the minimum among the remaining rates. */

        for (int i = 0; i < this.missionCount; i++) {
            double currentRate = this.missions[i].getSuccessRate();
            tRate += currentRate;

            if (currentRate > hRate) {
                hRate = currentRate;
            }
            if (currentRate < lRate) {
                lRate = currentRate;
            }
        }

        double averageRate = tRate / this.missionCount;

        System.out.println("\n--- Success Rate Summary ---");
        System.out.println("Total Missions: " + this.missionCount);
        System.out.printf("Average Rate: %.1f%%\n", averageRate);
        System.out.printf("Highest Rate: %.1f%%\n", hRate);
        System.out.printf("Lowest Rate: %.1f%%\n", lRate);
    }

    /*
     * Method comment block (Public Interface Method)
     * NAME: astronautsOfNationality
     * PURPOSE: Lists astronauts of a specified nationality.
     * IMPORTS: scanner (Scanner). EXPORTS: none.
     * Assertions: Pre: scanner open, missions array populated. Post: Matching astronauts listed or not found message.

     */
    public void astronautsOfNationality(Scanner scanner) {
        System.out.print("Enter nationality: ");
        String nationInput = scanner.nextLine().toLowerCase();

        boolean present= false;
        System.out.println("Astronauts from " + nationInput + ":");


        for (int i = 0; i < this.missionCount; i++) {
            if (this.missions[i].isMannedMission()) {
                for (Astronaut astronaut : this.missions[i].getAstronauts()) {
                    if (astronaut != null) {
                        if (astronaut.getNationality().toLowerCase().equals(nationInput)) {
                            System.out.println("  - " + astronaut.getName() + " (Mission: " + this.missions[i].getMissionName() + ")");
                            present= true;
                        }
                    }
                }
            }
        }

        if (!present) {
            System.out.println("No astronauts found for nationality: " + nationInput);
        }
    }
}