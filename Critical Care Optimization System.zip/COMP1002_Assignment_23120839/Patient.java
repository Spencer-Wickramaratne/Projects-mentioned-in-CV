/* Author:Nallaperuma Arachchilage Spencer Sterling Wickramaratne
 * Curtin ID: 23120839
 * Patient.java
 * Represents a patient record in the hospital system, including their unique ID,
 * personal details, urgency score, estimated treatment duration, and current status.
 * 1. 6-argument constructor: Used by HospitalSortTest, accepts double duration and department.
 * 2. 5-argument constructor: Used by menus/other tests, accepts int duration and defaults department.
 */

public class Patient {

    private static final int MIN_URGENCY = 1;
    private static final int MAX_URGENCY = 5;
    private static final int MIN_AGE = 0;
    private static final int MAX_AGE = 120;
    public static final double MIN_DURATION = 0.1;

    // --- Fields ---

    private String patientId;
    private String name;
    private int age;
    private String department; // Added to match the test data structure
    private int urgency; // 1 (critical) to 5 (low)
    private double duration; // Estimated treatment duration in minutes (DOUBLE)
    private String treatmentStatus; // Used by the Heap Test to track 'Waiting', 'Treated', 'Discharged'

    /**

     * CONSTRUCTOR 1 (Primary - Detailed, 6 Arguments)
     * Used by HospitalSortTest.java to handle precise double duration and department field.
     */
    public Patient(String inPatientId, String inName, int inAge, String inDepartment, int inUrgency, double inDuration) {

        // Basic field validation

        if (inPatientId == null || inPatientId.trim().isEmpty()) {
            throw new IllegalArgumentException("Patient ID cannot be empty.");
        }
        if (inName == null || inName.trim().isEmpty()) {
            throw new IllegalArgumentException("Patient Name cannot be empty.");
        }
        if (inDepartment == null || inDepartment.trim().isEmpty()) {
            throw new IllegalArgumentException("Patient Department cannot be empty.");
        }
        if (inAge < MIN_AGE || inAge > MAX_AGE) {
            throw new IllegalArgumentException("Age must be between " + MIN_AGE + " and " + MAX_AGE + ".");
        }
        if (inUrgency < MIN_URGENCY || inUrgency > MAX_URGENCY) {
            throw new IllegalArgumentException("Urgency must be between " + MIN_URGENCY + " and " + MAX_URGENCY + ".");
        }
        if (inDuration < MIN_DURATION) {
            throw new IllegalArgumentException("Duration must be a positive number.");

        }
        this.patientId = inPatientId.trim();
        this.name = inName.trim();
        this.age = inAge;
        this.department = inDepartment.trim();
        this.urgency = inUrgency;
        this.duration = inDuration;
        this.treatmentStatus = "Waiting"; // Default status for a new request
    }

    /**

     * CONSTRUCTOR 2 (Overloaded - Simple, 5 Arguments)
     * Used by Module2Menu.java (Hash Table) and other initial tests/menus.
     * Defaults department to "General" and converts int duration to double.
     */

    public Patient(String inPatientId, String inName, int inAge, int inUrgency, double inDuration) {
        // Call the primary 6-argument constructor, providing default values
        this(inPatientId, inName, inAge, "General", inUrgency, inDuration);

    }

    // --- Getters ---

    public String getPatientId() { return patientId; }
    public String getName() { return name; }
    public int getAge() { return age; }
    public String getDepartment() { return department; }
    public int getUrgency() { return urgency; }
    public double getDuration() { return duration; }
    public String getTreatmentStatus() { return treatmentStatus; }
    // --- Setters ---

    public void setUrgency(int newUrgency) {
        if (newUrgency < MIN_URGENCY || newUrgency > MAX_URGENCY) {
            throw new IllegalArgumentException("Urgency must be between " + MIN_URGENCY + " and " + MAX_URGENCY + ".");
        }
        this.urgency = newUrgency;

    }
    public void setDuration(double newDuration) {
        if (newDuration < MIN_DURATION) {
            throw new IllegalArgumentException("Duration must be a positive number.");
        }
        this.duration = newDuration;
    }
    public void setTreatmentStatus(String status) {
        this.treatmentStatus = status;
    }

    // --- Object Methods --
    /**
     * Generates a string representation of the Patient object.
     */
    public String toString() {
       return String.format(
            "Patient [ID: %s, Name: %s, Age: %d, Department: %s, Urgency: %d/5, Duration: %.1f min, Status: %s]",
            patientId, name, age, department, urgency, duration, treatmentStatus
        );
    }
}