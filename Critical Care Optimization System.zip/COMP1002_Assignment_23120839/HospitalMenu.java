/* Author:Nallaperuma Arachchilage Spencer Sterling Wickramaratne
 * Curtin ID: 23120839
 * HospitalMenu.java
 * The consolidated main menu for all modules (Graph, Hash Table, Heap, Sorting).
 */
import java.util.Scanner;
import java.util.InputMismatchException;
import java.util.Random;
import java.lang.Math; 
import java.io.*; // Added for file reading/writing

public class HospitalMenu {

    //  SHARED RESOURCES (Instance Variables - Not Static) 
    private DSAGraph hospitalMap; 
    private DSAHashTable patientTable; 
    private DSAHeap emergencyQueue; 
    private Scanner scanner;
    
    //  MODULE 4 CONSTANTS (Static Final are permitted) 
    private static final int SEED = 50;
    private static final int REPETITIONS = 5;
    private static final double MAX_DURATION = 120.0; 
    private static final int MAX_MANUAL_PATIENTS = 20; // Fixed size for input array 
    
    //  MODULE 4 HELPER CLASS (Static final is permitted) 
    static class Result {
        String inputType;
        long mergeTime = 0;
        long quickTime = 0;
    }

    //  CONSTRUCTOR: Initializes all instance variables 
    public HospitalMenu() {
        this.scanner = new Scanner(System.in);
        
        // Initialize graph and hash table
        this.hospitalMap = new DSAGraph(true); 
        setupHospitalGraph(this.hospitalMap); 
        this.patientTable = new DSAHashTable(50); 
        setupInitialPatientRecords(this.patientTable); 
        
        // Initialize emergency queue as a MAX HEAP (false)
        this.emergencyQueue = new DSAHeap(false); 
        setupInitialEmergencyQueue();
    }
    
    
    //  MAIN METHOD: Instantiates and runs the system (Static Entry Point) 
    
    public static void main(String[] args) {
        HospitalMenu menu = new HospitalMenu();
        menu.runSystem();
    }
    
    // --- Instance Method to run the main loop ---
    private void runSystem() {
        System.out.println("=========================================================");
        System.out.println("             HOSPITAL DATA STRUCTURES MASTER MENU");
        System.out.println("=========================================================");
        
        int mainChoice = -1;
        do {
            try {
                displayMainMenu();
                System.out.print("Enter your choice (1-4 for Modules, 0 to Exit): ");
                mainChoice = this.scanner.nextInt();
                this.scanner.nextLine(); 

                switch (mainChoice) {
                    case 1: this.runModule1Menu(); break;
                    case 2: this.runModule2Menu(); break;
                    case 3: this.runModule3Menu(); break;
                    case 4: this.runModule4Menu(); break;
                    case 0: System.out.println("\nExiting the Hospital System. Goodbye!"); break;
                    default: System.out.println("\n[ERROR] Invalid choice. Please select 1, 2, 3, 4, or 0.");
                }
            } catch (InputMismatchException e) {
                System.out.println("\n[ERROR] Invalid input. Please enter a number.");
                this.scanner.nextLine(); 
                mainChoice = -1;
            } catch (Exception e) {
                System.out.println("\n[FATAL ERROR] An unexpected error occurred: " + e.getMessage());
                e.printStackTrace();
            }
        } while (mainChoice != 0);

        this.scanner.close();
    }
    
 
    //  STATIC HELPERS (No state dependency)
 

  private static void setupHospitalGraph(DSAGraph graph) {
    graph.addVertex("Emergency"); 
    graph.addVertex("ICU"); 
    graph.addVertex("Pharmacy"); 
    graph.addVertex("Radiology"); 
    graph.addVertex("Laboratories"); 
    graph.addVertex("Operating Theatres"); 
    graph.addVertex("Outpatient Units"); 
    graph.addVertex("Wards"); 

    //  Edges  to create a 3-node cycle: Emergency <-> ICU <-> Radiology <-> Emergency, 
    // and to ensure other nodes remain connected.
    graph.addEdge("Emergency", "ICU", 5.0); // 1. Cycle Leg 1 (Kept)
    graph.addEdge("ICU", "Radiology", 4.0); // 2. Cycle Leg 2 
    graph.addEdge("Radiology", "Emergency", 6.0); // 3. Cycle Leg 3, closes cycle 
    
    graph.addEdge("ICU", "Pharmacy", 3.0);
    graph.addEdge("Pharmacy", "Outpatient Units", 8.0);
    graph.addEdge("Operating Theatres", "Radiology", 2.0);
    graph.addEdge("Radiology", "Laboratories", 1.5); 
    graph.addEdge("Emergency", "Laboratories", 12.0); 
    graph.addEdge("ICU", "Operating Theatres", 10.0); 
    graph.addEdge("Outpatient Units", "Laboratories", 4.5); 
}
    
    private static void setupInitialPatientRecords(DSAHashTable table) {
        try {
   
            table.put("100", new Patient("100", "Mary Jane", 35, "Pharmacy", 3, 30.0)); 
            table.put("101", new Patient("101", "John Doe", 72, "ICU", 5, 120.0)); 
            table.put("102", new Patient("102", "Jane Smith", 19, "Radiology", 2, 15.0));
        } catch (IllegalArgumentException e) {
            System.err.println("[ERROR] Failed to load initial records: " + e.getMessage());
        }
    }

    /**
     * Calculates the priority score using the formula: Priority = (6 - U) + 1000 / T
     * U = Urgency Level (1=highest, 5=lowest)
     * T = Expected treatment time in minutes (Duration)
     * Higher priority value means higher priority for treatment.
     */
    private double calculatePriorityScore(Patient patient) {
        
        int U = patient.getUrgency();
        
        // Safety: If patient urgency is outside the expected 1-5 range used by the formula, cap it to 5.
        if (U > 5) {
            U = 5; 
        } else if (U < 1) {
            U = 1;
        }

        double T = Math.max(Patient.MIN_DURATION, patient.getDuration()); // Ensure T is not zero/too small

        // New Priority Formula: (6 - U) + 1000 / T
        return (6.0 - (double)U) + (1000.0 / T);
    }
    
    // --- MODULE 3 HELPER METHODS ---

    /** Helper to define the fixed set of test patients. */
    private Patient[] createTestPatients() {
        // Urgency: 1=highest, 5=lowest (using the 1-5 scale for the module logic)
        Patient p1 = new Patient("P01", "A. Smith", 55, "ER", 4, 45.0);  
        Patient p2 = new Patient("P02", "B. Jones", 21, "ER", 2, 10.0);  
        Patient p3 = new Patient("P03", "C. Lee", 78, "ER", 5, 100.0); 
        Patient p4 = new Patient("P04", "D. Wong", 33, "ER", 3, 25.0);  
        Patient p5 = new Patient("P05", "E. King", 60, "ER", 5, 50.0); 
        return new Patient[] { p1, p2, p3, p4, p5 };
    }

    /** Helper to load the initial, default set of patients into the emergency queue. */
    private void setupInitialEmergencyQueue() {
        // Only load if the queue is currently empty
        if (this.emergencyQueue.getCount() == 0) {
            Patient[] initialPatients = createTestPatients();
            for (Patient p : initialPatients) {
                double priority = calculatePriorityScore(p);
                this.emergencyQueue.add(priority, p);
                p.setTreatmentStatus("Waiting (Initial)");
            }
        }
    }
    

    //  MODULE 1: GRAPH NAVIGATION (Instance Methods) 
    private void displayMainMenu() {
        System.out.println("\n--- Master Menu ---");
        System.out.println("1. Module 1: Hospital Map (Graph Algorithms - BFS, DFS, Dijkstra)");
        System.out.println("2. Module 2: Patient Lookup (Hash Table Operations)");
        System.out.println("3. Module 3: Emergency Scheduler (Heap/Priority Queue Test Trace)");
        System.out.println("4. Module 4: Patient Sorting (Algorithm Benchmarking)");
        System.out.println("0. Exit System");
    }

    private void runModule1Menu() {
        int choice = -1;
        do {
            try {
                System.out.println("\n--- Module 1: Hospital Map Menu ---");
                System.out.println("1. Display Graph Structure (Adjacency List)");
                System.out.println("2. Run Breadth-First Search (BFS) by Level");
                System.out.println("3. Run Depth-First Search (DFS) Cycle Detection");
                System.out.println("4. Find Shortest Path (Dijkstra's Algorithm)");
                System.out.println("5. Interactive Graph Modification and Re-Analysis"); 
                System.out.println("0. Back to Master Menu");
                
                System.out.print("Enter choice: ");
                choice = this.scanner.nextInt();
                this.scanner.nextLine(); 

                switch (choice) {
                    case 1: this.hospitalMap.displayAsList(); break;
                    case 2: runBFS(); break;
                    case 3: runDFS(); break;
                    case 4: runDijkstra(); break;
                    case 5: runInteractiveGraphMenu(); break; 
                    case 0: break;
                    default: System.out.println("\n[ERROR] Invalid choice. Please try again.");
                }
            } catch (InputMismatchException e) {
                System.out.println("\n[ERROR] Invalid input. Please enter a number.");
                this.scanner.nextLine(); 
                choice = -1;
            } catch (Exception e) {
                System.out.println("\n[ERROR] Operation failed: " + e.getMessage());
            }
        } while (choice != 0);
    }
    
    private void runBFS() {
        System.out.print("\nEnter starting department for BFS (e.g., Emergency): ");
        String startLabel = this.scanner.nextLine().trim();
        System.out.println("\n--- BFS Results (Start: " + startLabel + ") ---");
        System.out.print(this.hospitalMap.breadthFirstSearchLevelOutput(startLabel));
    }

    private void runDFS() {
        System.out.print("\nEnter starting department for DFS cycle check (e.g., Emergency): ");
        String startLabel = this.scanner.nextLine().trim();
        System.out.println("\n--- DFS Cycle Detection (Start: " + startLabel + ") ---");
        System.out.println("Note: Only reports cycles in UNDIRECTED mode.");
        System.out.println(this.hospitalMap.depthFirstSearchCycleDetection(startLabel));
    }

    private void runDijkstra() {
        System.out.print("\nEnter starting department (Source): ");
        String startLabel = this.scanner.nextLine().trim();
        System.out.print("Enter destination department (Target): ");
        String endLabel = this.scanner.nextLine().trim();

        System.out.println("\n--- Dijkstra's Shortest Path (Source: " + startLabel + ", Target: " + endLabel + ") ---");
        System.out.println("Cited: Edsger W. Dijkstra, 1959");
        System.out.println(this.hospitalMap.shortestPathDijkstra(startLabel, endLabel));
    }

    //  NEW METHODS FOR INTERACTIVE GRAPH (MODULE 1) 
    
    private void runInteractiveGraphMenu() {
        int choice = -1;
        do {
            try {
                System.out.println("\n--- Module 1: Interactive Graph Builder & Analysis ---");
                System.out.println("1. Add New Department (Vertex)");
                System.out.println("2. Add New Undirected Route (Weighted Edge - Walking Time)");
                System.out.println("3. Run Full Graph Re-Analysis (Display, BFS, DFS, Dijkstra)");
                System.out.println("0. Back to Module 1 Menu");
                
                System.out.print("Enter choice: ");
                choice = this.scanner.nextInt();
                this.scanner.nextLine(); 

                switch (choice) {
                    case 1: runAddDepartment(); break;
                    case 2: runAddEdge(); break;
                    case 3: runFullGraphAnalysis(); break;
                    case 0: break;
                    default: System.out.println("\n[ERROR] Invalid choice. Please try again.");
                }
            } catch (InputMismatchException e) {
                System.out.println("\n[ERROR] Invalid input. Please enter a number.");
                this.scanner.nextLine(); 
                choice = -1;
            } catch (Exception e) {
                System.out.println("\n[ERROR] Operation failed: " + e.getMessage());
            }
        } while (choice != 0);
    }

    private void runAddDepartment() {
        System.out.print("\nEnter new department name (Vertex Label): ");
        String label = this.scanner.nextLine().trim();
        try {
            this.hospitalMap.addVertex(label);
            System.out.printf("[RESULT] SUCCESS: Department '%s' added to the hospital map.\n", label);
        } catch (IllegalArgumentException e) {
            System.out.println("[ERROR] Failed to add vertex: " + e.getMessage());
        }
    }

    private void runAddEdge() {
        System.out.print("\nEnter Source Department: ");
        String source = this.scanner.nextLine().trim();
        System.out.print("Enter Target Department: ");
        String target = this.scanner.nextLine().trim();
        try {
            System.out.print("Enter Walking Time (Weight, e.g., 5.5): ");
            double weight = this.scanner.nextDouble();
            this.scanner.nextLine(); // consume newline

            this.hospitalMap.addEdge(source, target, weight);
            System.out.printf("[RESULT] SUCCESS: Undirected edge added between %s and %s with weight %.1f.\n", source, target, weight);

        } catch (InputMismatchException e) {
            System.out.println("[ERROR] Invalid number format for Weight.");
            this.scanner.nextLine(); 
        } catch (IllegalArgumentException e) {
            System.out.println("[ERROR] Failed to add edge: " + e.getMessage());
        }
    }
    
    private void runFullGraphAnalysis() {
        System.out.println("\n=======================================================");
        System.out.println("        FULL GRAPH RE-ANALYSIS ON MODIFIED MAP");
        System.out.println("=======================================================");
        
        // 1. Display Adjacency List
        System.out.println("\n--- 1. Current Adjacency List ---");
        this.hospitalMap.displayAsList();

        // 2. Get Analysis Inputs
        System.out.print("\nEnter starting department for BFS/DFS/Dijkstra (e.g., Emergency): ");
        String startLabel = this.scanner.nextLine().trim();
        System.out.print("Enter destination department for Dijkstra (e.g., ICU): ");
        String endLabel = this.scanner.nextLine().trim();
        
        // 3. BFS
        System.out.println("\n--- 2. BFS Results (Start: " + startLabel + ") ---");
        try {
            System.out.print(this.hospitalMap.breadthFirstSearchLevelOutput(startLabel));
        } catch (Exception e) {
            System.out.println("[ERROR] BFS failed: " + e.getMessage());
        }

        // 4. DFS Cycle Detection
        System.out.println("\n--- 3. DFS Cycle Detection (Start: " + startLabel + ") ---");
        System.out.println(this.hospitalMap.depthFirstSearchCycleDetection(startLabel));
        
        // 5. Dijkstra's Shortest Path
        System.out.println("\n--- 4. Dijkstra's Shortest Path ---");
        if (endLabel.isEmpty()) {
            System.out.println("[INFO] Dijkstra skipped (no valid destination provided).");
        } else {
            System.out.println("Source: " + startLabel + ", Target: " + endLabel);
            try {
                System.out.println(this.hospitalMap.shortestPathDijkstra(startLabel, endLabel));
            } catch (Exception e) {
                System.out.println("[ERROR] Dijkstra failed: " + e.getMessage());
            }
        }
        
        System.out.println("=======================================================\n");
    }

    
    // --- MODULE 2: HASH TABLE LOOKUP (Instance Methods) ---
  
    private void runModule2Menu() {
        System.out.println("\n=======================================================");
        System.out.println("  MODULE 2: HASH-BASED PATIENT LOOKUP SYSTEM (Menu)");
        System.out.println("  Initial Table Size: " + this.patientTable.getArraySize());
        System.out.println("=======================================================");

        int choice = -1;
        do {
            try {
                System.out.println("\n--- Patient Lookup Operations (Manual) ---");
                System.out.println("1. Insert New Patient Record (or Update Existing)");
                System.out.println("2. Search Patient Record by ID");
                System.out.println("3. Delete Patient Record by ID");
                System.out.println("4. Display Hash Table Status (Size, Count, Load Factor)");
                System.out.println("5. Load from CSV (PatientToHash.csv) and Export Table State (Hashtable.csv)"); 
                System.out.println("6. Run Resize Test (Load TriggerResize.csv and Export ResizeHashTable.csv)"); 
                System.out.println("0. Back to Master Menu");

                System.out.print("Enter choice: ");
                choice = this.scanner.nextInt();
                this.scanner.nextLine(); 

                switch (choice) {
                    case 1: runInsertPatient(); break;
                    case 2: runSearchPatient(); break;
                    case 3: runDeletePatient(); break;
                    case 4: displayTableStatus(); break;
                    case 5: runFileHashBenchmark(); break; 
                    case 6: runResizeTest(); break; 
                    case 0: break;
                    default: System.out.println("\n[ERROR] Invalid choice. Please try again.");
                }
            } catch (InputMismatchException e) {
                System.out.println("\n[ERROR] Invalid input. Please enter a number.");
                this.scanner.nextLine(); 
                choice = -1;
            } catch (Exception e) {
                System.out.println("\n[ERROR] Operation failed: " + e.getMessage());
            }
        } while (choice != 0);
    }
    
    private void runInsertPatient() {
        System.out.println("\n--- INSERT / UPDATE PATIENT ---");
        try {
            System.out.print("Patient ID (Key): ");
            String id = this.scanner.nextLine().trim();
            System.out.print("Name: ");
            String name = this.scanner.nextLine().trim();
            System.out.print("Age: ");
            int age = this.scanner.nextInt();
            this.scanner.nextLine(); 
            
            System.out.print("Urgency Level (1-5, 1=Highest): "); 
            int urgency = this.scanner.nextInt();
            this.scanner.nextLine();
            
            // Urgency Validation for 1-5 (matching module logic)
            if (urgency < 1 || urgency > 5) {
                throw new IllegalArgumentException("Urgency level must be between 1 (Highest) and 5 (Lowest).");
            }

            System.out.print("Estimated Duration (minutes, integer): "); 
            int duration = this.scanner.nextInt();
            this.scanner.nextLine();

            Patient newPatient = new Patient(id, name, age, "Emergency", urgency, (double)duration);

            boolean isUpdate = this.patientTable.hasKey(id);
            this.patientTable.put(id, newPatient);

            if (isUpdate) {
                System.out.printf("[RESULT] SUCCESS: Patient ID %s updated. Urgency: %d/5, Duration: %d min\n", id, urgency, duration);
            } else {
                System.out.printf("[RESULT] SUCCESS: New patient ID %s inserted. Current Count: %d\n", id, this.patientTable.getCount());
            }
        } catch (InputMismatchException e) {
            System.out.println("[ERROR] Invalid number format for Age, Urgency, or Duration.");
            this.scanner.nextLine();
        } catch (IllegalArgumentException e) {
            System.out.println("[ERROR] Validation failed: " + e.getMessage());
        }
    }

    private void runSearchPatient() {
        System.out.print("\nEnter Patient ID to search: ");
        String id = this.scanner.nextLine().trim();
        try {
            Patient result = (Patient) this.patientTable.get(id); 
            System.out.println("[RESULT] FOUND: " + result);
        } catch (IllegalArgumentException e) {
            System.out.println("[RESULT] NOT FOUND: " + e.getMessage());
        }
    }
    
    private void runDeletePatient() {
        System.out.print("\nEnter Patient ID to delete: ");
        String id = this.scanner.nextLine().trim();
        try {
            this.patientTable.remove(id);
            System.out.printf("[RESULT] SUCCESS: Patient ID %s removed.\n", id);
            displayTableStatus();
        } catch (IllegalArgumentException e) {
            System.out.println("[RESULT] FAILURE: " + e.getMessage());
        }
    }

    private void displayTableStatus() {
        System.out.println("\n--- Hash Table Status ---");
        System.out.printf("Table Size (M): %d\n", this.patientTable.getArraySize());
        System.out.printf("Current Count (N): %d\n", this.patientTable.getCount());
        System.out.printf("Load Factor (N/M): %.4f\n", (double) this.patientTable.getCount() / this.patientTable.getArraySize());
        this.patientTable.displayTable("Current State");
    }

    //  NEW METHOD FOR HASH TABLE CSV LOAD/EXPORT (MODULE 2) 
    private void runFileHashBenchmark() {
        final String INPUT_FILE = "PatientToHash.csv";
        final String OUTPUT_FILE = "Hashtable.csv";
        final int MAX_FILE_PATIENTS = 30; 
        
        System.out.println("\n--- Module 2: Load/Export Hash Table from CSV ---");
        System.out.printf("1. Reading up to %d patients from %s\n", MAX_FILE_PATIENTS, INPUT_FILE);
        
        Patient[] originalRecords = new Patient[MAX_FILE_PATIENTS];
        int count = 0;

        try {
            // Re-using the logic from the existing private readPatientsFromCSV method
            count = readPatientsFromCSV(INPUT_FILE, originalRecords, MAX_FILE_PATIENTS);
            
            if (count == 0) {
                System.out.printf("[INFO] No records read from %s. Aborting.\n", INPUT_FILE);
                return;
            }
            
            System.out.printf("2. Successfully read %d records.\n", count);

            // Create a new hash table for this operation 
            DSAHashTable fileHashTable = new DSAHashTable(this.patientTable.getArraySize());

            // Hash patients
            System.out.println("3. Inserting records into new Hash Table...");
            for (int i = 0; i < count; i++) {
                Patient p = originalRecords[i];
                
                // Ensure the key (Patient ID) is passed as a String to match DSAHashTable.put(String, Object) signature.
                fileHashTable.put(String.valueOf(p.getPatientId()), p);
            }
            
            System.out.printf("[RESULT] Insertion complete. Final Hash Table size: %d, Count: %d\n", 
                                fileHashTable.getArraySize(), fileHashTable.getCount());
            
            // Write hash table state to CSV
            writeHashTableToCSV(OUTPUT_FILE, fileHashTable);

        } catch (FileNotFoundException e) {
            System.out.printf("[FATAL ERROR] Input file %s not found. Please ensure the file is present.\n", INPUT_FILE);
            System.out.println("[HINT] Expected format: ID,Name,Age,Department,Urgency,Duration");
        } catch (IOException e) {
            System.out.printf("[FATAL ERROR] An I/O error occurred: %s\n", e.getMessage());
        } catch (Exception e) {
            System.out.printf("[FATAL ERROR] An unexpected error occurred: %s\n", e.getMessage());
            e.printStackTrace();
        }
    }
    
    /** * Loads patients from TriggerResize.csv into the patientTable 
     * in an amount sufficient to trigger an automatic resize, 
     * and exports the final state to ResizeHashTable.csv.
     */
    private void runResizeTest() {
        final String INPUT_FILE = "TriggerResize.csv";
        final String OUTPUT_FILE = "ResizeHashTable.csv";
        // The table size is 53 (nextPrime(50)), resize threshold is 40.
        // Reading 50 records ensures resize is triggered.
        final int MAX_RECORDS_TO_READ = 50; 
        
        System.out.println("\n--- Module 2: Load CSV to Trigger Hash Table Resize ---");
        System.out.printf("1. Current Hash Table Size (M): %d, Count (N): %d\n", 
                            this.patientTable.getArraySize(), this.patientTable.getCount());
        
        // Calculate the threshold based on the table's constants
        double resizeThreshold = Math.floor(this.patientTable.getArraySize() * DSAHashTable.UPPER_THRESHOLD);
        System.out.printf("   Resize will trigger when Count > %.0f\n", resizeThreshold);
        System.out.printf("2. Reading up to %d patients from %s\n", MAX_RECORDS_TO_READ, INPUT_FILE);
        
        // Use a temporary array to read the records
        Patient[] recordsFromFile = new Patient[MAX_RECORDS_TO_READ];
        int count = 0;

        try {
            // Re-use the existing helper method
            count = readPatientsFromCSV(INPUT_FILE, recordsFromFile, MAX_RECORDS_TO_READ);
            
            if (count == 0) {
                System.out.printf("[INFO] No records read from %s. Aborting.\n", INPUT_FILE);
                return;
            }
            
            System.out.printf("3. Successfully read %d new records.\n", count);

            // Insert records into the class-level patientTable
            System.out.println("4. Inserting new records into patientTable. Automatic resize will occur...");
            
            for (int i = 0; i < count; i++) {
                Patient p = recordsFromFile[i];
                // put() handles the key validation, insertion, and automatic resize
                this.patientTable.put(p.getPatientId(), p); 
            }
            
            System.out.printf("[RESULT] Insertion complete. Total patients now: %d\n", this.patientTable.getCount());
            
            // Write hash table state to CSV
            System.out.println("5. Exporting final Hash Table state after resize...");
            writeHashTableToCSV(OUTPUT_FILE, this.patientTable);

            System.out.printf("6. Final Hash Table Size (M): %d, Count (N): %d\n", 
                                this.patientTable.getArraySize(), this.patientTable.getCount());

        } catch (FileNotFoundException e) {
            System.out.printf("[FATAL ERROR] Input file %s not found. Please ensure the file is present.\n", INPUT_FILE);
            System.out.println("[HINT] Expected format: ID,Name,Age,Department,Urgency,Duration");
        } catch (IOException e) {
            System.out.printf("[FATAL ERROR] An I/O error occurred: %s\n", e.getMessage());
        } catch (Exception e) {
            System.out.printf("[FATAL ERROR] An unexpected error occurred: %s\n", e.getMessage());
            e.printStackTrace();
        }
    }


    /** Helper to write the contents of the Hash Table array to a CSV file. 
     * The output format is now fixed-width (tabular) instead of pure CSV.
     */
    private void writeHashTableToCSV(String filename, DSAHashTable table) throws IOException {
        PrintWriter pw = new PrintWriter(new FileWriter(filename));

        // Define the fixed-width format string for the columns.
        // Department column width increased to 25 characters to accommodate long names.
        final String FORMAT = "%-5s %-15s %-10s %-25s %5s %-25s %8s %10s";
        
        //  This requires a public accessor method (getHashArray) in DSAHashTable 
        // to retrieve the underlying array of DSAHashEntry objects.
        DSAHashTable.DSAHashEntry[] hashArray = table.getHashArray();
        
        // 1. Header (Separator line adjusted for new column width)
        pw.println("-------------------------------------------------------------------------------------------------------------");
        pw.println(String.format(FORMAT, 
            "Index", "Status", "Key", "Patient Name", "Age", "Department", "Urgency", "Duration"));
        pw.println("-------------------------------------------------------------------------------------------------------------");

        for (int i = 0; i < hashArray.length; i++) {
            DSAHashTable.DSAHashEntry entry = hashArray[i];
            
            String statusStr;
            String keyStr = "";
            String nameStr = "";
            String ageStr = "";
            String deptStr = "";
            String urgencyStr = "";
            String durationStr = "";
            
            if (entry.getState() == DSAHashTable.DSAHashEntry.USED) {
                statusStr = "USED";
                keyStr = entry.getKey();
                
                // Check if the value is a Patient object and extract its details
                if (entry.getValue() instanceof Patient) {
                    Patient p = (Patient) entry.getValue();
                    nameStr = p.getName();
                    // use String.valueOf() to prepare the string values for the format.
                    ageStr = String.valueOf(p.getAge()); 
                    deptStr = p.getDepartment();
                    urgencyStr = String.valueOf(p.getUrgency());
                    // Format duration to one decimal place
                    durationStr = String.format("%.1f", p.getDuration()); 
                } else {
                    // Fallback if the value is not a Patient object (e.g., just a string)
                    nameStr = entry.getValue().toString(); 
                }

            } else if (entry.getState() == DSAHashTable.DSAHashEntry.PREVIOUSLY_USED) {
                statusStr = "PREV_USED (DEL)";
                // All other fields remain empty strings (keyStr, nameStr, etc.)
            } else { // FREE
                statusStr = "FREE";
                // All other fields remain empty strings
            }
            
            // 2. Write the line using the fixed-width tabular format
            String line = String.format(FORMAT,
                                        String.valueOf(i), // Index column
                                        statusStr, 
                                        keyStr, 
                                        nameStr, 
                                        ageStr, 
                                        deptStr, 
                                        urgencyStr, 
                                        durationStr);
            pw.println(line);
        }
        
        pw.println("-------------------------------------------------------------------------------------------------------------");
        pw.close();
        System.out.printf("4. Wrote final Hash Table state in tabular format to %s\n", filename);
    }


   
    //  MODULE 3: EMERGENCY SCHEDULER (Instance Methods) 
   

    private void runModule3Menu() {
        System.out.println("\n=======================================================");
        System.out.println("  MODULE 3: EMERGENCY SCHEDULER MENU (Priority Queue)");
        System.out.println("  Priority: MAX HEAP (Score = (6 - U) + 1000 / T)");
        System.out.println("=======================================================");
        
        int choice = -1;
        do {
            try {
                System.out.println("\n--- Emergency Scheduling Operations ---");
                System.out.println("1. Manual: Insert New Patient to Queue");
                System.out.println("2. Manual: Extract Highest Priority Patient");
                System.out.println("3. Update Patient Urgency Level and Re-Calculate Priority"); 
                System.out.println("4. Display Current Queue Status (Full Queue List and Top Priority)"); 
                System.out.println("5. **RUN AUTOMATED TEST TRACE** (Inserts/Extracts for logging)"); 
                System.out.println("0. Back to Master Menu");
                
                System.out.print("Enter choice: ");
                choice = this.scanner.nextInt();
                this.scanner.nextLine(); 

                switch (choice) {
                    case 1: runInsertPatientToHeap(); break;
                    case 2: runExtractPatientFromHeap(); break;
                    case 3: runUpdatePatientUrgency(); break; 
                    case 4: displayQueueStatus(); break; 
                    case 5: runHeapTestTrace(); break;
                    case 0: break;
                    default: System.out.println("\n[ERROR] Invalid choice. Please try again.");
                }
            } catch (InputMismatchException e) {
                System.out.println("\n[ERROR] Invalid input. Please enter a number.");
                this.scanner.nextLine(); 
                choice = -1;
            } catch (IllegalStateException e) {
                System.out.println("\n[ERROR] Heap operation failed: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("\n[ERROR] Operation failed: " + e.getMessage());
            }
        } while (choice != 0);
    }
    
    /** Helper to find a specific patient entry in the heap array by ID. */
    private DSAHeap.DSAHeapEntry findPatientEntryInHeap(String patientId) {
        DSAHeap.DSAHeapEntry result = null; 
        int i = 0;
        int count = this.emergencyQueue.getCount();

        // Loop continues only while the patient has not been found AND we haven't reached the end of the array.
        while (result == null && i < count) {
            DSAHeap.DSAHeapEntry entry = this.emergencyQueue.getEntry(i);
            // Assuming the value stored is the Patient object
            Patient p = (Patient) entry.getValue();
            
            if (p.getPatientId().equals(patientId)) {
                result = entry; // Assigning result causes the loop condition (result == null) to fail on the next iteration.
            }
            i++;
        }
        
        return result; 
    }

    //  FOR URGENCY UPDATE
    private void runUpdatePatientUrgency() {
        System.out.println("\n--- UPDATE PATIENT URGENCY & PRIORITY ---");
        try {
            System.out.print("Enter Patient ID to update: ");
            String id = this.scanner.nextLine().trim();

            DSAHeap.DSAHeapEntry oldEntry = findPatientEntryInHeap(id);

            if (oldEntry == null) {
                System.out.println("[ERROR] Patient ID " + id + " not found in the emergency queue.");
                return;
            }

            Patient patientToUpdate = (Patient) oldEntry.getValue();
            
            System.out.printf("Current Urgency Level: %d/5\n", patientToUpdate.getUrgency());
            System.out.printf("Current Priority Score: %.2f\n", oldEntry.getPriority());

            System.out.print("Enter NEW Urgency Level (1-5, 1=Highest): ");
            int newUrgency = this.scanner.nextInt();
            this.scanner.nextLine();

            // Urgency Validation for 1-5 (matching module logic)
            if (newUrgency < 1 || newUrgency > 5) {
                throw new IllegalArgumentException("Urgency level must be between 1 (Highest) and 5 (Lowest).");
            }

            // 1. Update the Patient Object (Requires Patient.setUrgency(int))
            // The Patient object must be mutable for this to work.
            patientToUpdate.setUrgency(newUrgency); 

            // 2. Recalculate New Priority
            double newPriority = calculatePriorityScore(patientToUpdate);
            
            // 3. Update the Heap's Priority (Requires DSAHeap.updatePriority(Object, double))
            // The custom DSAHeap must support updating the priority of an object in the heap.
            this.emergencyQueue.updatePriority(patientToUpdate, newPriority); 

            System.out.printf("[RESULT] SUCCESS: Patient %s updated.\n", id);
            System.out.printf("-> New Urgency: %d/5. New Priority Score: %.2f\n", newUrgency, newPriority);
            printHeapStateTrace("Update Priority for " + id, this.emergencyQueue);

        } catch (InputMismatchException e) {
            System.out.println("[ERROR] Invalid number format. Please enter a number.");
            this.scanner.nextLine();
        } catch (IllegalArgumentException e) {
            System.out.println("[ERROR] Update failed: " + e.getMessage());
        } catch (Exception e) {
            // This is a common point of failure if setUrgency or updatePriority is missing.
            System.out.println("[ERROR] Unexpected error during update: " + e.getMessage() + ". Check if Patient.setUrgency(int) and DSAHeap.updatePriority(Object, double) are implemented.");
        }
    }


    private void runInsertPatientToHeap() {
        System.out.println("\n--- INSERT PATIENT TO EMERGENCY QUEUE ---");
        double duration;
        String department;
        final String START_DEPARTMENT = "Emergency";

        try {
            System.out.print("Patient ID: ");
            String id = this.scanner.nextLine().trim();
            System.out.print("Name: ");
            String name = this.scanner.nextLine().trim();
            System.out.print("Age: ");
            int age = this.scanner.nextInt();
            this.scanner.nextLine();
            
            System.out.print("Urgency Level (1-5, 1=Highest): "); 
            int urgency = this.scanner.nextInt();
            this.scanner.nextLine();

            // Urgency Validation for 1-5 (matching module logic)
            if (urgency < 1 || urgency > 5) {
                throw new IllegalArgumentException("Urgency level must be between 1 (Highest) and 5 (Lowest).");
            }

            System.out.print("Required Treatment Department (e.g., ICU, Radiology, Laboratories): ");
            department = this.scanner.nextLine().trim();
            
            String shortestPathResult = this.hospitalMap.shortestPathDijkstra(START_DEPARTMENT, department);
            
            String[] parts = shortestPathResult.split("Total Walking Time: ");
            if (parts.length > 1) {
                String timeStr = parts[1].split(" minutes")[0];
                duration = Double.parseDouble(timeStr);
                System.out.printf("[INFO] Calculated Duration: Shortest path time from %s to %s is %.1f minutes.\n", 
                                  START_DEPARTMENT, department, duration);
                
                if (duration < Patient.MIN_DURATION) {
                    duration = Patient.MIN_DURATION;
                    System.out.printf("[WARNING] Duration set to minimum of %.1f due to invalid path result.\n", duration);
                }

            } else {
                System.out.println("[WARNING] Cannot determine shortest path (Unreachable/Invalid Dept). Falling back to manual duration entry.");
                System.out.print("Estimated Duration (minutes, e.g., 30.0): "); 
                duration = this.scanner.nextDouble();
                this.scanner.nextLine();
            }

            Patient newPatient = new Patient(id, name, age, department, urgency, duration);
            double priority = calculatePriorityScore(newPatient);
            
            System.out.println("-> Calculated Priority Score: " + String.format("%.2f", priority));

            this.emergencyQueue.add(priority, newPatient);
            newPatient.setTreatmentStatus("Waiting (In Queue)");
            
            System.out.println("[RESULT] SUCCESS: Patient added to queue.");
            printHeapStateTrace("Insert Patient " + newPatient.getPatientId(), this.emergencyQueue);
            
        } catch (InputMismatchException e) {
            System.out.println("[ERROR] Invalid number format for Age, Urgency, or Duration.");
            this.scanner.nextLine();
        } catch (IllegalArgumentException e) {
             System.out.println("[ERROR] Insertion failed: " + e.getMessage());
        } catch (Exception e) {
             System.out.println("[ERROR] Unexpected error: " + e.getMessage());
        }
    }
    
    private void runExtractPatientFromHeap() {
        System.out.println("\n--- EXTRACT HIGHEST PRIORITY PATIENT ---");
        try {
            DSAHeap.DSAHeapEntry removedEntry = this.emergencyQueue.remove();
            Patient treatedPatient = (Patient) removedEntry.getValue(); 
            
            treatedPatient.setTreatmentStatus("Treated (Extracted)");
            
            System.out.println("[RESULT] TREATING PATIENT: " + treatedPatient);
            System.out.println("-> Priority Score: " + String.format("%.2f", removedEntry.getPriority()));
            printHeapStateTrace("Extract Max Priority", this.emergencyQueue);
            
        } catch (IllegalStateException e) {
            System.out.println("[RESULT] FAILURE: Queue is empty. No patients to treat.");
        }
    }

    private void displayQueueStatus() {
        System.out.println("\n==============================================");
        System.out.println("--- CURRENT EMERGENCY QUEUE STATUS ---");
        System.out.println("==============================================");
        
        if (this.emergencyQueue.getCount() == 0) {
            System.out.println("The emergency queue is currently empty.");
            return;
        }

        System.out.println("--- FULL QUEUE LIST (Heap Array Order) ---");
        System.out.printf("| %-5s | %-5s | %-20s | %-8s | %-12s | %-8s |\n", 
                          "Index", "ID", "Name", "Urgency", "Duration (min)", "Score");
        System.out.println("|-------|-------|----------------------|----------|--------------|----------|");

        for (int i = 0; i < this.emergencyQueue.getCount(); i++) {
            DSAHeap.DSAHeapEntry entry = this.emergencyQueue.getEntry(i);
            Patient p = (Patient) entry.getValue(); 
            double score = entry.getPriority();
            
            String rowFormat = "| %-5d | %-5s | %-20s | %-8d | %-12.1f | %-8.2f |\n";
            System.out.printf(rowFormat, 
                              i, p.getPatientId(), p.getName(), p.getUrgency(), p.getDuration(), score);
        }
        System.out.println("|-------|-------|----------------------|----------|--------------|----------|");


        DSAHeap.DSAHeapEntry topEntry = this.emergencyQueue.peek(); 
        Patient topPatient = (Patient) topEntry.getValue();   
        double topScore = topEntry.getPriority();
        
        System.out.println("\n--- QUEUE SUMMARY ---");
        System.out.printf("Total Patients in Queue: %d\n", this.emergencyQueue.getCount());
        System.out.printf("Patient with TOP PRIORITY: **%s** (ID: %s)\n", topPatient.getName(), topPatient.getPatientId());
        System.out.printf("Priority Score: %.2f (Urgency: %d/5, Duration: %.1f min)\n", 
                          topScore, topPatient.getUrgency(), topPatient.getDuration());
        System.out.println("This patient has the **TOP PRIORITY** and will be treated next.");
        System.out.println("==============================================");
    }
    
    private void runHeapTestTrace() {
        System.out.println("\n--- AUTOMATED HEAP TEST TRACE ---");
        // Clear the current queue to start clean, as a test trace should start from a known state.
        this.emergencyQueue = new DSAHeap(false); 
        
        // Define test patients using the new helper method
        Patient[] testPatients = createTestPatients(); 

        System.out.println("\n** PHASE 1: INSERTING PATIENTS **");
        for (Patient p : testPatients) {
            double priority = calculatePriorityScore(p);
            System.out.printf("\nInserting: %s (Score: %.2f)\n", p.getName(), priority);
            this.emergencyQueue.add(priority, p);
            p.setTreatmentStatus("Waiting (In Queue)");
            printHeapStateTrace("Insert " + p.getPatientId(), this.emergencyQueue);
        }

        System.out.println("\n** PHASE 2: EXTRACTING PATIENTS (Highest Priority First) **");
        int initialCount = this.emergencyQueue.getCount();
        for (int i = 0; i < initialCount; i++) {
            try {
                DSAHeap.DSAHeapEntry removedEntry = this.emergencyQueue.remove();
                Patient treatedPatient = (Patient) removedEntry.getValue(); 
                treatedPatient.setTreatmentStatus("Treated (Extracted)");
                System.out.printf("\nExtracted %d: %s (Score: %.2f)\n", 
                                 i + 1, treatedPatient.getName(), removedEntry.getPriority());
                printHeapStateTrace("Extract " + treatedPatient.getPatientId(), this.emergencyQueue);
            } catch (IllegalStateException e) {
                // Should not happen
            }
        }
        
        // Restore the initial data after the trace is complete.
        if (this.emergencyQueue.getCount() == 0) {
            setupInitialEmergencyQueue(); 
            System.out.println("\n[TRACE COMPLETE] Initial emergency patients re-loaded for continuous operation.");
        } else {
             System.out.println("\n[TRACE COMPLETE] Emergency Queue trace finished.");
        }
    }
    
    private void printHeapStateTrace(String operation, DSAHeap heap) {
        System.out.println("------------------------------------------------------------------");
        System.out.printf("HEAP TRACE: %s (Count: %d)\n", operation, heap.getCount());
        System.out.println("Array Contents (Index: [Priority, Value]):");
        
        if (heap.getCount() == 0) {
            System.out.println("[]");
            return;
        }

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < heap.getCount(); i++) {
            DSAHeap.DSAHeapEntry entry = heap.getEntry(i);
            Patient patient = (Patient)entry.getValue(); 
            sb.append(String.format("[%d: (%.2f, %s)]", i, entry.getPriority(), patient.getPatientId()));
            if (i < heap.getCount() - 1) {
                sb.append(" | ");
            }
        }
        System.out.println(sb.toString());
        System.out.println("------------------------------------------------------------------");
    }
    
    // --------------------------------------------------------------------
    // --- MODULE 4: SORTING BENCHMARK (Instance Methods) ---
    // --------------------------------------------------------------------
    private void runModule4Menu() {
        System.out.println("\n=======================================================================");
        System.out.println("  MODULE 4: PATIENT RECORD SORTING");
        System.out.println("  Sorting Metric: Total Treatment Time (Path Time + Est. Duration)");
        System.out.println("=======================================================================");

        int choice = -1;
        do {
            try {
                System.out.println("\n--- Module 4 Menu ---");
                System.out.println("1. Run Automated Benchmarking (Time Analysis)");
                System.out.println("2. **Interactive Sort (Input Patients & Sort)**");
                System.out.println("3. **File-Based Sort (Read UnsortedPatients.csv, Generate  merge/quick sorted CSVs)**"); // ADDED
                System.out.println("0. Back to Master Menu");
                
                System.out.print("Enter choice: ");
                choice = this.scanner.nextInt();
                this.scanner.nextLine(); 

                switch (choice) {
                    case 1: runAutomatedBenchmark(); break; 
                    case 2: runModule4InteractiveMenu(); break;
                    case 3: runFileBenchmark(); break; // ADDED
                    case 0: break;
                    default: System.out.println("\n[ERROR] Invalid choice. Please try again.");
                }
            } catch (InputMismatchException e) {
                System.out.println("\n[ERROR] Invalid input. Please enter a number.");
                this.scanner.nextLine(); 
                choice = -1;
            } catch (Exception e) {
                System.out.println("\n[ERROR] Operation failed: " + e.getMessage());
            }
        } while (choice != 0);
    }

    //  METHOD FOR FILE BENCHMARK
    private void runFileBenchmark() {
        final String INPUT_FILE = "UnsortedPatients.csv";
        final int MAX_FILE_PATIENTS = 10;
        
        System.out.println("\n--- Module 4: File-Based Sort ---");
        System.out.printf("1. Reading exactly %d patients from %s\n", MAX_FILE_PATIENTS, INPUT_FILE);
        
        Patient[] originalRecords = new Patient[MAX_FILE_PATIENTS];
        int count = 0;

        try {
            // Read patients from file
            count = readPatientsFromCSV(INPUT_FILE, originalRecords, MAX_FILE_PATIENTS);

            if (count != MAX_FILE_PATIENTS) {
                System.out.printf("[ERROR] File read failed. Expected %d records, found %d. Aborting.\n", MAX_FILE_PATIENTS, count);
                return;
            }

            //  Merge Sort 
            Patient[] mergeArr = copyArray(originalRecords, count);
            long startTimeMerge = System.nanoTime();
            DSASorts.mergeSort(mergeArr);
            long endTimeMerge = System.nanoTime();
            writePatientsToCSV("merge_sorted.csv", mergeArr, count, "Merge Sort");
            System.out.printf("[RESULT] Merge Sort completed and written to merge_sorted.csv (Time: %.2f ns)\n", (double)(endTimeMerge - startTimeMerge) / 1_000);

            //  Quick Sort 
            Patient[] quickArr = copyArray(originalRecords, count);
            long startTimeQuick = System.nanoTime();
            DSASorts.quickSort(quickArr);
            long endTimeQuick = System.nanoTime();
            writePatientsToCSV("quick_sorted.csv", quickArr, count, "Quick Sort");
            System.out.printf("[RESULT] Quick Sort completed and written to quick_sorted.csv (Time: %.2f ns)\n", (double)(endTimeQuick - startTimeQuick) / 1_000);

        } catch (FileNotFoundException e) {
            System.out.printf("[FATAL ERROR] Input file %s not found. Please ensure the file is present.\n", INPUT_FILE);
            System.out.println("[HINT] The expected file format is: ID,Name,Age,Department,Urgency,Duration(SortKey)");
        } catch (IOException e) {
            System.out.printf("[FATAL ERROR] An I/O error occurred: %s\n", e.getMessage());
        } catch (Exception e) {
            System.out.printf("[FATAL ERROR] An unexpected error occurred: %s\n", e.getMessage());
            e.printStackTrace();
        }
    }
    
    /** Helper to read patients from a CSV file into a fixed array. */
    private int readPatientsFromCSV(String filename, Patient[] records, int maxCapacity) throws FileNotFoundException {
        Scanner fileScanner = new Scanner(new File(filename));
        int count = 0;
        
        if (fileScanner.hasNextLine()) {
            fileScanner.nextLine(); // Skip header row
        }

        while (fileScanner.hasNextLine() && count < maxCapacity) {
            String line = fileScanner.nextLine();
            String[] data = line.split(",");
            
            try {
                if (data.length >= 6) {
                    String id = data[0].trim();
                    String name = data[1].trim();
                    int age = Integer.parseInt(data[2].trim());
                    String department = data[3].trim();
                    int urgency = Integer.parseInt(data[4].trim());
                    // Urgency Validation: CSVs must also conform to the 1-5 range
                    if (urgency < 1 || urgency > 5) {
                        throw new IllegalArgumentException("CSV urgency level must be between 1 and 5.");
                    }
                    
                    // The 6th field is the total treatment time, which serves as the sort key
                    double duration = Double.parseDouble(data[5].trim()); 
                    
                    records[count] = new Patient(id, name, age, department, urgency, duration);
                    count++;
                }
            } catch (NumberFormatException e) {
                System.out.println("[WARNING] Skipping malformed line in CSV: " + line);
            } catch (IllegalArgumentException e) {
                System.out.println("[WARNING] Skipping invalid patient data: " + e.getMessage());
            }
        }
        fileScanner.close();
        return count;
    }

    /** Helper to write patients from an array to a CSV file. */
    private void writePatientsToCSV(String filename, Patient[] records, int count, String sortType) throws IOException {
        PrintWriter pw = new PrintWriter(new FileWriter(filename));
        
        // Header
        pw.println("ID,Name,Age,Department,Urgency,Duration(SortKey)");
        
        for (int i = 0; i < count; i++) {
            Patient p = records[i];
            String line = String.format("%s,%s,%d,%s,%d,%.1f",
                                        p.getPatientId(), p.getName(), p.getAge(), 
                                        p.getDepartment(), p.getUrgency(), p.getDuration());
            pw.println(line);
        }
        
        pw.close();
        System.out.printf("2. Wrote %d sorted records (%s) to %s\n", count, sortType, filename);
    }

    /** Helper to create a shallow copy of the array for separate sorting runs. */
    private Patient[] copyArray(Patient[] original, int count) {
        Patient[] copy = new Patient[count];
        // Only copy the portion of the array that contains actual patient objects
        for(int i = 0; i < count; i++) {
            copy[i] = original[i]; 
        }
        return copy;
    }


    
    private void runAutomatedBenchmark() {
        System.out.println("Hospital Sorts.");
        System.out.println("-----------------------------------------------------------------------\n");
        
        int[] sizes = {100, 500, 1000};
        String[] types = {"Random", "Nearly Sorted", "Reversed"};
        
        System.out.println("Module 4: Sorting Patient Records Benchmarking (Time Analysis)");
        System.out.println("-------------------------------------------------------");
        
        // Table Header
        System.out.printf("| %-8s | %-15s | %-15s | %-15s |\n", "Size (N)", "Input Type", "Merge Time (ns) ", "Quick Time (ns) ");
        System.out.println("|----------|-----------------|-----------------|-----------------|");

        // Run benchmarks for all sizes and types
        for (int size : sizes) {
            for (String type : types) {
                Result result = runBenchmark(size, type);
                System.out.printf("| %-8d | %-15s | %-15.0f | %-15.0f |\n", 
                                 size, result.inputType, (double)result.mergeTime / 1_000, (double)result.quickTime / 1_000);
            }
        }
        
        System.out.println("\n-------------------------------------------------------");
        printAnalysis();
        
        System.out.println("\n[INFO] Benchmarking complete. Press Enter to return to Module 4 Menu.");
        this.scanner.nextLine(); 
    }
    
    private Result runBenchmark(int size, String type) {
        Result result = new Result();
        long totalMergeTime = 0;
        long totalQuickTime = 0;
        result.inputType = type;

        for (int i = 0; i < REPETITIONS; i++) {
           
            Patient[] original = generateData(size, type, SEED + i); 
            
            //  Merge Sort Timing 
            Patient[] arrMerge = new Patient[original.length];
            for (int j = 0; j < original.length; j++) {
                arrMerge[j] = original[j];
            }
            long startTime = System.nanoTime();
            DSASorts.mergeSort(arrMerge); 
            long endTimeMerge = System.nanoTime();
            totalMergeTime += (endTimeMerge - startTime);


            //  Quick Sort Timing 
            Patient[] arrQuick = new Patient[original.length];
            for (int j = 0; j < original.length; j++) {
                arrQuick[j] = original[j];
            }
            startTime = System.nanoTime();
            DSASorts.quickSort(arrQuick); 
            long endTimeQuick = System.nanoTime();
            totalQuickTime += (endTimeQuick - startTime);
        }

        result.mergeTime = totalMergeTime / REPETITIONS;
        result.quickTime = totalQuickTime / REPETITIONS;
        
        return result; 
    }

    private void runModule4InteractiveMenu() {
        System.out.println("\n=======================================================");
        System.out.println("  MODULE 4: INTERACTIVE PATIENT SORT");
        System.out.println("  Sorting Metric: Total Treatment Time (Path Time + Est. Duration)");
        System.out.println("=======================================================");
        
        Patient[] records = inputManualPatients();

        if (records.length == 0) {
            System.out.println("[INFO] No patients entered. Returning to menu.");
            return;
        }

        int sortChoice = -1;
        boolean continueSortMenu = true;

        while (continueSortMenu) {
            try {
                System.out.println("\n--- Select Sorting Algorithm ---");
                System.out.println("1. Merge Sort");
                System.out.println("2. Quick Sort");
                System.out.println("0. Back to Module 4 Menu");
                System.out.print("Enter choice: ");
                sortChoice = this.scanner.nextInt();
                this.scanner.nextLine(); 

                if (sortChoice == 0) {
                    continueSortMenu = false; 
                } else {
                    long startTime = System.nanoTime();
                    
                    switch (sortChoice) {
                        case 1: 
                            DSASorts.mergeSort(records); 
                            System.out.println("\n[RESULT] Merge Sort Complete."); 
                            continueSortMenu = false; 
                            break;
                        case 2: 
                            DSASorts.quickSort(records); 
                            System.out.println("\n[RESULT] Quick Sort Complete."); 
                            continueSortMenu = false; 
                            break;
                        default: System.out.println("\n[ERROR] Invalid choice. Please select 1, 2, or 0."); break;
                    }

                    if (!continueSortMenu) {
                        long endTime = System.nanoTime();
                        System.out.printf("Time taken: %.2f \n", (double)(endTime - startTime) / 1_000);
                        displaySortedPatients(records);
                    }
                }
            } catch (InputMismatchException e) {
                System.out.println("\n[ERROR] Invalid input. Please enter a number.");
                this.scanner.nextLine(); 
            } catch (Exception e) {
                System.out.println("\n[ERROR] Sorting failed: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }
    
    /** * Helper to prompt the user for a list of patients. 
     * Uses a fixed array to adhere to the no-collection-class constraint.
     */
    private Patient[] inputManualPatients() {
        Patient[] records = new Patient[MAX_MANUAL_PATIENTS];
        final String START_DEPARTMENT = "Emergency";
        int patientCount = 0; 
        
        System.out.println("\n--- Enter Patient Records (Max " + MAX_MANUAL_PATIENTS + ") ---");
        System.out.println("--- Enter 'stop' for Patient ID to finish ---");
        
        boolean continueInput = true; 
        
        while (continueInput && patientCount < MAX_MANUAL_PATIENTS) {
            try {
                System.out.print("\nPatient ID (or 'stop'): ");
                String id = this.scanner.nextLine().trim();
                
                if (id.equalsIgnoreCase("stop") || id.isEmpty()) {
                    continueInput = false; 
                } else {
                    System.out.print("Name: ");
                    String name = this.scanner.nextLine().trim();
                    System.out.print("Age: ");
                    int age = this.scanner.nextInt();
                    this.scanner.nextLine(); 

                    System.out.print("Required Department (e.g., ICU, Radiology): ");
                    String department = this.scanner.nextLine().trim();
                    System.out.print("Estimated Treatment Time (Duration in min, e.g., 30.0): ");
                    double estDuration = this.scanner.nextDouble();
                    this.scanner.nextLine();

                    // 1. Calculate Shortest Path Time
                    String shortestPathResult = this.hospitalMap.shortestPathDijkstra(START_DEPARTMENT, department);
                    double pathTime = 0.0;
                    
                    String[] parts = shortestPathResult.split("Total Walking Time: ");
                    if (parts.length > 1) {
                        pathTime = Double.parseDouble(parts[1].split(" minutes")[0]);
                    } 
                    
                    // 2. Calculate Total Treatment Time (the new sorting key)
                    double totalTreatmentTime = pathTime + estDuration;
                    
                    System.out.printf("-> Calculated Path Time: %.1f min. Total Treatment Time (Sort Key): %.1f min.\n", pathTime, totalTreatmentTime);
                    
                    // Store in fixed array. Patient's duration field holds the Total Treatment Time for sorting.
                    // Urgency is hardcoded to 5  as it is not the primary sorting key in this module.
                    Patient newPatient = new Patient(id, name, age, department, 5, totalTreatmentTime);
                    records[patientCount] = newPatient;
                    patientCount++;
                }

            } catch (InputMismatchException e) {
                System.out.println("[ERROR] Invalid number format. Please try again.");
                this.scanner.nextLine();
            } catch (Exception e) {
                System.out.println("[ERROR] Unexpected error during input: " + e.getMessage());
            }
        }
        
        if (patientCount == MAX_MANUAL_PATIENTS) {
             System.out.println("[WARNING] Maximum number of patients (" + MAX_MANUAL_PATIENTS + ") reached.");
        }
        System.out.printf("\n[INFO] %d patient records finalized for sorting.\n", patientCount);
        
        // Trim the array
        Patient[] finalRecords = new Patient[patientCount];
        for (int i = 0; i < patientCount; i++) {
            finalRecords[i] = records[i];
        }
        
        return finalRecords; 
    }
    
    private void displaySortedPatients(Patient[] records) {
        System.out.println("\n=======================================================");
        System.out.println("               SORTED PATIENT RECORDS");
        System.out.println("=======================================================");
        if (records.length == 0) {
             System.out.println("No records to display.");
             return;
        }

        System.out.printf("| %-5s | %-20s | %-8s | %-12s |\n", 
                          "ID", "Name", "Age", "Total Time (min)");
        System.out.println("|-------|----------------------|----------|----------------|");

        for (Patient p : records) {
            // getDuration() is assumed to return the Total Treatment Time (the sorting key)
            System.out.printf("| %-5s | %-20s | %-8d | %-12.1f |\n", 
                              p.getPatientId(), p.getName(), p.getAge(), p.getDuration());
        }
        System.out.println("|-------|----------------------|----------|----------------|");
    }
    
    private Patient[] generateData(int size, String type, int seed) {
        Random rand = new Random(seed);
        Patient[] arr = new Patient[size];
        
        for (int i = 0; i < size; i++) {
            double duration;
            if (type.equals("Random")) {
                duration = rand.nextDouble() * MAX_DURATION + 0.1;
            } else if (type.equals("Reversed")) {
                duration = MAX_DURATION - ((double)i / size) * MAX_DURATION;
            } else { // Nearly Sorted (Base ascending order)
                duration = ((double)i / size) * MAX_DURATION + 0.1;
            }

            // Urgency generated between 1 and 5 
            arr[i] = new Patient(
                String.valueOf(i + 100), "Name" + i, rand.nextInt(80) + 1, "ER_Auto", 
                rand.nextInt(5) + 1, duration 
            );
        }
        
        if (type.equals("Nearly Sorted")) {
            int displacements = (int) (size * 0.10); 
            for (int i = 0; i < displacements; i++) {
                int idx1 = rand.nextInt(size);
                int idx2 = rand.nextInt(size);
                Patient temp = arr[idx1];
                arr[idx1] = arr[idx2];
                arr[idx2] = temp;
            }
        }
        
        return arr; 
    }
    
    private void printAnalysis() {
        System.out.println("Module 4 Analysis and Reflection (Automated Benchmark)");
        System.out.println("-------------------------------------------------------");
        
        System.out.println("1. Quick Sort Pivot Strategy Justification:");
        System.out.println("The **Median-of-Three** pivot strategy was chosen for Quick Sort. This method selects the median value among the first, middle, and last elements of the sub-array as the pivot. This substantially reduces the probability of hitting the worst-case scenario (O(n^2)) on ordered or nearly ordered inputs (like the 'Nearly Sorted' or 'Reversed' cases).");
        
        System.out.println("\n2. Merge Sort Implementation and Stability:");
        System.out.println("The **Top-Down (Recursive)** implementation was chosen for Merge Sort. This approach guarantees consistent O(n log n) performance regardless of the input condition. A key feature is its **stability**.");

        System.out.println("\n3. Performance Analysis Summary:");
        System.out.println(" - **Quick Sort (Median-of-Three)**: Generally the fastest in practice on **Random** data.");
        System.out.println(" - **Merge Sort**: Exhibits high consistency across all input types (Random, Nearly Sorted, Reversed).");
    }
}