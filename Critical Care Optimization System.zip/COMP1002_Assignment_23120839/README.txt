*** NAME:N.A.S.S.WICKRAMARATNE
*** CURTIN ID:23120839
*** MODULE:COMP1002

**The project consists of the following Java files:**

HospitalMenu.java

Patient.java

DSAGraph.java

DSAHashTable.java

DSAHeap.java

DSASorts.java

HospitalGraphTest.java (Module 1 Test Driver)

HospitalHashTableTest.java (Module 2 Test Driver)

HospitalHeapTest.java (Module 3 Test Driver)

HospitalSortTest.java (Module 4 Test Driver)

DSAStack.java (Used in Module 1)

DSAQueue.java (Used in Module 1)

DSALinkedlist.java (Used in Module 1)

DSAListNode.java (Used in Module 1)

**The project also contains the following .csv files to load data into certain modules**

PatientToHash.csv (Used by module 2 File loading option and will create an output file called Hashtable.csv)

TriggerResize.csv (Used by module 2 Resize trigger option to show how the hashtable is resized and will create output file called    
                   ResizeHashTable.csv)

UnsortedPatients.csv (Used by module 4 file loading option to provide unsorted data and output files merge_sorted.csv and quick_sorted.csv 
                     will be created)

**It should be noted that the data required to perform DFS,BFS,Dijikstra are populated in the HospitalMenu.java file it self and some data are provided for the other modules as well.**

**Moreover, the data required for the test harnesses of each module are provided in the test harness file of each module itself.**

**Module Instructions (Compilation and Execution)**

Compile All Files:
    javac *.java

Execute the Main Menu:
   java HospitalMenu

Execute the Module 01 Test Harness :
   java HospitalGraphTest

Execute the Module 02 Test Harness:
   java HospitalHashTableTest

Execute the Module 03 Test Harness:
   java HospitalHeapTest

Execute the Module 04 Test Harness:
   java HospitalSortTest

**Main Menu Navigation: Once the main menu is displayed, select the corresponding option to access each module's functionality:**

Enter 1 for the Graph-Based Menu (Module 1: Hospital Map).

Enter 2 for the Hash Table-Based Menu (Module 2: Patient Database).

Enter 3 for the Heap-Based Menu (Module 3: Emergency Scheduler).

Enter 4 for the Sorting Algorithm Menu (Module 4: Treatment Duration Analysis).

Enter 0 to exit the system.

**Functions of Modules**

The core functionality is split across the data structure classes and the shared Patient object.

*Shared Class:*

Class	        Functions	       Description
Patient.java	Patient()              (x2)Constructors (5-arg and 6-arg).
	        getUrgency()	       Returns the patient's urgency score (1-5).
	        getDuration()	       Returns the estimated treatment duration (double).
	        setTreatmentStatus()   Updates the patient's status (Waiting, Treated, Discharged).
	        toString()	       Provides a formatted string representation of the patient.

*Module 01:*
Class	                  Functions
DSAGraph.java	          addNode(), addEdge(), getNode(), hasNode()
	                  breadthFirstSearch(), depthFirstSearch(), findShortestPath()
	                  displayAsMatrix(), displayAsList() (Graph traversal and display)
	                  loadFromFile(), saveToFile() (File I/O for graph structure)
HospitalGraphTest.java	  runTestTrace() (Test driver for graph functionality)

*Module 02:
Class	                      Functions
DSAHashTable.java	      put(key, value) (Insertion)
	                      get(key) (Search/Retrieval)
	                      remove(key) (Deletion)
	                      hasKey(key), getCount(), resize() (Helper/Utility methods)
	                      loadFromFile(), saveToFile() (File I/O for patient data)
HospitalHashTableTest.java    runTestTrace() (Test driver for Hash Table operations)

*Module 03:*
Class                     Functions
DSAHeap.java              add(priority, value) (Insert/Enqueue)
                          remove() (Extract Max/Dequeue)
                          heapify(), trickleUp(), trickleDown() (Heap maintenance methods)
                          getEntry(), getCount()
HospitalHeapTest.java,    runTestTrace(), insertRequest(), extractPriorityCase() (Test driver for Heap operations)

*Module 04:*
Class                     Functions
DSASorts.java             mergeSort(Patient[] arr)
                          quickSort(Patient[] arr) (Uses Median-of-Three pivot strategy)
                          merge(), findMedianOfThree(), doPartitioning() (Helper methods)
HospitalSortTest.java     main(), runBenchmark() (Executes sorting tests/analysis)
                          checkSorted(), generateData() (Data generation and verification)
                          printAnalysis() (Displays performance reflection)



