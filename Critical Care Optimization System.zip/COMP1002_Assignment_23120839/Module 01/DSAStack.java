/* Author:Nallaperuma Arachchilage Spencer Sterling Wickramaratne
 * Curtin ID: 23120839
 * References: Lecture slides and https://www.geeksforgeeks.org and practical 03 submssion*/
                 
public class DSAStack {

    private Object[] stackArray;
    private int count;
    private static final int DEFAULT_CAPACITY = 100;

    public DSAStack() {
        stackArray = new Object[DEFAULT_CAPACITY];
        count = 0;
    }

    public DSAStack(int capacity) {
        stackArray = new Object[capacity];
        count = 0;
    }

    public int getCount() {
        return count;
    }

    public boolean isEmpty() {
        return count == 0;
    }

    public boolean isFull() {
        return count == stackArray.length;
    }

    public void push(Object value) {
        if (isFull()) {
            throw new IllegalStateException("Stack is full");
        }
        stackArray[count] = value;
        count++;
    }

    public Object pop() {
        if (isEmpty()) {
            throw new IllegalStateException("Stack is empty");
        }
        Object value = stackArray[count - 1];
        stackArray[count - 1] = null; // Optional: helps with garbage collection
        count--;
        return value;
    }

    public Object top() {
        if (isEmpty()) {
            throw new IllegalStateException("Stack is empty");
        }
        return stackArray[count - 1];
    }

     /**
         * Returns a string representation of the stack's contents.
        
         */
       
        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append("[");
            for (int i = 0; i < count; i++) {
                sb.append(stackArray[i]);
                if (i < count - 1) {
                    sb.append(", ");
                }
            }
            sb.append("]");
            return sb.toString();
        }
}
