/* Author:Nallaperuma Arachchilage Spencer Sterling Wickramaratne
 * Curtin ID: 23120839
 * DSAGraph.java - A graph implementation for the Hospital System.
 * References: Lecture slides and practical 06 submission
 * Citation:Edsger W. Dijkstra (1959), "A Note on Two Problems in Connexion with Graphs"
 * and https://www.geeksforgeeks.org/dsa/dijkstras-shortest-path-algorithm-greedy-algo-7/

 */

import java.util.Objects;

public class DSAGraph {
    // MAIN GRAPH CLASS FIELDS

    private DSALinkedList vertices;
    private int edgeCount;
    private boolean isDirected;


    //  FIELDS FOR DFS CYCLE PATH TRACKING

    private String cyclePathOutput = null;
    private DSAHashTable cyclePredecessors;

    //  INNER CLASS: DSAGraphVertex 
    // Made public static so DSAHeap can reference it (e.g., DSAGraph.DSAGraphVertex)

    public static class DSAGraphVertex {

        private String label;
        private DSALinkedList edges;
        private boolean visited;
        private double distance;
        private DSAGraphVertex predecessor;

        public DSAGraphVertex(String inLabel) {

            this.label = inLabel;
            // Use custom DSALinkedList for edges
            this.edges = new DSALinkedList();
            this.visited = false;
            this.distance = Double.MAX_VALUE;
            this.predecessor = null;
        }

        public String getLabel() { return label; }
        public DSALinkedList getEdges() { return edges; }
        public void setVisited(boolean isVisited) { this.visited = isVisited; }
        public boolean isVisited() { return visited; }
        public void setDistance(double distance) { this.distance = distance; }
        public double getDistance() { return distance; }
        public void setPredecessor(DSAGraphVertex predecessor) { this.predecessor = predecessor; }
        public DSAGraphVertex getPredecessor() { return predecessor; }
        public void addEdge(DSAGraphEdge edge) {

            // Use insertLast from custom DSALinkedList
            this.edges.insertLast(edge);
        }

        public String toString() {
            return label;
        }
        public boolean equals(Object o) {

            boolean isEqual = false; // Initialize result variable
            if (this == o) {
                isEqual = true;

            } else if (o != null && getClass() == o.getClass()) {
                DSAGraphVertex that = (DSAGraphVertex) o;
                // The core comparison is done here

                isEqual = Objects.equals(label, that.label);
            }
            return isEqual;
        }
        public int hashCode() {
            return Objects.hash(label);

        }

    }

    // INNER CLASS: DSAGraphEdge 
    private class DSAGraphEdge {
        private DSAGraphVertex sink;
        private double weight;

        public DSAGraphEdge(DSAGraphVertex inSink, double inWeight) {
            this.sink = inSink;
            this.weight = inWeight;

        }

        public DSAGraphVertex getSink() { return sink; }
        public double getWeight() { return weight; }

        // Needed for edge deletion logic

        public boolean equals(Object o) {
            boolean isEqual = false; // Initialize the result variable
            if (this == o) {
                isEqual = true;

            } else if (o != null && getClass() == o.getClass()) {

                DSAGraphEdge that = (DSAGraphEdge) o;
                // Edges are considered equal if their sink vertices are equal
                isEqual = sink.equals(that.sink);

            }

            return isEqual;
        }
    }
    //  CONSTRUCTOR 

    public DSAGraph(boolean directed) {
        this.vertices = new DSALinkedList();

        this.edgeCount = 0;
        this.isDirected = directed;

    }

    //  HELPER METHOD: Find Vertex by Label 
    private DSAGraphVertex getVertex(String label) throws IllegalArgumentException {
        DSAGraphVertex foundVertex = null;
        Object[] vertexArray = this.vertices.toArray();
        int i = 0;
        // Loop runs until end of array or vertex is found

        while (i < vertexArray.length && foundVertex == null) {
            DSAGraphVertex vertex = (DSAGraphVertex) vertexArray[i];
            if (vertex.getLabel().equals(label)) {
                foundVertex = vertex;

            }
            i++;
        }
        if (foundVertex == null) {
            // Throw exception if vertex was not found after checking all
            throw new IllegalArgumentException("Vertex not found: " + label);
        }
        return foundVertex;

    }

    //  CORE OPERATIONS REQUIRED BY TEST HARNESS 
    public void addVertex(String label) {
        if (hasVertex(label)) {
            throw new IllegalArgumentException("Vertex already exists: " + label);

        }
        this.vertices.insertLast(new DSAGraphVertex(label));
    }

    /**
     * Adds a symmetrical edge pair (for undirected compatibility).
     */

    public void addEdge(String label1, String label2, double weight) {

        DSAGraphVertex v1 = getVertex(label1);
        DSAGraphVertex v2 = getVertex(label2);

        boolean isDuplicate = false;
        // Check for duplicate edge
        Object[] v1Edges = v1.getEdges().toArray();
        int i = 0;
        // Loop condition uses the flag 
        while (i < v1Edges.length && !isDuplicate) {

            Object obj = v1Edges[i];
            DSAGraphEdge edge = (DSAGraphEdge) obj;
            if (edge.getSink().getLabel().equals(label2)) {

                isDuplicate = true;
            }
            i++;

        }
        if (!isDuplicate) {

            // Add edge from v1 to v2
            v1.addEdge(new DSAGraphEdge(v2, weight));
            // Add symmetrical edge from v2 to v1
            v2.addEdge(new DSAGraphEdge(v1, weight));
            this.edgeCount++;
        }
        // Single return implied at end of void function
    }


    public int getEdgeCount() {
        return this.edgeCount;
    }

    /**
     * Returns an instance of the custom DSALinkedList containing neighbor labels (String).
     */
    public DSALinkedList getAdjacent(String label) {
        DSAGraphVertex vertex = getVertex(label);
        DSALinkedList adjacentList = new DSALinkedList();
        Object[] edgesArray = vertex.getEdges().toArray();
        for (Object obj : edgesArray) {
            DSAGraphEdge edge = (DSAGraphEdge) obj;
            adjacentList.insertLast(edge.getSink().getLabel());
        }
        return adjacentList;

    }
    /**
     * Removes the symmetrical edge pair.
     */
    public void deleteEdge(String label1, String label2) {
        DSAGraphVertex v1 = getVertex(label1);
        DSAGraphVertex v2 = getVertex(label2);
        // Create dummy edge objects for removal based on sink vertex
        DSAGraphEdge edge1 = new DSAGraphEdge(v2, 0);

        DSAGraphEdge edge2 = new DSAGraphEdge(v1, 0);
        // Use custom DSALinkedList.remove()

        boolean removed1 = v1.getEdges().remove(edge1);
        boolean removed2 = v2.getEdges().remove(edge2);
        if (removed1 || removed2) {
            this.edgeCount--;
        } else {
            throw new IllegalArgumentException("Edge not found between " + label1 + " and " + label2);
        }
        // Single return implied at end of void function
    }

    public boolean hasVertex(String label) {
        boolean exists = false; // Initialize result variable
        try {
            getVertex(label);
            exists = true;
        } catch (IllegalArgumentException e) {
            exists = false;
        }
        return exists; 
    }

    public int getVertexCount() {
        return this.vertices.getCount();
    }

    // DISPLAY / UTILITY 
    public void displayAsList() {

        final int COL1_WIDTH = 25;
        final int COL2_OFFSET = COL1_WIDTH + 3;
        System.out.println("--- Adjacency List ---");
        System.out.printf("%-" + COL1_WIDTH + "s | %s\n", "Source Vertex", "Adjacent Edges (Target, Weight)");
        String headerSeparator = "";
        for (int i = 0; i < COL1_WIDTH; i++) headerSeparator += "-";
        headerSeparator += "-+--";
        for (int i = 0; i < 50; i++) headerSeparator += "-";
        System.out.println(headerSeparator);

        // End of displayAsList modification
        Object[] vertexArray = this.vertices.toArray();

        for (Object obj : vertexArray) {
            DSAGraphVertex vertex = (DSAGraphVertex) obj;
            Object[] edgesArray = vertex.getEdges().toArray();
            if (edgesArray.length == 0) {
                System.out.printf("%-" + COL1_WIDTH + "s | %s\n", vertex.getLabel(), "No Edges");

            } else {

                DSAGraphEdge firstEdge = (DSAGraphEdge) edgesArray[0];
                System.out.printf("%-" + COL1_WIDTH + "s | (%s, %.1f)\n",

                    vertex.getLabel(),
                    firstEdge.getSink().getLabel(),
                    firstEdge.getWeight());
                for (int i = 1; i < edgesArray.length; i++) {
                    DSAGraphEdge edge = (DSAGraphEdge) edgesArray[i];
                    String padding = new String(new char[COL2_OFFSET]).replace('\0', ' ');
                    System.out.printf("%s(%s, %.1f)\n",
                        padding,
                        edge.getSink().getLabel(),
                        edge.getWeight());
                }
            }

            System.out.println(headerSeparator);
        }
    }
    private void clearVisited() {

        Object[] vertexArray = this.vertices.toArray();

        for (Object obj : vertexArray) {
            DSAGraphVertex vertex = (DSAGraphVertex) obj;
            vertex.setVisited(false);
        }
    }

    //  BFS (Breadth First Search)
    public String breadthFirstSearchLevelOutput(String startLabel) {

        clearVisited();

        DSAGraphVertex startVertex = getVertex(startLabel);
        // Assuming DSACircularQueue and DSAHashTable exist
        DSACircularQueue queue = new DSACircularQueue(this.vertices.getCount());
        DSAHashTable levelMap = new DSAHashTable(this.vertices.getCount());
        String output = "";
        queue.enqueue(startVertex);
        startVertex.setVisited(true);
        levelMap.put(startVertex.getLabel(), 0);
        int currentLevel = -1;
        while (!queue.isEmpty()) {

            DSAGraphVertex u = (DSAGraphVertex) queue.dequeue();
            int uLevel = (int) levelMap.get(u.getLabel());
            if (uLevel > currentLevel) {
                if (currentLevel != -1) {
                    output += "]"; // Close previous level
                }
                currentLevel = uLevel;
                // Use concatenation for new line and level header
                output += "\nLevel " + currentLevel + ": [";

            }
            // Check if  a comma is needeed
            if (output.length() > 0 && output.charAt(output.length() - 1) != '[') {
                output += ", ";
            }
            output += u.getLabel(); // Append current vertex label
            Object[] edgesArray = u.getEdges().toArray();
            for (Object obj : edgesArray) {
                DSAGraphEdge edge = (DSAGraphEdge) obj;
                DSAGraphVertex v = edge.getSink();
                if (!v.isVisited()) {
                    v.setVisited(true);
                    levelMap.put(v.getLabel(), uLevel + 1);
                    queue.enqueue(v);
                }
            }
        }

        if (currentLevel != -1) {
            output += "]"; // Close the final level
        }
        output += "\n";
        return output;

    }

    //  DFS (Depth First Search) for Cycle Detection
    public String depthFirstSearchCycleDetection(String startLabel) {

        String result;
        clearVisited();
        DSAGraphVertex startVertex = getVertex(startLabel);
        this.cyclePredecessors = new DSAHashTable(this.vertices.getCount());
        DSAHashTable recursionStack = new DSAHashTable(this.vertices.getCount());
        this.cyclePathOutput = null;
        boolean cycleFound = dfsRecursiveCycleCheck(startVertex, null, recursionStack);
        if (cycleFound) {

            result = "[RESULT] CYCLE DETECTED in the map (or back edge found in directed graph).\nCycle Exists: True";

            if (this.cyclePathOutput != null) {

                result += "\nCycle Found: " + this.cyclePathOutput;

            }

        } else {
            result = "[RESULT] No cycle detected reachable from " + startLabel + ".\nCycle Exists: False";
        }
        return result;
    }

    private boolean dfsRecursiveCycleCheck(DSAGraphVertex u, DSAGraphVertex parent, DSAHashTable recursionStack) {
        boolean cycleFound = false;
        u.setVisited(true);
        recursionStack.put(u.getLabel(), true);
        Object[] edgesArray = u.getEdges().toArray();
        // Use a loop condition that allows early termination via the cycleFound variable

        for (int i = 0; i < edgesArray.length && !cycleFound; i++) {
            DSAGraphEdge edge = (DSAGraphEdge) edgesArray[i];
            DSAGraphVertex v = edge.getSink();
            // Check if a cycle was found deeper in the recursion

            if (this.cyclePathOutput != null) {
                cycleFound = true;

            } else if (!v.isVisited()) {

                this.cyclePredecessors.put(v.getLabel(), u);
                if (dfsRecursiveCycleCheck(v, u, recursionStack)) {
                    cycleFound = true;
                }

            } else if (v != parent) {

                if (this.isDirected ? recursionStack.hasKey(v.getLabel()) : true) {
                    //  Cycle Reconstruction 

                    DSALinkedList cycle = new DSALinkedList();
                    cycle.insertFirst(u.getLabel());
                    DSAGraphVertex curr = u;
                    boolean cycleStartFound = false;
                    while (this.cyclePredecessors.hasKey(curr.getLabel()) && !curr.equals(v) && !cycleStartFound) {

                        try {

                            DSAGraphVertex next = (DSAGraphVertex) this.cyclePredecessors.get(curr.getLabel());

                            if (next != null) {
                                curr = next;
                                cycle.insertFirst(curr.getLabel());

                            } else {
                                cycleStartFound = true; // Stop loop if predecessor is null

                            }
                        } catch (IllegalArgumentException e) {
                            cycleStartFound = true; // Stop loop if key not found
                        }
                    }

                    if (curr != null && !cycle.peekFirst().equals(v.getLabel())) {
                        cycle.insertFirst(v.getLabel());
                    }

                    cycle.insertLast(v.getLabel());

                    // Manual string building (replaces String.join)
                    Object[] pathObjects = cycle.toArray();
                    String pathStr = "";
                    for(int j = 0; j < pathObjects.length; j++) {
                        pathStr += (String) pathObjects[j];
                        if (j < pathObjects.length - 1) {
                            pathStr += " -> ";

                        }
                    }
                    this.cyclePathOutput = pathStr;

                    // End of cyclePathOutput modification
                    cycleFound = true;
                }
            }
        }
        if (!cycleFound) {

            recursionStack.remove(u.getLabel());

        }
        return cycleFound;

    }

    //  DIJKSTRA'S SHORTEST PATH

    public String shortestPathDijkstra(String startLabel, String endLabel) {

        // 1. Initialization

        Object[] vertexArray = this.vertices.toArray();

        for (Object obj : vertexArray) {
            DSAGraphVertex v = (DSAGraphVertex) obj;
            v.setDistance(Double.MAX_VALUE);
            v.setPredecessor(null);

        }

        DSAGraphVertex start = getVertex(startLabel);
        DSAGraphVertex end = getVertex(endLabel);
        start.setDistance(0.0);
        //  Custom DSAHeap  (Min-Heap)
        // true for isMinHeap, as Dijkstra's needs minimum distance
        DSAHeap priorityQueue = new DSAHeap(this.vertices.getCount(), true);
        // Add all vertices to the heap with their initial distance as priority
        for (Object obj : vertexArray) {
            DSAGraphVertex vertex = (DSAGraphVertex) obj;
            // The vertex object is the value; the distance is the priority.
            // DSAHeap uses the vertex's label (via getLabel()) as the key for its indexTable.
            priorityQueue.add(vertex.getDistance(), vertex);

        }
        // 2. Main Loop

        DSAGraphVertex u = null;
        boolean targetFound = false;
        // Loop runs as long as the queue is not empty AND the target hasn't been processed

        while (!priorityQueue.isEmpty() && !targetFound) {
            DSAHeap.DSAHeapEntry entry = priorityQueue.remove();
            u = (DSAGraphVertex) entry.getValue();

            if (u.equals(end) || u.getDistance() == Double.MAX_VALUE) {
                targetFound = true;
            }
            if (!targetFound) {
                // 3. Relaxation Step
                Object[] edgesArray = u.getEdges().toArray();

                for (Object obj : edgesArray) {
                    DSAGraphEdge edge = (DSAGraphEdge) obj;
                    DSAGraphVertex v = edge.getSink();
                    double newDist = u.getDistance() + edge.getWeight();
                    if (newDist < v.getDistance()) {
                        v.setDistance(newDist);
                        v.setPredecessor(u);
                        // Decrease-Key operation using the custom DSAHeap
                        // This uses the DSAHeap's updatePriority(Object value, double newPriority) overload
                        priorityQueue.updatePriority(v, newDist);
                    }
                }
            }
        }

        // 4. Result Construction
        return buildPathString(start, end);
    }

    private String buildPathString(DSAGraphVertex start, DSAGraphVertex end) {
        String result;
        if (end.getDistance() == Double.MAX_VALUE) {

            // Replacement for String.format
            result = "[RESULT] Target department '" + end.getLabel() + "' is unreachable from '" + start.getLabel() + "'.";
        } else {
            DSALinkedList path = new DSALinkedList();
            DSAGraphVertex current = end;


            boolean pathComplete = false;
            while (current != null && !pathComplete) {
                path.insertFirst(current.getLabel());
                if (current.equals(start)) {
                    pathComplete = true;
                } else {
                    current = current.getPredecessor();
                }
            }

            Object[] pathObjects = path.toArray();
            String pathStr = "";
            // Manual path string construction
            for (int i = 0; i < pathObjects.length; i++) {
                pathStr += pathObjects[i];
                if (i < pathObjects.length - 1) {
                    pathStr += " -> ";
                }

            }

            double distance = end.getDistance();
            // Simple approach to round to one decimal place if absolutely required:
            long rounded = Math.round(distance * 10);
            double formattedDistance = (double) rounded / 10.0;
            result = "[RESULT] Shortest Path: " + pathStr + "\nTotal Walking Time: " + formattedDistance + " minutes";
        }
        return result;

    }

}