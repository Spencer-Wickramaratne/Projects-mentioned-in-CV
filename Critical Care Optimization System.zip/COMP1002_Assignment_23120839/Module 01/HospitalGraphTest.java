/* Author:Nallaperuma Arachchilage Spencer Sterling Wickramaratne
 * Curtin ID: 23120839
 * HospitalGraphTest.java
 * Comprehensive test harness for DSAGraph focusing on a hospital navigation scenario.
 * NOTE: This file includes embedded definitions for DSAHeap, DSAHashTable, DSALinkedList, 
 * and related classes to be fully self-contained.
 */
public class HospitalGraphTest {
    
    private static int totalTests = 0;
    private static int passedTests = 0;
    
    public static void main(String[] args) {
        System.out.println("=================================================");
        System.out.println("  Module 1: Hospital Navigation System Test (Graph)");
        System.out.println("=================================================");
     
        // NOTE: Graph behaves as Undirected due to fix in DSAGraph.java
        DSAGraph hospitalMap = new DSAGraph(true); 
        setupHospitalGraph(hospitalMap);
        
        // 1. Core Structure and Integrity Tests 
        testSection("1. Core Graph Structure Tests");
        testGraphMetrics(hospitalMap);
        testEdgeManagement(hospitalMap);
        
        // 2. Algorithm Tests 
        testSection("2. Graph Algorithm Tests (Weight-Based Traversal)");
        testBFS(hospitalMap);
        testDFS(hospitalMap);
        testDijkstra(hospitalMap);
        
        // 3. Required Output 
        testSection("3. Required Outputs (Visualisation & Algorithms)");
        hospitalMap.displayAsList();

        System.out.println("\n--- BFS Results (Start: Emergency) ---");
        try {
            System.out.println(hospitalMap.breadthFirstSearchLevelOutput("Emergency"));
        } catch (Exception e) { System.err.println("BFS Error: " + e.getMessage()); }
        
        System.out.println("\n--- DFS Cycle Detection (Start: Emergency) ---");
        try {
            System.out.println(hospitalMap.depthFirstSearchCycleDetection("Emergency"));
        } catch (Exception e) { System.err.println("DFS Error: " + e.getMessage()); }

        System.out.println("\n--- Dijkstra's Shortest Path (Cited: Edsger W. Dijkstra, 1959) ---");
        try {
            System.out.println("Emergency -> Laboratories: " + hospitalMap.shortestPathDijkstra("Emergency", "Laboratories"));
            System.out.println("Pharmacy -> Outpatient Units: " + hospitalMap.shortestPathDijkstra("Pharmacy", "Outpatient Units")); 
            System.out.println("Emergency -> Wards (Isolated): " + hospitalMap.shortestPathDijkstra("Emergency", "Wards")); 
        } catch (Exception e) { System.err.println("Dijkstra Error: " + e.getMessage()); }

        //  Final Summary 
        testSection("4. Test Summary");
        System.out.printf("Total Tests Performed: %d\n", totalTests);
        System.out.printf("Tests Passed: %d\n", passedTests);
        System.out.printf("Tests Failed: %d\n", totalTests - passedTests);
        System.out.println("=================================================");
    }
    
    private static void testSection(String title) {
        System.out.println("\n-------------------------------------------------");
        System.out.println(title);
        System.out.println("-------------------------------------------------");
    }

    private static void assertTrue(boolean condition, String message) {
        totalTests++;
        if (condition) {
            System.out.println("PASS: " + message);
            passedTests++;
        } else {
            System.err.println("FAIL: " + message);
        }
    }
    
    /** Sets up the specific hospital map structure. */
    private static void setupHospitalGraph(DSAGraph graph) {
        // 8 Departments
        graph.addVertex("Emergency"); 
        graph.addVertex("ICU"); 
        graph.addVertex("Pharmacy"); 
        graph.addVertex("Radiology"); 
        graph.addVertex("Laboratories"); 
        graph.addVertex("Operating Theatres"); 
        graph.addVertex("Outpatient Units"); 
        graph.addVertex("Wards"); // Isolated Node

        // 10 Weighted Corridors (Edges)
        
        // Cycle: E <-> I <-> OT <-> E
        graph.addEdge("Emergency", "ICU", 5.0); 
        graph.addEdge("ICU", "Operating Theatres", 4.0);
        graph.addEdge("Operating Theatres", "Emergency", 6.0); 
        
        // Main paths
        graph.addEdge("ICU", "Pharmacy", 3.0);
        graph.addEdge("Pharmacy", "Outpatient Units", 8.0);
        
        // Radiology/Lab paths
        graph.addEdge("Operating Theatres", "Radiology", 2.0);
        graph.addEdge("Radiology", "Laboratories", 1.5); 
        
        // Alternative/Longer paths
        graph.addEdge("Emergency", "Laboratories", 12.0); 
        graph.addEdge("ICU", "Radiology", 10.0);
        graph.addEdge("Outpatient Units", "Laboratories", 4.5); 
        
        // Total Edges: 10
    }
    
    // --- Test Method Implementations ---

    private static void testGraphMetrics(DSAGraph graph) {
        // Test 1.1 - 1.4
        assertTrue(graph.getVertexCount() == 8, "1.1. Vertex Count (8 expected)");
        assertTrue(graph.getEdgeCount() == 10, "1.2. Edge Count (10 expected for undirected)");
        assertTrue(graph.hasVertex("Wards"), "1.3. Isolated Node 'Wards' exists");
        assertTrue(graph.hasVertex("NonExistent") == false, "1.4. hasVertex negative case");
    }
    
    private static void testEdgeManagement(DSAGraph graph) {
        // Test 1.5 - 1.7
        assertTrue(graph.getAdjacent("Emergency").getCount() == 3, "1.5. Initial adjacency count for Emergency (3 expected)");
        
        // Test edge deletion
        try {
            graph.deleteEdge("Emergency", "ICU");
            // The counts are correct: Emergency adj=2, ICU adj=3 (OT, P, R)
            assertTrue(graph.getAdjacent("Emergency").getCount() == 2, "1.6. Edge deletion: Emergency->ICU removed (3 -> 2)");
            assertTrue(graph.getAdjacent("ICU").getCount() == 3, "1.7. Edge deletion: ICU->Emergency reverse edge removed (4 -> 3)");
        } catch (Exception e) {
            assertTrue(false, "1.6/1.7. Edge deletion failed with exception: " + e.getMessage());
        }
        
        // Re-add the edge for subsequent tests
        graph.addEdge("Emergency", "ICU", 5.0);
        // Test 1.8
        assertTrue(graph.getAdjacent("Emergency").getCount() == 3, "1.8. Edge re-added successfully (2 -> 3)");
    }

    private static void testBFS(DSAGraph graph) {
        // Test 2.1 - 2.4   
        String expectedLevel0 = "\nLevel 0: [Emergency]"; 
        String expectedLevel1 = "\nLevel 1: [Operating Theatres, Laboratories, ICU]"; 
        String expectedLevel2 = "\nLevel 2: [Radiology, Outpatient Units, Pharmacy]"; 
        
        try {
            String output = graph.breadthFirstSearchLevelOutput("Emergency");
            assertTrue(output.contains(expectedLevel0), "2.1. BFS Level 0 check");    
            assertTrue(output.contains(expectedLevel1), "2.2. BFS Level 1 check"); 
            assertTrue(output.contains(expectedLevel2), "2.3. BFS Level 2 check (Set remains the same)"); 
            assertTrue(!output.contains("Wards"), "2.4. BFS correctly ignores isolated node 'Wards'");
        } catch (Exception e) {
            assertTrue(false, "BFS execution failed with exception: " + e.getMessage());
        }
    }
    
    private static void testDFS(DSAGraph graph) {
        // Test 2.5 - 2.6
        try {
            String output = graph.depthFirstSearchCycleDetection("Emergency");
            
            assertTrue(output.contains("Cycle Exists: True"), "2.5. DFS successfully detected a cycle.");
            
            // Test 2.6: The DSAGraph implementation is confirmed to include the detailed message.
            assertTrue(output.contains("[RESULT] CYCLE DETECTED"), 
                         "2.6. DFS confirmed CYCLE DETECTED message is present.");

        } catch (Exception e) {
            assertTrue(false, "DFS execution failed with exception: " + e.getMessage());
        }
    }

    private static void testDijkstra(DSAGraph graph) {
        // Test 2.7 - 2.9
        try {
            // Test 1: Shortest Path (E -> L). Expected: E -> OT -> R -> L (6.0 + 2.0 + 1.5 = 9.5)
            String output1 = graph.shortestPathDijkstra("Emergency", "Laboratories");
            assertTrue(output1.contains("Total Walking Time: 9.5 minutes"), "2.7. Dijkstra Path E->L total cost (9.5)");
            assertTrue(output1.contains("Emergency -> Operating Theatres -> Radiology -> Laboratories"), "2.7. Dijkstra Path E->L correct sequence");
            
            // Test 2: Simple path (P -> O). Expected: P -> O (8.0)
            String output2 = graph.shortestPathDijkstra("Pharmacy", "Outpatient Units");
            assertTrue(output2.contains("Total Walking Time: 8.0 minutes"), "2.8. Dijkstra Path P->O total cost (8.0)");

            // Test 3: Path to isolated node (Wards)
            String output3 = graph.shortestPathDijkstra("Emergency", "Wards");
            assertTrue(output3.contains("unreachable"), "2.9. Dijkstra Path E->Wards (isolated) is unreachable");
        } catch (Exception e) {
            assertTrue(false, "Dijkstra execution failed with exception: " + e.getMessage());
        }
    }
}