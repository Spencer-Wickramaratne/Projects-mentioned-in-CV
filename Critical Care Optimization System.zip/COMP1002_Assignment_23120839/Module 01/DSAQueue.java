/*Author:Nallaperuma Arachchilage Spencer Sterling Wickramaratne
 * Curtin ID: 23120839
 * References: Lecture slides and https://www.geeksforgeeks.org practical 03 submission
 * A general-purpose queue class that acts as a parent for specific
 * queue implementations. Its methods are designed to be overridden by subclasses.
 */

public class DSAQueue {
    private Object[] queueArray;
    private int count;
    private static final int DEFAULT_CAPACITY = 100;

    /**
     * Default constructor for DSAQueue.
     */
    public DSAQueue() {

        this(DEFAULT_CAPACITY);
    }

    /**

     */
    public DSAQueue(int capacity) {
        if (capacity <= 0) {
            throw new IllegalArgumentException("Capacity must be positive.");
        }
        this.queueArray = new Object[capacity];
        this.count = 0;
    }

    // Public getters to allow subclasses to access the private fields
    public Object[] getQueueArray() {
        return queueArray;
    }

    public int getCount() {
        return count;
    }
    
    // Public setters to allow subclasses to modify the private fields
    public void setCount(int newCount) {
        this.count = newCount;
    }

    /**
     * Adds a new value to the queue. This method should be overridden by a subclass.

     */
    public void enqueue(Object value) {
        throw new UnsupportedOperationException("This method must be overridden by a subclass.");
    }

    /**
     * Removes and returns the value at the front of the queue. This method should be overridden by a subclass.
 
     */
    public Object dequeue() {
        throw new UnsupportedOperationException("This method must be overridden by a subclass.");
    }

    /**
     * Returns the value at the front of the queue without removing it. This method should be overridden by a subclass.
   
     */
    public Object peek() {
        throw new UnsupportedOperationException("This method must be overridden by a subclass.");
    }

    /**
     * Checks if the queue is empty.
   
     */
    public boolean isEmpty() {
        return getCount() == 0;
    }

    /**
     * Checks if the queue is full.
   
     */
    public boolean isFull() {
        return getCount() == getQueueArray().length;
    }
}

// -------------------------------------------------------------------------------------------------------------------

/**
 * A queue implementation using an array with a shuffling approach.
 * It inherits from the DSAQueue class.
 */
 class DSAShufflingQueue extends DSAQueue {
    public DSAShufflingQueue() {
        super();
    }

    public DSAShufflingQueue(int capacity) {
        super(capacity);
    }

    /**
 
     */
   
    public void enqueue(Object value) {
        if (isFull()) {
            throw new IllegalStateException("Queue is full");
        }
        getQueueArray()[getCount()] = value;
        setCount(getCount() + 1);
    }

    /**
     * Removes an element from the front of the shuffling queue and shifts all
     * subsequent elements forward.
 
     */

    public Object dequeue() {
        if (isEmpty()) {
            throw new IllegalStateException("Queue is empty");
        }
        Object value = getQueueArray()[0];
        
        // Shift all elements forward by one
        for (int i = 0; i < getCount() - 1; i++) {
            getQueueArray()[i] = getQueueArray()[i + 1];
        }

        getQueueArray()[getCount() - 1] = null;
        setCount(getCount() - 1);
        return value;
    }

    /**
     * Peeks at the element at the front of the shuffling queue without removing it.
   
     */
  
    public Object peek() {
        if (isEmpty()) {
            throw new IllegalStateException("Queue is empty");
        }
        return getQueueArray()[0];
    }

    /**
     * Returns a string representation of the queue's contents.
     */
  
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        if (!isEmpty()) {
            for (int i = 0; i < getCount(); i++) {
                sb.append(getQueueArray()[i]);
                if (i < getCount() - 1) {
                    sb.append(", ");
                }
            }
        }
        sb.append("]");
        return sb.toString();
    }
}



/**
 * A queue implementation using a circular array. It inherits from the DSAQueue class.
 */
class DSACircularQueue extends DSAQueue {
    private int front;
    private int rear;

    public DSACircularQueue() {
        super();
        this.front = 0;
        this.rear = -1;
    }

    public DSACircularQueue(int capacity) {
        super(capacity);
        this.front = 0;
        this.rear = -1;
    }

    /**
     * Adds an element to the rear of the circular queue.
     * The rear index is incremented using modulo arithmetic to wrap around.
  
     */
   
    public void enqueue(Object value) {
        if (isFull()) {
            throw new IllegalStateException("Queue is full");
        }
        
        // Move the rear index forward, wrapping around if needed
        this.rear = (this.rear + 1) % getQueueArray().length;
        getQueueArray()[this.rear] = value;
        setCount(getCount() + 1);
    }

    /**
     * Removes an element from the front of the circular queue.
     * The front index is incremented using modulo arithmetic to wrap around.
    
     */
   
    public Object dequeue() {
        if (isEmpty()) {
            throw new IllegalStateException("Queue is empty");
        }
        
        Object value = getQueueArray()[this.front];
        getQueueArray()[this.front] = null;
        
        // Move the front index forward, wrapping around if needed
        this.front = (this.front + 1) % getQueueArray().length;
        setCount(getCount() - 1);
        return value;
    }

    /**
     * Peeks at the element at the front of the circular queue without removing it.
    
     */
   
    public Object peek() {
        if (isEmpty()) {
            throw new IllegalStateException("Queue is empty");
        }
        return getQueueArray()[this.front];
    }

    /**
         * Returns a string representation of the circular queue's contents.
         * Note that this implementation iterates through the array from the front,
         * handling the circular nature to correctly display the elements in order.
       
         */
       
        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append("[");
            if (!isEmpty()) {
                for (int i = 0; i < super.getCount(); i++) {
                    int index = (front + i) % super.getQueueArray().length;
                    sb.append(super.getQueueArray()[index]);
                    if (i < super.getCount() - 1) {
                        sb.append(", ");
                    }
                }
            }
            sb.append("]");
            return sb.toString();
        }
}
