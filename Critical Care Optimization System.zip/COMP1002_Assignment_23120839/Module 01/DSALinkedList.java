/*Author:Nallaperuma Arachchilage Spencer Sterling Wickramaratne
 * Curtin ID: 23120839
 * References: Lecture slides and practical 04 submission */
import java.util.Objects;

public class DSALinkedList {
    private DSAListNode head;
    private DSAListNode tail;
    private int count;

    public DSALinkedList() {
        this.head = null;
        this.tail = null;
        this.count = 0;
    }

    public void insertFirst(Object newValue) {
        DSAListNode newNode = new DSAListNode(newValue);

        if (isEmpty()) { 
            head = newNode;
            tail = newNode;
        } else {
            newNode.setNext(head);
            head.setPrev(newNode);
            head = newNode;
        }
        this.count++;
    }

    public void insertLast(Object newValue) {
        DSAListNode newNode = new DSAListNode(newValue);

        if (isEmpty()) { 
            head = newNode;
            tail = newNode;
        } else {
            tail.setNext(newNode);
            newNode.setPrev(tail);
            tail = newNode;
        }
        this.count++;
    }
    
  
     
    public Object removeFirst() {
        if (isEmpty()) {
            throw new IllegalStateException("List is empty.");
        }
        Object value = head.getValue();
        if (head.getNext() == null) { 
            head = null;
            tail = null;
        } else {
            head = head.getNext();
            head.setPrev(null);
        }
        this.count--;
        return value;
    }

    public Object removeLast() {
        if (isEmpty()) {
            throw new IllegalStateException("List is empty.");
        }
        Object value = tail.getValue();
        if (tail.getPrev() == null) { 
            head = null;
            tail = null;
        } else {
            tail = tail.getPrev();
            tail.setNext(null);
        }
        this.count--;
        return value;
    }
     
    /**
     * Removes the first occurrence of a specified value from the list. 
     * IMPORTANT: Uses Objects.equals() to correctly handle custom objects like DSAEdge.
     */
    public boolean remove(Object value) {
        if (isEmpty()) {
            return false;
        }

        DSAListNode current = head;
        while (current != null) {
            //  Use Objects.equals() to check equality against the stored value.
            if (Objects.equals(current.getValue(), value)) { 
                // Found the node to remove
                if (current.getPrev() == null) { // It's the head
                    removeFirst(); // Already handles count--
                } else if (current.getNext() == null) { // It's the tail
                    removeLast(); // Already handles count--
                } else { // It's a middle node
                    current.getPrev().setNext(current.getNext());
                    current.getNext().setPrev(current.getPrev());
                    this.count--; // Manually decrease count for middle node
                }
                return true; // Deletion successful
            }
            current = current.getNext();
        }
        return false; // Value not found
    }

    public boolean isEmpty() {
        return head == null;
    }

    public Object peekFirst() {
        if (isEmpty()) {
            throw new IllegalStateException("List is empty.");
        }
        return head.getValue();
    }
     
    public DSAListNode peekFirstNode() {
        return head;
    }

    // Returns the value of the last node without removing it
    public Object peekLast() {
        if (isEmpty()) {
            throw new IllegalStateException("List is empty.");
        }
        return tail.getValue();
    }

    public int getCount() {
        return this.count;
    }

    public Object[] toArray() {
        Object[] array = new Object[count];
        DSAListNode current = head;
        int i = 0;
        while (current != null) {
            array[i++] = current.getValue();
            current = current.getNext();
        }
        return array;
    }
     
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        DSAListNode current = head;
        while (current != null) {
            sb.append(current.getValue().toString());
            if (current.getNext() != null) {
                sb.append(", ");
            }
            current = current.getNext();
        }
        sb.append("]");
        return sb.toString();
    }
}