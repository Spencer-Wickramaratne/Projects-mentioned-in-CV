/*Author:Nallaperuma Arachchilage Spencer Sterling Wickramaratne
 * Curtin ID: 23120839
 * A public class representing a node in a doubly linked list.
 * This class is now in its own file to be accessible by other classes.
 * References: Lecture slides and practical 04 submission 
 */
public class DSAListNode {
    private Object value;
    private DSAListNode next;
    private DSAListNode prev;

    public DSAListNode(Object inValue) {
        this.value = inValue;
        this.next = null;
        this.prev = null;
    }

    public Object getValue() {
        return value;
    }

    public DSAListNode getNext() {
        return next;
    }

    public void setNext(DSAListNode next) {
        this.next = next;
    }

    public DSAListNode getPrev() {
        return prev;
    }

    public void setPrev(DSAListNode prev) {
        this.prev = prev;
    }
}