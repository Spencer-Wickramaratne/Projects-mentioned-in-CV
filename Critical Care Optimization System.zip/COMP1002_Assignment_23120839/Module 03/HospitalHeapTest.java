/* Author:Nallaperuma Arachchilage Spencer Sterling Wickramaratne
 * Curtin ID: 23120839
 * HospitalHeapTest.java
 * Test driver for Module 3: Heap-Based Emergency Scheduling.
 */
import java.lang.Math;

public class HospitalHeapTest {

    // Must use DSAHashTable (Module 2) 
    
    private static DSAHashTable patientDatabase = new DSAHashTable(20); 
    private static DSAHeap schedulerHeap;
    
    // Test Reporting Fields
    private static int testsRun = 0;
    private static int testsPassed = 0;
    
    private static final double EXPECTED_P_112 = 1003.0; 
    public static void main(String[] args) {
        runTestTrace();
    }
    
    /** Public method to run the entire test trace. */
    public static void runTestTrace() {
        testsRun = 0;
        testsPassed = 0;
        
        System.out.println("=======================================================");
        System.out.println("     MODULE 3: HOSPITAL HEAP SCHEDULER TEST TRACE");
        System.out.println("     Data Storage: DSAHashTable (Module 2)");
        System.out.println("     Priority Metric: P = (6 - U) + (1000 / T)"); 
        System.out.println("     Urgency (U) CAPPED at 5 for calculation (U=1 is highest priority).");
        System.out.println("=======================================================");
        
        // --- 0. Setup and Initialization ---
        testSetup();

        // --- 1. Insertion Sequence (12 Requests) ---
        System.out.println("\n--- TEST PHASE 1: INSERTION SEQUENCE (12 Requests) ---");
        runInsertionTests();
        
        // --- 2. Edge Cases and Updates ---
        System.out.println("\n--- TEST PHASE 2: EDGE CASES AND UPDATES ---");
        runEdgeCaseTests();

        // --- 3. Extraction Sequence (12 Served Cases Total) ---
        System.out.println("\n--- TEST PHASE 3: EXTRACTION (TREATMENT) SEQUENCE (12 Served Cases Total) ---");
        runExtractionTests();

        // --- Final Test Report ---
        generateTestReport();
    }
    

    private static void testSetup() {
        try {
            schedulerHeap = new DSAHeap(false); 
            setupPatientDatabase();
            recordTestResult(true, "Setup: Initialize Heap and DSAHashTable.");
        } catch (Exception e) {
            recordTestResult(false, "Setup: Initialization Failed. " + e.getMessage());
        }
    }

    private static void setupPatientDatabase() {
        // Since the priority formula caps U at 5 anyway, this change does not affect the calculation.
        patientDatabase.put("101", new Patient("101", "Ally", 50, 1, 20.0));
        patientDatabase.put("102", new Patient("102", "Bill", 65, 5, 5.0));     
        patientDatabase.put("103", new Patient("103", "Cate", 30, 5, 15.0));
        patientDatabase.put("104", new Patient("104", "David", 45, 1, 20.0));
        patientDatabase.put("105", new Patient("105", "Eve", 20, 5, 1.0));       
        patientDatabase.put("106", new Patient("106", "Frank", 70, 3, 10.0));
        patientDatabase.put("107", new Patient("107", "Grace", 85, 5, 2.0)); 
        patientDatabase.put("108", new Patient("108", "Henry", 50, 5, 5.0));
        patientDatabase.put("109", new Patient("109", "Ivy", 33, 3, 50.0));
        patientDatabase.put("110", new Patient("110", "Jack", 22, 5, 25.0));   
        patientDatabase.put("111", new Patient("111", "Kelly", 12, 1, 100.0));
        patientDatabase.put("112", new Patient("112", "Leo", 60, 3, 1.0));
        System.out.printf("[INFO] %d patients loaded into DSAHashTable.\n", patientDatabase.getCount());
        recordTestResult(patientDatabase.getCount() == 12, "Setup: Load 12 Patients into DSAHashTable.");
    }
    
    private static void runInsertionTests() {
        insertRequest("101", 20.0, false); 
        insertRequest("102", 5.0, false); 
        insertRequest("103", 15.0, false); 
        insertRequest("104", 20.0, false); 
        insertRequest("105", 1.0, false); 
        insertRequest("106", 10.0, false); 
        insertRequest("107", 2.0, false); 
        insertRequest("108", 5.0, false); 
        insertRequest("109", 50.0, false); 
        insertRequest("110", 25.0, false); 
        insertRequest("111", 100.0, false);
        insertRequest("112", 1.0, false); 
        
        DSAHeap.DSAHeapEntry root = schedulerHeap.getEntry(0);
        boolean rootCheck = root != null && Math.abs(root.getPriority() - EXPECTED_P_112) < 0.01;
        recordTestResult(rootCheck, String.format("Insertion: P112 (P=%.2f) is Max Root after 12 inserts.", EXPECTED_P_112));
        
        System.out.printf("[INFO] Total items in heap: %d\n", schedulerHeap.getCount());
        printHeapArray(schedulerHeap, "AFTER ALL INSERTS");
    }

    private static void runEdgeCaseTests() {
        // --- Edge 1: Invalid Patient ID ---
        try {
            insertRequest("999", 10.0, true); 
            recordTestResult(true, "Edge Test: Invalid Patient ID (Handled by DSAHashTable)."); 
        } catch (Exception e) {
             recordTestResult(false, "Edge Test: Invalid Patient ID (Unexpected Exception).");
        }
        
        // --- Edge 2: Patient with Inactive Status ---
        try {
            Patient p103 = (Patient) patientDatabase.get("103");
            p103.setTreatmentStatus("Discharged"); 
            insertRequest("103", 15.0, true); 
            recordTestResult(p103.getTreatmentStatus().equals("Discharged"), "Edge Test: Inactive Status (Insertion Ignored).");
            p103.setTreatmentStatus("Waiting"); 
        } catch (Exception e) {
            recordTestResult(false, "Edge Test: Inactive Status (Unexpected Exception).");
        }

        //  Edge 3: Invalid Treatment Time (T <= 0) 
        boolean timeErrorCaught = false;
        try {
            System.out.println("[LOG] Testing T <= 0...");
            insertRequest("101", 0.0, true);
        } catch (IllegalArgumentException e) {
            System.err.println("[ERROR] Invalid Time Handled: " + e.getMessage());
            timeErrorCaught = true;
        } catch (Exception e) {
        }
        recordTestResult(timeErrorCaught, "Edge Test: Invalid Time (T <= 0) throws IllegalArgumentException.");

        //  Update Demo (Task 3: Re-insertion) 
        System.out.println("\n--- UPDATE DEMO: P109 Urgency Change (Re-insertion for Skip Test) ---");
        Patient p109 = (Patient) patientDatabase.get("109");
        
        p109.setUrgency(5); 
        insertRequest("109", 50.0, false); 
        
        DSAHeap.DSAHeapEntry rootAfterUpdate = schedulerHeap.getEntry(0);
        boolean updateCheck = rootAfterUpdate != null && Math.abs(rootAfterUpdate.getPriority() - EXPECTED_P_112) < 0.01;
        recordTestResult(updateCheck, String.format("Update: P109 re-inserted (Max Root check remains P112 (P=%.2f)).", EXPECTED_P_112));
        System.out.printf("[INFO] Total items in heap: %d\n", schedulerHeap.getCount());
        printHeapArray(schedulerHeap, "AFTER UPDATE INSERT");
    }

    private static void runExtractionTests() {
        
        double newExpectedPrioritySequence[] = {
             1003.00, // P112
             1001.00, // P105
             501.00,    // P107
             201.00,    // P102 (Observed to be extracted first in the tie)
             201.00,    // P108 (Observed to be extracted second in the tie)
             103.00,    // P106
             67.67,     // P103
             55.00,     // P104 (Observed to be extracted first in the tie)
             55.00,     // P101 (Observed to be extracted second in the tie)
             41.00,     // P110
             21.00,     // P109 
             15.00  // P111
        }; 
      
        String expectedIDSequence[] = {
             "112", "105", "107", "102", "108", "106", 
             "103", "104", "101", "110", "109", "111" 
        }; 
        
        final int NUM_VALID_EXTRACTIONS = 12; 
        boolean prematureHeapEmpty = false; // FLAG: Used to replace the non-switch 'break'
        
        for (int i = 0; i < NUM_VALID_EXTRACTIONS && !prematureHeapEmpty; i++) { // Loop condition checks flag
            try {
                // The issue here is a return inside a try block, but it's an exceptional case exit.
                // The requested refactoring focuses on logic, not exception/error exits.
                DSAHeap.DSAHeapEntry extracted = extractPriorityCase(true); 
                
                if (extracted != null) {
                    Patient p = (Patient) extracted.getValue();
                    boolean priorityMatch = Math.abs(extracted.getPriority() - newExpectedPrioritySequence[i]) < 0.01;
                    boolean idMatch = p.getPatientId().equals(expectedIDSequence[i]);
                    
                    int extractionNum = i + 1;
                    String extractionName = "Extraction " + extractionNum;
                    
                    if (i == 10) {
                        
                        extractionName = "Extraction 11 (Includes Skip): Serve P109 (P=21.00)"; 
                    } else if (i == 11) {
                            extractionName = "Extraction 12 (Includes Skip): Serve P111"; 
                    }

                    recordTestResult(priorityMatch && idMatch, 
                        String.format(extractionName + " P%s (P=%.2f) - Priority Check.", expectedIDSequence[i], newExpectedPrioritySequence[i]));
                } else {
                    recordTestResult(false, String.format("Extraction %d Failed: Returned null unexpectedly.", i + 1));
                }
            } catch (IllegalStateException e) {
                    recordTestResult(false, String.format("Extraction %d Failed: Heap became empty prematurely.", i + 1));
                    // Cannot use return, so this loop will just end on the exception anyway
                    prematureHeapEmpty = true; // FIX: Replaced 'break' with setting the flag to stop iteration
            } catch (Exception e) {
                    recordTestResult(false, String.format("Extraction %d Failed: %s", i + 1, e.getMessage()));
            }
        }
        
        // --- Final check: ensure heap is empty after all 12 unique patients are served ---
        System.out.println("\n[INFO] Checking for heap emptiness (next extraction should fail)...");
        
        try {
            DSAHeap.DSAHeapEntry finalExtraction = extractPriorityCase(false); 
            
            if (finalExtraction != null) {
                recordTestResult(false, "Final Check Failed: Extraction returned P" + ((Patient)finalExtraction.getValue()).getPatientId() + ", but expected Heap Empty exception.");
            }

        } catch (IllegalStateException e) {
            recordTestResult(true, "Final Check: Heap is correctly empty after all valid extractions (IllegalStateException caught).");
        } catch (Exception e) {
                    recordTestResult(false, "Final Check Failed unexpectedly: " + e.getMessage());
        }
    }
    
    private static void insertRequest(String patientID, double T, boolean isEdgeCase) {
        
        Patient patient = null;
        double priority = -1.0;
        boolean canInsert = true;
        
        try {
            patient = (Patient) patientDatabase.get(patientID); 
        } catch (IllegalArgumentException e) {
            // Patient ID not found, set flag to prevent insertion logic
            if (isEdgeCase) System.err.println("[ERROR] Request failed: Patient ID '" + patientID + "' not found in database.");
            canInsert = false;
        }
        
        if (canInsert && patient.getTreatmentStatus().equals("Discharged")) {
            // Patient inactive, set flag to prevent insertion logic
            if (isEdgeCase) System.err.println("[INFO] Request for " + patientID + " ignored: Patient status is 'Discharged'.");
            canInsert = false;
        }
        
        if (canInsert && T <= 0) {
            // Invalid time is a serious error, still must throw an exception
            throw new IllegalArgumentException("Treatment time (T) must be positive (> 0).");
        }
        
        // --- Single Logical Path for Successful Insertion ---
        if (canInsert) {
            int U = patient.getUrgency(); 
            // Urgency is capped at 5 for calculation, where 1 is highest priority.
            int U_capped = Math.min(5, U);
            
            // REQUIRED PRIORITY FORMULA IMPLEMENTATION 
            priority = (6.0 - U_capped) + (1000.0 / T);
            
            if (!isEdgeCase) {
                 System.out.printf("\n[INSERT %d] ID:%s (U_Patient:%d, U_Form:%d, T:%.1f min)\n", schedulerHeap.getCount() + 1, patientID, U, U_capped, T);
            }
            
            System.out.printf("[LOG] Priority Calculation: (6 - %d) + (1000 / %.1f) = %.2f\n", U_capped, T, priority);
            
            schedulerHeap.add(priority, patient);
            
            if (!isEdgeCase) {
                printHeapArray(schedulerHeap, "AFTER INSERT");
            }
        }
   
    }
    
    /**
     * Return highestEntry at the end.
     * The internal while loop handles the 'skip stale entry' logic.
     */
    private static DSAHeap.DSAHeapEntry extractPriorityCase(boolean trace) {
        
        DSAHeap.DSAHeapEntry highestEntry = null;
        Patient patient = null;
        boolean entryFound = false;

        // Loop to handle stale entries without recursion
        while (!entryFound) {
            try {
                highestEntry = schedulerHeap.remove();
                patient = (Patient) highestEntry.getValue();
                
                // Task 3: Handle stale entries (Re-insertion Strategy)
                if (patient.getTreatmentStatus().equals("Treated")) {
                    if (trace) System.out.println("[INFO] Skipping stale entry (P=" + String.format("%.2f", highestEntry.getPriority()) + ", ID: " + patient.getPatientId() + "). Patient was already served by a higher-priority re-insertion.");
                    // Continue loop to remove the next entry
                } else {
                    entryFound = true; // Found a valid entry, exit loop
                }

            } catch (IllegalStateException e) {
                if (trace) System.out.println("\n[INFO] Scheduler is empty. No more cases to serve.");
                highestEntry = null; // Ensure null if exception is caught
                entryFound = true; // Exit loop after throwing or catching exception
                throw e; // Re-throw the IllegalStateException
            }
        }
        
        // Only executes for a valid, non-stale entry
        if (highestEntry != null) {
            if (trace) {
                System.out.println("\n--- EXTRACT: SERVING CASE (ID: " + patient.getPatientId() + ") ---");
                System.out.printf("[RESULT] Patient Data: %s\n", patient);
                System.out.printf("[RESULT] Priority Value: **%.2f**\n", highestEntry.getPriority());
            }
            
            // Mark patient as treated/served
            patient.setTreatmentStatus("Treated");
            
            if (trace) {
                printHeapArray(schedulerHeap, "AFTER EXTRACT");
            }
        }

        return highestEntry; // Single exit point
    }
    
    
    private static void printHeapArray(DSAHeap heap, String context) {
        System.out.printf("[TRACE] Heap State %s (Count: %d): [", context, heap.getCount());
        
        for (int i = 0; i < heap.getCount(); i++) {
            DSAHeap.DSAHeapEntry entry = heap.getEntry(i);
            String patientID = ((Patient) entry.getValue()).getPatientId();
            System.out.printf("(%.2f, %s)%s", entry.getPriority(), patientID, (i < heap.getCount() - 1 ? ", " : ""));
        }
        System.out.println("]");
    }

    private static void recordTestResult(boolean success, String testName) {
        testsRun++;
        if (success) {
            testsPassed++;
            System.out.printf("[PASS] %s\n", testName);
        } else {
            System.err.printf("[FAIL] %s\n", testName);
        }
    }
    
    private static void generateTestReport() {
        int testsFailed = testsRun - testsPassed;
        System.out.println("\n=======================================================");
        System.out.println("     MODULE 3 FINAL TEST REPORT");
        System.out.println("=======================================================");
        System.out.printf("Total Tests Run: %d\n", testsRun);
        System.out.printf("Tests Passed: %d\n", testsPassed);
        System.out.printf("Tests Failed: %d\n", testsFailed);
        System.out.println("=======================================================");
        
        System.out.println("Brief Written Note on Update Strategy (Task 3):");
        System.out.println("Strategy: **Re-insertion with Stale Entry Skip.** To update a patient's priority (e.g., P109's urgency worsens), the Patient object in the DSAHashTable is modified, and a *new* heap entry is inserted with the new priority value. The Max Heap ensures the new entry is served first. The old, lower-priority entry remains in the heap but is detected as 'stale' (by checking its **Treatment Status** on the patient object) when extracted, and is then safely skipped/discarded via **looping** (instead of recursion) until a valid, non-stale entry is found.");
    }
}