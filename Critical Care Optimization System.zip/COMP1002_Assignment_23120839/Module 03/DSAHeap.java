/* Author:Nallaperuma Arachchilage Spencer Sterling Wickramaratne
 * Curtin ID: 23120839
*  References: Lecture slides and practical 08 submission
 * DSAHeap.java
 * Implements a configurable Heap structure (Min Heap for Dijkstra's, Max Heap otherwise).
 */
public class DSAHeap {

    // DSAHeapEntry Class (Public Static Nested)
    public static class DSAHeapEntry {
        private double priority; // The heap key (e.g., urgency score or inverted distance)
        private Object value; // The data associated with the priority (e.g., Patient object)

        public DSAHeapEntry(double priority, Object value) {
            this.priority = priority;
            this.value = value;
        }

        public double getPriority() { return priority; }
        public void setPriority(double priority) { this.priority = priority; }
        public Object getValue() { return value; }
        public void setValue(Object value) { this.value = value; }

        public String toString() { return "(" + String.format("%.1f", priority) + ", " + value + ")"; }
    }
    
    
    // DSAHeap Fields and Methods
    private DSAHeapEntry[] heap;
    private int count;
    private boolean isMinHeap; // Configuration flag
    private static final int DEFAULT_CAPACITY = 10000;

    // Auxiliary structure for O(1) element look-up. 
    private DSAHashTable indexTable; 

    /**
     * Constructor: Creates a configurable Heap with a specific capacity.
     */
    public DSAHeap(int capacity, boolean isMinHeap) {
        this.heap = new DSAHeapEntry[capacity];
        this.count = 0;
        this.isMinHeap = isMinHeap;
        // Use the provided custom hash table implementation
        this.indexTable = new DSAHashTable(); 
    }
    
    /**
     * Constructor: Creates a configurable Heap with a default capacity.
     */
    public DSAHeap(boolean isMinHeap) {
        this(DEFAULT_CAPACITY, isMinHeap);
    }
    
    /**
     * Constructor: Creates a Min Heap (default for Dijkstra's).
     */
    public DSAHeap() {
        this(DEFAULT_CAPACITY, true); // Default capacity and Min Heap
    }
    
    //  Private Helper to Safely Extract Patient ID 
    /**
     * Extracts the unique ID/key from the value object stored in the heap.
  
     */
    private String getPatientId(Object value) {
        String id = null;
        
        try {
            // 1. Check for getPatientId() method (e.g., Patient object)
            if (value != null && value.getClass().getMethod("getPatientId") != null) {
                id = value.getClass().getMethod("getPatientId").invoke(value).toString();
            }
        } catch (Exception e) {
            // Fall through to the next checks if not a Patient or method missing/inaccessible
        }
        
        if (id == null) {
            // 2. Check for the graph vertex object
            if (value instanceof DSAGraph.DSAGraphVertex) {
                id = ((DSAGraph.DSAGraphVertex) value).getLabel(); 
            }
        }
        
        if (id == null) {
            // 3. Fallback for generic String keys
            if (value instanceof String) { 
                id = (String) value; 
            }
        }
        
        if (id == null) {
            // 4. Throw exception if no valid key found
            throw new IllegalArgumentException("Heap value must be an object with a getPatientId() method or a String key for indexing.");
        }
        
        return id;
    }

    // Accessors
    public int getCount() { return count; }
    public boolean isEmpty() { return count == 0; }
    public DSAHeapEntry peek() {
        if (count == 0) {
            throw new IllegalStateException("Heap is empty. Cannot peek.");
        }
        return heap[0];
    }
    
    /**
     * Public accessor to retrieve an entry from the underlying heap array at a specific index.
     * This is intended for testing and debugging purposes only.
     */
    public DSAHeapEntry getEntry(int index) {
        if (index < 0 || index >= count) {
            throw new IndexOutOfBoundsException("Index out of bounds for current heap size. Index: " + index + ", Count: " + count);
        }
        return heap[index];
    }
    

    /**
     * Adds a new entry or updates an existing one if the value is already present..
     */
    public void add(double priority, Object value) { 
        if (priority < 0) {
            throw new IllegalArgumentException("Priority must be non-negative. Received: " + priority);
        }
        
        String patientId = getPatientId(value);

        // Check for existing value using the custom hash table (O(1) average look-up)
        if (indexTable.hasKey(patientId)) {
            // If it exists, treat this operation as an update
            updatePriority(patientId, priority);
            return; // Early exit
        }

        if (count >= heap.length) {
            throw new IllegalStateException("Heap capacity exceeded.");
        }
        
        // Insert new entry
        DSAHeapEntry newEntry = new DSAHeapEntry(priority, value);
        
        // Add to the array
        heap[count] = newEntry;
        
        // Add to the custom index table: Map Patient ID (key) to its index (value)
        indexTable.put(patientId, count);
        
        // Trickle up and increment count
        trickleUp(count);
        count++;
    }

    /**
     * O(log N) Update Strategy (decrease-key or increase-key).
     * Uses the custom DSAHashTable to find the element index in O(1) average time.
     */
    public void updatePriority(String patientId, double newPriority) {
        if (newPriority < 0) {
            throw new IllegalArgumentException("New priority must be non-negative. Received: " + newPriority);
        }
        
        // 1. Use the custom hash table to find the index (O(1) average case)
        if (!indexTable.hasKey(patientId)) {
            throw new IllegalArgumentException("ID '" + patientId + "' not found in the emergency queue. Cannot update priority.");
        }
        
        // indexTable.get() returns an Object (Integer), so we must cast and unbox the Integer index
        int index = (int) indexTable.get(patientId); 
        
        DSAHeapEntry entry = heap[index];
        double oldPriority = entry.getPriority();

        // 2. Update the priority value
        entry.setPriority(newPriority);

        // 3. Restore the Heap Property (O(log N))
        // If the new priority is 'better' (e.g., lower in a min-heap, higher in a max-heap)
        if (isBetterPriority(newPriority, oldPriority)) {
            trickleUp(index); // Decrease-Key (Min-Heap) or Increase-Key (Max-Heap)
        } else if (isBetterPriority(oldPriority, newPriority)) {
             trickleDown(index); // Increase-Key (Min-Heap) or Decrease-Key (Max-Heap)
        }
        // If priorities are equal, no action needed.
    }
    
   
    /**
     * Overloaded method to update priority using the Patient/Value object directly.
     * The method internally extracts the ID and calls the String-based update.
     * This is the method expected by the call in HospitalMenu and DSAGraph.
     */
    public void updatePriority(Object value, double newPriority) {
        String patientId = getPatientId(value);
        updatePriority(patientId, newPriority);
    }
    

    /**
     * Removes the root (highest priority element).
     */
    public DSAHeapEntry remove() {
        if (count == 0) {
            throw new IllegalStateException("Heap is empty.");
        }
        
        DSAHeapEntry root = heap[0];
        String patientId = getPatientId(root.getValue());
        
        // 1. Remove from the index table (O(1) average case)
        indexTable.remove(patientId);
        
        count--;
        
        if (count > 0) {
            // Move last element to the root
            heap[0] = heap[count];
            
            // 2. Update the new root's index in the index table
            String newRootId = getPatientId(heap[0].getValue());
            indexTable.put(newRootId, 0); // Put updates the value for the existing key
            
            heap[count] = null; 
            trickleDown(0);
        } else {
             heap[0] = null; 
        }
              
        return root;
    }
    
    // Private helper methods
   
    private boolean isBetterPriority(double priority1, double priority2) {
        boolean better;
        if (isMinHeap) {
            better = priority1 < priority2; 
        } else {
            better = priority1 > priority2;
        }
        
        return better;
    }

    private void trickleUp(int currIdx) {
        int parentIdx = (currIdx - 1) / 2;
        
        while (currIdx > 0 && isBetterPriority(heap[currIdx].getPriority(), heap[parentIdx].getPriority())) {
            swap(currIdx, parentIdx);
            currIdx = parentIdx;
            parentIdx = (currIdx - 1) / 2;
        }
    }
    
    
    private void trickleDown(int currIdx) {
        boolean heapPropertyBroken = true; // Use a boolean flag for loop control
        
        while (heapPropertyBroken) {
            int leftChildIdx = (currIdx * 2) + 1;
            int rightChildIdx = (currIdx * 2) + 2;
            int bestIdx = currIdx; 

            if (leftChildIdx < count && isBetterPriority(heap[leftChildIdx].getPriority(), heap[bestIdx].getPriority())) {
                bestIdx = leftChildIdx;
            }
            
            if (rightChildIdx < count && isBetterPriority(heap[rightChildIdx].getPriority(), heap[bestIdx].getPriority())) {
                bestIdx = rightChildIdx;
            }
            
            if (bestIdx == currIdx) {
                heapPropertyBroken = false; // Stop if current is the best
            } else {
                swap(currIdx, bestIdx);
                currIdx = bestIdx;
            }
        }
    }

    private void swap(int idx1, int idx2) {
        DSAHeapEntry temp = heap[idx1];
        heap[idx1] = heap[idx2];
        heap[idx2] = temp;
        
        // Crucial step: Update the index table for both swapped elements
        String id1 = getPatientId(heap[idx1].getValue());
        String id2 = getPatientId(heap[idx2].getValue());
        
        // The put operation handles updating the existing key's value (index)
        indexTable.put(id1, idx1);
        indexTable.put(id2, idx2);
    }
}