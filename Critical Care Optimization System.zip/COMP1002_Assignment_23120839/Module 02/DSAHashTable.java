/* Author:Nallaperuma Arachchilage Spencer Sterling Wickramaratne
 * Curtin ID: 23120839
 * References: Lecture slides and practical 07 submission
 * DSAHashTable: Implements a Hash Table using Open Addressing with Linear Probing.
 */
public class DSAHashTable {

    //  DSAHashEntry Companion Class (Public Static Nested Class) 
    public static class DSAHashEntry { 
        public static final int FREE = 0;
        public static final int USED = 1;
        public static final int PREVIOUSLY_USED = 2;

        private String key;
        private Object value;
        private int state; // 0=FREE, 1=USED, 2=PREVIOUSLY_USED

        public DSAHashEntry() {
            key = null;
            value = null;
            state = FREE;
        }

        public DSAHashEntry(String inKey, Object inValue) {
            key = inKey;
            value = inValue;
            state = USED;
        }

        // Getters
        public String getKey() { return key; }
        public Object getValue() { return value; }
        public int getState() { return state; }

        // Setters
        public void setKey(String newKey) { this.key = newKey; }
        public void setValue(Object newValue) { this.value = newValue; }
        public void setState(int newState) { this.state = newState; }
    }

    // --- Constants and Fields ---
    private DSAHashEntry[] hashArray;
    private int count; // Number of items currently stored
    private int arraySize;
    
    // Load Factor Thresholds (for resizing)
    public static final double UPPER_THRESHOLD = 0.75; 
    private static final double LOWER_THRESHOLD = 0.25;
    private static final int DEFAULT_SIZE = 101; 
    
    // --- Constructors ---
    public DSAHashTable() {
        this(DEFAULT_SIZE);
    }

    public DSAHashTable(int inSize) {
        arraySize = nextPrime(inSize);
        hashArray = new DSAHashEntry[arraySize];
        count = 0;
        for (int i = 0; i < arraySize; i++) {
            hashArray[i] = new DSAHashEntry();
        }
    }
    
    // --- Public Getters (Required for External Access/Test) ---
    public DSAHashEntry[] getHashArray() { return hashArray; }
    public int getArraySize() { return arraySize; }
    public int getCount() { return count; }

    /** * Displays the current state of the entire hash table array 
     * in a clean, tabular format.
     */
    public void displayTable(String title) {
        double loadFactor = (double) count / arraySize;
        System.out.println("\n--- HASH TABLE STATE: " + title + " ---");
        

        System.out.printf("| Array Size: %-5d | Count: %-5d | Load Factor: %.4f |\n", 
                            arraySize, count, loadFactor);
        System.out.println("----------------------------------------------------------"); 
        
        System.out.printf("| %-5s | %-15s | %-10s | %-30s |\n", 
                            "INDEX", "STATUS", "KEY", "VALUE (Patient Name)");
        System.out.println("|-------|-----------------|------------|--------------------------------|"); 
        
        for (int i = 0; i < arraySize; i++) {
            DSAHashEntry entry = hashArray[i];
            
            String stateStr;
            String keyStr = " ";
            String valueStr = " ";
            
            if (entry.getState() == DSAHashEntry.USED) {
                stateStr = "USED";
                keyStr = entry.getKey() == null ? " " : entry.getKey();
                
                try {
                    // This uses reflection/dynamic check since we don't have the Patient class here.
                    if (entry.getValue() != null && entry.getValue().getClass().getName().endsWith("Patient")) {
                        // This assumes the getValue() returns an object with a getName() method if it's a Patient.
                        valueStr = entry.getValue().getClass().getMethod("getName").invoke(entry.getValue()).toString();
                    } else {
                        valueStr = entry.getValue().toString();
                    }
                } catch (Exception e) {
                    valueStr = entry.getValue() != null ? entry.getValue().toString() : "Error/Unknown Value Type";
                }

                
            } else if (entry.getState() == DSAHashEntry.PREVIOUSLY_USED) {
                stateStr = "DEL (PREV_USED)";
                
            } else { // DSAHashEntry.FREE
                stateStr = "FREE";
            }
            
            System.out.printf("| %-5d | %-15s | %-10s | %-30s |\n", 
                                 i, stateStr, keyStr, valueStr);
        }
        System.out.println("----------------------------------------------------------");
    }

    // --- Hashing and Probing Methods ---
    
    /** * Private helper to calculate the raw, size-independent hash code (the 'key' from pseudocode). */
    public long getHashVal(String key) {
        long hashVal = 0;
        for (int i = 0; i < key.length(); i++) {
            // Standard polynomial rolling hash (base 31)
            hashVal = (hashVal * 31 + key.charAt(i));
        }
        return hashVal;
    }
    
    /** * Primary hash function: Calculates h1(key). */
    private int hash(String key) {
        // 1. Calculate the hash code (independent of arraySize)
        long hashVal = getHashVal(key);
        
        // 2. Map the hash code to the array index.
        int index = (int) (hashVal % arraySize); 
        
        // 3. Ensure the result is non-negative.
        if (index < 0) {
            index += arraySize;
        }
        
        return index;
    }

    
    
    /** * Helper to find an index for a key. (Changed to public for testing) 
     * Now uses Linear Probing logic: h_i = (h0 + i) % M.
     * Returns index of key if found (USED state), or index for insertion if not found (FREE/PREVIOUSLY_USED).
     */
    public int find(String key) { 
        int h0 = hash(key);
        int resultIndex = -1; 
        boolean found = false;
        
        // Track first encounter with PREVIOUSLY_USED for insertion point
        int firstPreviouslyUsedIndex = -1; 

        // Loop through all possible probe steps (i=0 to arraySize-1), stop if result found
        for (int i = 0; i < arraySize && !found; i++) {
            // Calculate the index for the current probe attempt (Linear Probing: h_i = (h0 + i) % M)
            int index = (h0 + i) % arraySize;
            
            DSAHashEntry entry = hashArray[index];
            
            // 1. Found the key (Success)
            if (entry.getState() == DSAHashEntry.USED && entry.getKey().equals(key)) {
                resultIndex = index; 
                found = true; 
            }
            // 2. Found a FREE slot (Stop condition: key not found, provides insertion point)
            else if (entry.getState() == DSAHashEntry.FREE) {
                // If we found a PREVIOUSLY_USED slot earlier, that is the best insertion point
                if (firstPreviouslyUsedIndex != -1) {
                    resultIndex = firstPreviouslyUsedIndex;
                } else {
                    resultIndex = index;
                }
                found = true; 
            }
            // 3. Found a PREVIOUSLY_USED slot (Potential insertion point, but keep looking for the key)
            else if (entry.getState() == DSAHashEntry.PREVIOUSLY_USED && firstPreviouslyUsedIndex == -1) {
                // Only record the *first* previously used slot
                firstPreviouslyUsedIndex = index; 
            }
            // 4. Continue probing if USED with wrong key
        }
        
        // Final check if key wasn't found but there was a PREVIOUSLY_USED slot
        if (!found) {
            if (firstPreviouslyUsedIndex != -1) {
                resultIndex = firstPreviouslyUsedIndex;
            } else {
                // Table is full, and no PREVIOUSLY_USED slots exist. Find failed.
                resultIndex = -1; 
            }
        }
        
        return resultIndex;
    }
    
    // --- Core Hash Table Operations ---
    
    public void put(String key, Object value) {
        //   Generic Key Validation (Required for all modules) ---
        if (key == null || key.trim().isEmpty()) {
            throw new IllegalArgumentException("Key cannot be null or empty.");
        }
        
        //   Find Insertion/Update Index ---
        int index = find(key);
        
        if (index != -1) {
            // Check if the key was found (USED state with matching key) - this is an UPDATE
            if (hashArray[index].getState() == DSAHashEntry.USED && key.equals(hashArray[index].getKey())) {
                hashArray[index].setValue(value);
            } 
            else {
                // If FREE or PREVIOUSLY_USED, insert new entry
                hashArray[index] = new DSAHashEntry(key, value);
                count++;
                
                // AUTOMATIC RESIZING: Check upper threshold
                if ((double) count / arraySize > UPPER_THRESHOLD) {
                    resize(arraySize * 2);
                }
            }
        }
        else {
            // This case means the table is full (find returned -1)
            System.err.println("[ERROR] Hash table full. FORCING RESIZE to avoid crash.");
            resize(arraySize * 2); 
            put(key, value); // Re-insert into the new table
        }
    }

    /**
     * Now uses Linear Probing logic: h_i = (h0 + i) % M.
     */
    public Object get(String key) {
        // Loop through the probe sequence until the key is found or a FREE slot is hit
        int h0 = hash(key);
        
        for (int i = 0; i < arraySize; i++) {
            // Linear Probing: h_i = (h0 + i) % M
            int index = (h0 + i) % arraySize;
            DSAHashEntry entry = hashArray[index];

            if (entry.getState() == DSAHashEntry.FREE) {
                // Found a free slot, key cannot be further down the probe sequence
                throw new IllegalArgumentException("Key not found: " + key);
            }
            
            if (entry.getState() == DSAHashEntry.USED && entry.getKey().equals(key)) {
                // Key found
                return entry.getValue();
            }
            
            // If PREVIOUSLY_USED or USED with wrong key, continue probing
        }
        
        // Probed all slots and didn't find the key or a FREE slot
        throw new IllegalArgumentException("Key not found: " + key);
    }

    /**
     * Checks if a key exists in the hash table using the find method.
     * Uses a single return statement.
     */
    public boolean hasKey(String key) {
        // The find method returns the index of the key if found (state=USED), 
        // or a potential insertion index (state=FREE/PREV_USED), or -1 if full.
        int index = find(key);
        boolean foundKey = false;
        
        if (index != -1) {
            // Check if the slot returned by find actually contains the key (i.e., state is USED)
            if (hashArray[index].getState() == DSAHashEntry.USED && key.equals(hashArray[index].getKey())) {
                foundKey = true;
            }
        }
        
     
        return foundKey;
    }
    
  
    /**
     * Now uses Linear Probing logic: h_i = (h0 + i) % M.
     */
    public void remove(String key) {
        int h0 = hash(key);
        int i = 0;
        boolean removed = false;
        boolean stopSearch = false;

        // Loop as long as we haven't checked all slots, haven't stopped (FREE slot found), and haven't removed
        while (i < arraySize && !removed && !stopSearch) {
            // Linear Probing: h_i = (h0 + i) % M
            int index = (h0 + i) % arraySize;
            DSAHashEntry entry = hashArray[index];
            
            if (entry.getState() == DSAHashEntry.FREE) {
                // Stop condition: Key not found, cannot be further down the probe sequence
                stopSearch = true; 
            }
            
            else if (entry.getState() == DSAHashEntry.USED && entry.getKey().equals(key)) {
                // Found the key
                hashArray[index].setState(DSAHashEntry.PREVIOUSLY_USED);
                hashArray[index].setKey(null);
                hashArray[index].setValue(null);
                
                count--;
                removed = true; // Set flag for single return

                // AUTOMATIC RESIZING: Check lower threshold
                if ((double) count / arraySize < LOWER_THRESHOLD && arraySize > DEFAULT_SIZE) {
                    resize(arraySize / 2);
                }
            }
            // If PREVIOUSLY_USED or USED with wrong key, continue (i++)
            
            i++;
        }
        
        // Single exit point (throwing an exception for not found)
        if (!removed) {
            throw new IllegalArgumentException("Key not found for removal: " + key);
        }
    }
  
    
    // --- Resizing Helper Methods ---
    
    /** Resizes the hash table to the nearest prime size near newSize. */
    private void resize(int newSize) {
        int oldSize = arraySize;
        DSAHashEntry[] oldArray = hashArray;
        
        // 1. Calculate the new prime size
        // If down-sizing, ensure size doesn't drop below DEFAULT_SIZE
        int targetSize = Math.max(newSize, DEFAULT_SIZE);
        arraySize = nextPrime(targetSize);
        
        // 2. Initialize the new hash array
        hashArray = new DSAHashEntry[arraySize];
        // Reset count *before* re-inserting, as put() increments it.
        count = 0; 
        
        for (int i = 0; i < arraySize; i++) {
            hashArray[i] = new DSAHashEntry();
        }
        
        // 3. Re-hash old entries into the new array
        System.out.println("\n*** Resizing from " + oldSize + " to " + arraySize + " ***");
        for (int i = 0; i < oldSize; i++) {
            if (oldArray[i].getState() == DSAHashEntry.USED) {
                // The put() method handles the re-insertion and incrementing of 'count'.
                put(oldArray[i].getKey(), oldArray[i].getValue());
            }
        }
        System.out.println("*** Resize Complete ***\n");
    }

    /** Finds the next prime number. */
    private int nextPrime(int startVal) {
        int result;

        if (startVal <= 2) {
            // Handle the smallest primes (1, 2, 3)
            result = 3;
        } else {
            // Set the starting point for the search
            result = startVal;
            
            // If the starting number is even, increment it to start checking from an odd number
            if (result % 2 == 0) {
                result++;
            }
            
            // Loop until a prime number is found
            while (!isPrime(result)) {
                result += 2; // Check only odd numbers
            }
        }
        
        return result;
    }

    
    /** Checks if a number is prime. */
    private boolean isPrime(int num) {
        boolean is_prime;

        if (num <= 1) {
            is_prime = false;
        } else if (num <= 3) {
            is_prime = true;
        } else if (num % 2 == 0 || num % 3 == 0) {
            // Not prime if divisible by 2 or 3
            is_prime = false;
        } else {
            // Assume prime until a factor is found
            is_prime = true; 
            
            // Optimized check without using 'break': The while loop condition controls the exit.
            int i = 5;
            while (i * i <= num && is_prime) {
                if (num % i == 0 || num % (i + 2) == 0) {
                    is_prime = false; // Found a factor
                }
                i += 6; // Check numbers of the form 6k ± 1
            }
        }
        
        return is_prime;
    }
}