/* Author:Nallaperuma Arachchilage Spencer Sterling Wickramaratne
 * Curtin ID: 23120839
 * References:Lecture slides and practical 09 submission
 * DSASorts.java
 * Holds static sort methods (Merge Sort and Quick Sort) for Patient objects, 
 */
public class DSASorts {

    // --- Private Helper ---
    private static void swap(Patient[] A, int idx1, int idx2) {
        Patient temp = A[idx1];
        A[idx1] = A[idx2];
        A[idx2] = temp;
    }

    //  MERGE SORT (Top-Down)

    /** Wrapper method to initiate Merge Sort. */
    public static void mergeSort(Patient[] arr) {
        if (arr != null && arr.length > 1) {
            mergeSortRecurse(arr, 0, arr.length - 1);
        }
    }

    /** Recursive method for Merge Sort. */
    private static void mergeSortRecurse(Patient[] arr, int leftIdx, int rightIdx) {
        if (leftIdx < rightIdx) {
            int midIdx = leftIdx + (rightIdx - leftIdx) / 2;
            mergeSortRecurse(arr, leftIdx, midIdx);
            mergeSortRecurse(arr, midIdx + 1, rightIdx);
            merge(arr, leftIdx, midIdx, rightIdx);
        }
    }
    
    /** Merges two sorted sub-arrays using Patient.getDuration() for comparison. */
    private static void merge(Patient[] arr, int leftIdx, int midIdx, int rightIdx) {
        int sizeLeft = midIdx - leftIdx + 1;
        int sizeRight = rightIdx - midIdx;

        Patient[] leftArr = new Patient[sizeLeft];
        Patient[] rightArr = new Patient[sizeRight];

        for (int i = 0; i < sizeLeft; i++) {
            leftArr[i] = arr[leftIdx + i];
        }
        for (int j = 0; j < sizeRight; j++) {
            rightArr[j] = arr[midIdx + 1 + j];
        }

        int i = 0, j = 0; 
        int k = leftIdx;  

        // Merge using direct duration comparison (Patient.getDuration())
        while (i < sizeLeft && j < sizeRight) {
            if (leftArr[i].getDuration() <= rightArr[j].getDuration()) { 
                arr[k] = leftArr[i];
                i++;
            } else {
                arr[k] = rightArr[j];
                j++;
            }
            k++;
        }

        // Copy remaining elements
        while (i < sizeLeft) {
            arr[k] = leftArr[i];
            i++;
            k++;
        }
        while (j < sizeRight) {
            arr[k] = rightArr[j];
            j++;
            k++;
        }
    }

    // QUICK SORT (Median of Three Pivot) 
    
    /** Wrapper method to initiate Quick Sort (Median-of-Three). */
    public static void quickSort(Patient[] arr) {
        if (arr != null && arr.length > 1) {
            quickSortRecurse(arr, 0, arr.length - 1);
        }
    }

    /** Recursive method for Quick Sort. */
    private static void quickSortRecurse(Patient[] arr, int leftIdx, int rightIdx) {
        if (rightIdx > leftIdx) {
            int pivotIdx = findMedianOfThree(arr, leftIdx, rightIdx);
            int newPivotIdx = doPartitioning(arr, leftIdx, rightIdx, pivotIdx);
            
            quickSortRecurse(arr, leftIdx, newPivotIdx - 1);
            quickSortRecurse(arr, newPivotIdx + 1, rightIdx);
        }
    }
    
    /** Selects the pivot index by finding the median of the first, middle, and last elements. */
    private static int findMedianOfThree(Patient[] arr, int leftIdx, int rightIdx) {
        int centerIdx = leftIdx + (rightIdx - leftIdx) / 2;

        // Sort left, center, and right elements using direct duration comparison
        if (arr[leftIdx].getDuration() > arr[centerIdx].getDuration()) {
            swap(arr, leftIdx, centerIdx);
        }
        if (arr[leftIdx].getDuration() > arr[rightIdx].getDuration()) {
            swap(arr, leftIdx, rightIdx);
        }
        if (arr[centerIdx].getDuration() > arr[rightIdx].getDuration()) {
            swap(arr, centerIdx, rightIdx);
        }

        return centerIdx;
    }

    /** Partitions the array segment around the pivot using Patient.getDuration(). */
    private static int doPartitioning(Patient[] arr, int leftIdx, int rightIdx, int pivotIdx) {
        Patient pivotVal = arr[pivotIdx];
        swap(arr, pivotIdx, rightIdx); 

        int curr = leftIdx; 

        for (int ii = leftIdx; ii <= rightIdx - 1; ii++) {
            if (arr[ii].getDuration() < pivotVal.getDuration()) {
                swap(arr, ii, curr); 
                curr++;
            }
        }

        swap(arr, curr, rightIdx);
        return curr;
    }
}

