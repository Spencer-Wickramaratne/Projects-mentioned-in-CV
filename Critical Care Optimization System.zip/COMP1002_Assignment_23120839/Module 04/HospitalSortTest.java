/* Author:Nallaperuma Arachchilage Spencer Sterling Wickramaratne
 * Curtin ID: 23120839
 * HospitalSortTest.java
 * Test harness to verify the correctness of DSASorts implementations
 * on required dataset sizes and conditions.
 */
import java.util.Random;

public class HospitalSortTest {

    private static final int SEED = 50;
    private static int totalTests = 0;
    private static int passedTests = 0;
    private static int failedTests = 0;
    private static final double MAX_DURATION = 120.0; 

    public static void main(String[] args) {
        System.out.println("--- Hospital Sort Test Harness ---");
        System.out.println("Verifying DSASorts Correctness (Sorting by Duration)");
        
        int[] sizes = {100, 500, 1000};
        String[] types = {"Random", "Nearly Sorted", "Reversed"};

        for (int size : sizes) {
            for (String type : types) {
                // Test Merge Sort
                runTest(size, type, "Merge Sort");
                // Test Quick Sort
                runTest(size, type, "Quick Sort");
            }
        }

        System.out.println("\n--- Test Results Summary ---");
        System.out.println("Total Tests Run:    " + totalTests);
        System.out.println("Tests Passed:       " + passedTests);
        System.out.println("Tests Failed:       " + failedTests);
        System.out.println("----------------------------");
        if (failedTests == 0) {
            System.out.println("RESULT: All sorting algorithms passed the correctness checks. ");
        } else {
            System.out.println("RESULT: **CRITICAL** Failures detected. Check error logs above. ");
        }
    }

    /** Runs a single test and updates the counters. */
    private static void runTest(int size, String type, String algorithm) {
        totalTests++;
        try {
            // Generate deterministic data
            Patient[] arr = generateData(size, type, SEED);
            
            // Execute Sort
            if (algorithm.equals("Merge Sort")) {
                DSASorts.mergeSort(arr);
            } else if (algorithm.equals("Quick Sort")) {
                DSASorts.quickSort(arr);
            } else {
                throw new IllegalArgumentException("Unknown algorithm.");
            }
            
            // Check Correctness
            if (checkSorted(arr)) {
                System.out.printf("[PASS] %s: Size %d, Type %s\n", algorithm, size, type);
                passedTests++;
            } else {
                System.out.printf("[FAIL] %s: Size %d, Type %s. Not correctly sorted.\n", algorithm, size, type);
                failedTests++;
            }
        } catch (Exception e) {
            System.err.printf("[ERROR] %s: Size %d, Type %s failed with exception: %s\n", algorithm, size, type, e.getMessage());
            failedTests++;
        }
    }

    /** * Verifies if the array is correctly sorted using getDuration(). 
    
     */
    private static boolean checkSorted(Patient[] arr) {
        boolean isSorted = true;
        
        for (int i = 0; i < arr.length - 1; i++) {
            // Direct comparison using duration
            if (arr[i].getDuration() > arr[i + 1].getDuration()) {
                isSorted = false;
                break; // Use break to exit the loop early, preventing non-switch break in outer context
            }
        }
        
        // Single return statement
        return isSorted;
    }
    
    /** Generates patient data based on the required type and seed. */
    private static Patient[] generateData(int size, String type, int seed) {
        Random rand = new Random(seed);
        Patient[] arr = new Patient[size];
        
        for (int i = 0; i < size; i++) {
            double duration;
            if (type.equals("Random")) {
                duration = rand.nextDouble() * MAX_DURATION + 0.1;
            } else if (type.equals("Reversed")) {
                // Creates descending order
                duration = MAX_DURATION - ((double)i / size) * MAX_DURATION;
            } else { // Nearly Sorted (Base ascending order)
                duration = ((double)i / size) * MAX_DURATION + 0.1;
            }

            
            // The Patient class's 6-argument constructor handles the default status.
            arr[i] = new Patient(
                String.valueOf(i + 100), "Name" + i, rand.nextInt(80) + 1, "ER", 
                rand.nextInt(5) + 1, duration          
            );
        }
        
        // Introduce disorder for Nearly Sorted
        if (type.equals("Nearly Sorted")) {
            int displacements = (int) (size * 0.10); 
            for (int i = 0; i < displacements; i++) {
                int idx1 = rand.nextInt(size);
                int idx2 = rand.nextInt(size);
                Patient temp = arr[idx1];
                arr[idx1] = arr[idx2];
                arr[idx2] = temp;
            }
        }
        
        return arr;
    }
}