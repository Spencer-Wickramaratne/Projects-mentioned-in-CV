package edu.curtin.app;
import java.util.*;

public class ReportFunding implements ReportInterface 
{
     @Override
    public void perform(Scanner sc,Map<Integer,RegionInterface> regions, RegionInterface glRegion)
    {/*this is used to implement the fourth option of App.java which is to report the avenues of funding in a rgion */
        System.out.println("Enter Region Id or Name to view the funding: ");
        String input= sc.nextLine();
        List<RegionInterface> matches = findRegion(input,regions);
        if (matches.isEmpty())
            {
              System.out.println("Region cannot be found! ");
              return;
            }
        RegionInterface target;
        if(matches.size()>1)
        {
         System.out.println("ultiple regions found with that names so please entr a specific ID ");
         for (RegionInterface r:matches)
         {
            System.out.println("ID: "+r.getId()+" | Name:"+ r.getName());
         }
         try
         {
            int id =Integer.parseInt(sc.nextLine().trim());
            target=regions.get(id);

         }
         catch(NumberFormatException e)
         {
            System.out.println("Invalid ID format");
            return;
         }
        }
        else
        {
            target=matches.get(0);
        }
        if (target== null)
        {
          System.out.println("Region cannot be found");
          return;
        }
        
        Map<String,Double> fundingTotals= new HashMap<>();
        for(Funding f : target.getAllFunding())
        {
            String source=f.getSource();
            double current=fundingTotals.getOrDefault(source,0.0 );
            fundingTotals.put(source,current +f.getAmount());

        }
        if(fundingTotals.isEmpty())
        {
            System.out.println("No fudning recorded for this region");
        }
        else
        {
            System.out.println("\n Funding is provided as follows for "+target.getName()+" (including the sub regions):");
            for(Map.Entry<String,Double> entry: fundingTotals.entrySet())
            {
               System.out.printf("-%s: $%.2f%n", entry.getKey(),entry.getValue());
            }
        }

    }
    //same as the private helper method in ReportDisease.java
     private List<RegionInterface> findRegion(String input,Map<Integer,RegionInterface> regions)
    {
        List<RegionInterface> matches=new ArrayList<>(); 
        try
         {
           int id =Integer.parseInt(input.trim());
           RegionInterface r= regions.get(id);
           if (r!= null)
           {
            matches.add(r);
           }
         } catch(NumberFormatException e) 
         {
            for(RegionInterface r : regions.values())
            {
                if(r.getName().equalsIgnoreCase(input.trim()))
                {
                    matches.add(r);
                }
            }
         }
        
         return matches;
    }
}
