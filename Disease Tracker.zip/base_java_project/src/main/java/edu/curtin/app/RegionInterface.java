package edu.curtin.app;
import java.util.*;

/*a composite pattern is used to represent the hireachcical structure of regions and this interface acts as a component that defines thw options
available for both individual regions and composite regions */
public interface RegionInterface {
    int getId();
    String getName();
    List<Survey>getAllSurveys();
    List<Funding>getAllFunding();
    List<RegionInterface>getSubRegions();
    void addSubRegion(RegionInterface component);
    void addSurvey(Survey survey);
    void addFunding(Funding funfing);


    
}
