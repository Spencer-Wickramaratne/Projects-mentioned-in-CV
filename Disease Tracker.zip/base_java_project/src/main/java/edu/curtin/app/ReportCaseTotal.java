package edu.curtin.app;
import java.util.*;

public class ReportCaseTotal implements ReportInterface
{/**this  file implements the second option in the App.java file which is to list the total cases of a diseases in a partcular region */
    
    @Override
    public void perform(Scanner sc,Map<Integer,RegionInterface> regions, RegionInterface glRegion)
    {
        System.out.println("Enter disease name: ");
        String disease= sc.nextLine();
        int total =0;
        for(Survey s: glRegion.getAllSurveys())
        {
            if(s.getDisease().equalsIgnoreCase(disease))
            {
               total+=s.getCases();
            }
            
        }
        System.out.println("\nTotal cases for disease "+disease + " globally: "+total  );
    }
}
