package edu.curtin.app;
import java.util.*;

public class ReportDisease implements ReportInterface 
{/*this code file implements the first option of the App.java file and report all diseases in a particular rgion */
    @Override
    public void perform(Scanner sc,Map<Integer,RegionInterface> regions, RegionInterface glRegion)
    {
        System.out.println("Enter Region Id or Name: ");
        String input= sc.nextLine();
        List<RegionInterface> matches = findRegion(input,regions);
        if (matches.isEmpty())
            {
              System.out.println("Region cannot be found! ");
              return;
            }
        RegionInterface target ;
        if(matches.size()>1)
        {
         System.out.println("Multiple regions found with that names so please entr a specific ID ");
         for (RegionInterface r:matches)
         {
            System.out.println("ID: "+r.getId()+" | Name:"+ r.getName());
         }
         try
         {
            int id =Integer.parseInt(sc.nextLine().trim());
            target=regions.get(id);

         }
         catch(NumberFormatException e)
         {
            System.out.println("Invalid ID format");
            return;
         }
        }
        else
        {
            target=matches.get(0);
        }
        if (target== null)
        {
          System.out.println("Region cannot be found");
          return;
        }

        
        Set <String> diseases =new HashSet<>();
        collectDiseasesRecursive(target,diseases);

      
        System.out.println("\nDiseases recorded in "+target.getName()+ " (including the sub regions):" );
        if (diseases.isEmpty())
        {
         System.out.println("No diseases recorded");
        }
        else
        {
          for (String d:diseases)
           {
            System.out.println("- "+ d);
           }
        }
    }
    private void collectDiseasesRecursive(RegionInterface region, Set<String> diseases)
    {
        for (Survey s:region.getAllSurveys())
        {
            diseases.add(s.getDisease());
        }
        for (RegionInterface sub:region.getSubRegions())
        {
            collectDiseasesRecursive(sub, diseases);
        }
    }


    private List<RegionInterface> findRegion(String input,Map<Integer,RegionInterface> regions)
    {
        List<RegionInterface> matches=new ArrayList<>(); 
        try
         {
           int id =Integer.parseInt(input.trim());
           RegionInterface r= regions.get(id);
           if (r!= null)
           {
            matches.add(r);
           }
         } catch(NumberFormatException e) 
         {
            for(RegionInterface r : regions.values())
            {
                if(r.getName().equalsIgnoreCase(input.trim()))
                {
                    matches.add(r);
                }
            }
         }
        
         return matches;
    }
}
