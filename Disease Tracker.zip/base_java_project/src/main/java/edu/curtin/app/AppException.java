package edu.curtin.app;
/*this is the custom exception i made */
public class AppException extends Exception {
    public AppException(String message)
    {
        super(message);
    }
     public AppException(String message, Throwable cause)
    {
        super(message,cause);
    }
    
}
