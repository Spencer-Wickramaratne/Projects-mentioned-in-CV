package edu.curtin.app;
import java.util.*
;
public class ReportCaseByYear implements ReportInterface 
{   
    @Override
    public void perform(Scanner sc,Map<Integer,RegionInterface> regions, RegionInterface glRegion)
    {/*this is used to implement the third option of App.java which is to list the number of cases by year for a particlar disese */
        System.out.println("Enter disease name: ");
        String disease= sc.nextLine();
        Map<Integer,Integer> totalsPerYear= new TreeMap<>();
        for(Survey s: glRegion.getAllSurveys())
        {
            if(s.getDisease().equalsIgnoreCase(disease))
            {
               int year= s.getYear();
               int presentCases=totalsPerYear.getOrDefault(year,0);
               totalsPerYear.put(year,presentCases+s.getCases());
            }
        }
        if(totalsPerYear.isEmpty())
        {
            System.out.println("No cases can be found for "+ disease);
        }
        else
        {
            System.out.println("\n Yearly cases found for "+ disease+":");
            for(Map.Entry<Integer,Integer> entry: totalsPerYear.entrySet())
            {
              System.out.println(entry.getKey() + " :" + entry.getValue()+ " cases ");
            }
        }

    } 
}
