package edu.curtin.app;

public class Funding {
    /*ive used final here so that the feilds do not get changed over the course of the project */
    private final String source;
    private final double amount;
    private final String currency;


    public Funding (String source,double amount,String currency)
    {
        this.source=source;
        this.amount=amount;
        this.currency=currency;
    }
    public String getSource()
    {
        return source;
    }
    public double getAmount()
    {
        return amount;
    }
    public String getCurrency()
    {
        return currency;
    }
}
