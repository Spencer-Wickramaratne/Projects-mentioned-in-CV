package edu.curtin.app;
import java.util.*;
/*this class implements the methods getAllSurveys() and getAllFunding() by iterating thorugh its own daata and recursively
calling the same methods on its children to aggregate the results and the whole compositw strucuture is built in the DataReader file */
public class Region implements RegionInterface {
     private final int id;
     private final String name;
     private final List<RegionInterface> subRegions;
     private final List<Survey> surveys;
     private final List<Funding> fundings;

     public Region(int id,String name)
     {
        this.id=id;
        this.name=name;
        this.subRegions=new ArrayList<>();
        this.surveys=new ArrayList<>();
        this.fundings=new ArrayList<>();

     }
    @Override
    public  int getId()
    {
        return id;
    
    }
    @Override
    public  String getName()
    {
        return name;
    
    }
    @Override
    public  void addSubRegion(RegionInterface component)
    {
        subRegions.add(component);
    
    }
    @Override
    public  void addSurvey(Survey survey)
    {
        surveys.add(survey);
    
    }
    @Override
    public  void addFunding(Funding funding)
    {
        fundings.add(funding);
    
    }
    @Override
    public List<Survey>getAllSurveys()
    {
        List<Survey> allSurveys =new ArrayList<>(this.surveys);
        for (RegionInterface child: subRegions)
        {
            allSurveys.addAll(child.getAllSurveys());
        }
        return allSurveys;
    }
    @Override
    public List<Funding>getAllFunding()
    {
        List<Funding> allFunding = new ArrayList<>(this.fundings);
        for (RegionInterface child: subRegions)
        {
            allFunding.addAll(child.getAllFunding());
        }
        return allFunding;
    }
    @Override
    public List<RegionInterface> getSubRegions()
    {
        return subRegions;
    }




     


    
}
