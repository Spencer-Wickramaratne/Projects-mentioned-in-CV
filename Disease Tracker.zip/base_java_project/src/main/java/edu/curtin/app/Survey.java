package edu.curtin.app;

public class Survey {
    /*similar to the Funding.java file ive used final here so that the fields do not get changed over the course of the project */
    private final String disease;
    private final int year;
    private final int cases;

    public Survey(String disease,int year,int cases)
    {
        this.disease=disease;
        this.year=year;
        this.cases=cases;
        
    }

    public String getDisease()
    {
        return disease;
    }
    public int getYear()
    {
        return year;
    }
    public int getCases()
    {
        return cases;
    }

    
}
