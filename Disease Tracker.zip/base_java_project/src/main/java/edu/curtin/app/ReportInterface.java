package edu.curtin.app;
import java.util.*;

/*here a common method is induced as it is needed to handle the four types of reports that must be implemented without
neediing to know the speicific logic for each report type(strategy pattern).Each of the files such as ReportDisease.java,ReportCaseTotal.Java, 
ReportCaseByYear.java and ReportFunding.java contains a specific algorithm to genrate each repport*/
public interface ReportInterface {
    void perform(Scanner sc,Map<Integer,RegionInterface> regions, RegionInterface glRegion);
    
}
