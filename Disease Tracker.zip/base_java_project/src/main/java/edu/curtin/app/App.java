package edu.curtin.app;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Entry point into the application. To change the package, and/or the name of this class, make
 * sure to update the 'mainClass = ...' line in build.gradle.
 */
public class App
{   
    private static final Logger LOGGER=Logger.getLogger(App.class.getName());
    public static void main(String[] args)
    {   
        if (args.length<1)
        {
            System.out.println("Usage:gradle run --args=\"datafile.txt\"");
            return;
        }
        DataReader reader=new DataReader();
        try
        {
            Map<Integer,RegionInterface>regions=reader.parseFile(args[0]);
            RegionInterface glRegion=regions.get(0);
            runMenu(regions,glRegion);   
        }catch(AppException e)
        {
            LOGGER.log(Level.SEVERE,e, () -> "Proejct failed to initialize" + e.getMessage());
        }   
    }

    private static void runMenu(Map<Integer,RegionInterface>regions,RegionInterface glRegion)
    {
        Map<String,ReportInterface>options= new HashMap<>();
        options.put("1", new ReportDisease());
        options.put("2", new ReportCaseTotal());
        options.put("3", new ReportCaseByYear());
        options.put("4", new ReportFunding());
        try(Scanner sc = new Scanner(System.in))
        {
          String choice="";

            while(!"5".equals(choice))
            {
                System.out.println("\n *Disease Tracking System*");
                System.out.println("1. List all the diseases in a region");
                System.out.println("2. Total number of cases for a particular disease");
                System.out.println("3. List cases by year for a particular disease");
                System.out.println("4. Funding for a particular region elucidated ");
                System.out.println("5. Exit");
                System.out.println("Enter your option:");
                

                choice = sc.nextLine();

                ReportInterface tact =options.get(choice);
                if (tact!=null)
                {
                    tact.perform(sc,regions,glRegion);
                }
                else if (!"5".equals(choice))
                {
                    System.out.println("Ivalid option.Try again.");
                }


            }
        }
        
    }
}
