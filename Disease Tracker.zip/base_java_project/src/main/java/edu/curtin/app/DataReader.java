package edu.curtin.app;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/*the file reading aspect relevant to the included data file is implemented here */

public class DataReader {
    private static final Logger LOGGER = Logger.getLogger(DataReader.class.getName());
    public Map<Integer,RegionInterface> parseFile(String filename) throws AppException
    {
        Map<Integer,RegionInterface>regionMap= new HashMap<>();

        // the global region is initialised
        RegionInterface glRegion= new Region(0,"Global");
        regionMap.put(0,glRegion);

        try(BufferedReader reader= new BufferedReader(new FileReader(filename)))
        {
            String line;
            while((line=reader.readLine())!= null)
            {
                processline(line.trim(),regionMap);
            }
            LOGGER.log(Level.INFO, () -> "Data sucessfully from"+ filename);
        }
        catch(IOException e)
        {
            throw new AppException("Failed to read the input data file",e);
        } 
        return regionMap;
   }

    private void processline( String line, Map<Integer,RegionInterface> regionMap)
    {
        if (line.isEmpty())
        {
            return;
        }
        
        try 
        {
            //this is for REGION: (region id 1 parent 0 name South-America)
            if(line.startsWith("(region"))
            {
                int id = Integer.parseInt(extract(line,"id"));
                int parentId=Integer.parseInt(extract(line,"parent"));
                String name=extract(line,"name").replace(")", "");
                RegionInterface newRegion= new Region(id, name);
                regionMap.put(id, newRegion);
                RegionInterface parent=regionMap.get(parentId);
                if (parent!=null)
                {
                    parent.addSubRegion(newRegion);
                }

            }
            //this is for SURVEY: (survey region 651 disease RQ-160 year 2024 cases 9044)
            else if(line.startsWith("(survey"))
            {
                 int regionId = Integer.parseInt(extract(line,"region"));
                  String disease=extract(line,"disease");
                int year=Integer.parseInt(extract(line,"year"));
                 int cases=Integer.parseInt(extract(line,"cases").replace(")", ""));
                 RegionInterface tRegion=regionMap.get(regionId);
                if (tRegion!=null)
                {
                    tRegion.addSurvey(new Survey(disease, year, cases));
                }
                 
            }
            //this is for FUNDING(Format extension area):FUNDING,1,Government,50000.00,EUR
            else if(line.startsWith("FUNDING"))
            {
                String parts[] = line.split(",");
                if(parts.length>=5)
                {
                  int fRegionId=Integer.parseInt(parts[1].trim());
                  String source=parts[2].trim();
                  Double amt=Double.parseDouble(parts[3].trim());
                  String currency=parts[4].trim();
                  RegionInterface fRegion= regionMap.get(fRegionId);
                  if (fRegion!=null)
                    {
                        fRegion.addFunding(new Funding(source,amt,currency));

                    }
                }
                else
                {
                  LOGGER.log(Level.WARNING, () -> "Funding line has insufficent funds{0}"+line);
                }
            }      
            else
                {
                  LOGGER.log(Level.WARNING, () ->  "Unkniwn file format{0}"+line);
                }   
            

        }catch( NumberFormatException e)
            {
                LOGGER.log(Level.WARNING, () ->  "Slipping erroneous line: "+line +"-"+e.getMessage());
            }
    }

    /*hlper method used for extraction of data segmentally from each line of the data file */
    private String extract(String line,String label)
    {   
        String result= "";
        String[] split= line.split(label + " ");
        if(split.length>1)
        {
            result=split[1].split(" ")[0];
        }
        return result;

    }
}
