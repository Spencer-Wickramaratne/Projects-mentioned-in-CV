package edu.curtin.app;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.extension.ExtensionContext;
import org.junit.jupiter.api.extension.TestWatcher;
import static org.junit.jupiter.api.Assertions.*;
import java.util.*;


@ExtendWith(AppTest.ResultTracker.class)

/*References to create this Test Harness : https://docs.junit.org/6.0.3/overview.html and https://www.tutorialspoint.com/junit/index.html 
and ive used this to see how @ExtendWith and @AfterAll and TestWatcher class are used as i want to keep track of the number of tests passed,
failed and conducted*/

public class AppTest
{
    private static int testsRun=0;
    private static int testsPassed = 0;
    private static int testsFailed= 0;
    
    //this is a custom class to keep track and provide the overall test report
    public static class ResultTracker implements TestWatcher
    {
      @Override
      public void testSuccessful(ExtensionContext context)
      {
        testsRun++;
        testsPassed++;

      }
      @Override
      public void testFailed(ExtensionContext context, Throwable cause)
      {
        testsRun++;
        testsFailed++;
      }
    }

    @AfterAll
    static void printSummary()
    {
     System.out.println("***** TESTING OVERALL REPORT *****");
     System.out.println("Total Tests Run: "+testsRun);
     System.out.println("Total Tests Passed: "+   testsPassed);
     System.out.println("Total Tests Failed: "+    testsFailed);

    }
    
    //Helper method to load data from the test file
    private Map<Integer,RegionInterface> loadData() throws AppException
    {
        DataReader reader = new DataReader();
        return reader.parseFile("epidemiology-1.txt");
    }

    @Test
    @DisplayName("Test the file reading functionality")
    void testFileReading()
    {
    try
    {
        Map<Integer,RegionInterface>regions=loadData();
        assertNotNull(regions,"Region Map should not be null");
        assertFalse(regions.isEmpty(),"Region Map should not be empty");
         assertTrue(regions.containsKey(0),"Global region (id 0) should exist");
         assertTrue(regions.containsKey(1),"Region 1 (Pacific) should exist");
        assertEquals("Pacific", regions.get(1).getName(),"Region 1 name should be Pacific");

        assertTrue(regions.containsKey(8),"Region 8 (Europe) should exist");

    }catch(AppException e)
    {
        fail("Failed to pass the epidemiology-1.txt file");

    }


    }
    @Test
    @DisplayName("Functionality 1:List all diseases in a region (recursively)")
    void testDiseaseListing() throws AppException
    {
    Map<Integer,RegionInterface> regions=loadData();
    RegionInterface eastern=regions.get(4);
    assertNotNull(eastern,"Region  4(eastern) should not be null");
    Set<String> diseases=new HashSet<>();
    for(Survey s:eastern.getAllSurveys())
    {
        diseases.add(s.getDisease());
    }
    assertTrue(diseases.contains("PP-499"),"Should contain PP-499");
    assertTrue(diseases.contains("WI-744"),"Should contain WI-744");
    assertTrue(diseases.contains("ET-798"),"Should contain ET-798");
    assertEquals(3, diseases.size(), "There should be 3 unique diseases");

    }
    @Test
    @DisplayName("Included in Functionality 1 and 4 :Handle non unique region names")
    void testNonUniqueRegionNames() throws AppException
    {
       Map<Integer,RegionInterface> regions=loadData();
       String duplicateName="Western";
       List<RegionInterface>matches= new ArrayList<>();
       for(RegionInterface r: regions.values())
        {
           if(r.getName().equalsIgnoreCase(duplicateName))
          {
            matches.add(r);
          }
        } 
        assertTrue(matches.size()>=1,"Should find at least one region for the name");
        Set<Integer> uniqueIds= new HashSet<>();
        for(RegionInterface r:matches)
        {
            uniqueIds.add(r.getId());

        }
        assertEquals(matches.size(),uniqueIds.size(),"Each matched region should have a unique ID");
    }







    @Test
    @DisplayName("Functionality 2:List total cases for a particular diseae globally")
    void testTotalCases() throws AppException
    {
        Map<Integer,RegionInterface> regions=loadData();
        RegionInterface glRegion=regions.get(0);
        int total=0;
        String target ="PP-499";
        for (Survey s:glRegion.getAllSurveys())
        {
        if(s.getDisease().equalsIgnoreCase(target))
        {
            total+=s.getCases();
        }
        }
        assertEquals(241506, total, "Total cases for disease PP-499 should match correctly");


    }

    @Test
    @DisplayName("Functionality 3:List  cases by year for a particular diseae globally")
    void testCasesByYear() throws AppException
    {
        Map<Integer,RegionInterface> regions=loadData();
        RegionInterface glRegion=regions.get(0);
        String target ="PP-499";
        Map<Integer,Integer>totalsPerYear=new TreeMap<>();
        for (Survey s:glRegion.getAllSurveys())
        {
        if(s.getDisease().equalsIgnoreCase(target))
        {
            int year=s.getYear();
            int currentCases=totalsPerYear.getOrDefault(year,0 );
            totalsPerYear.put(year,currentCases+s.getCases() );

        }
        }
        assertEquals(68874, totalsPerYear.get(2020), "Cases for 2020 should be 68874");
        assertEquals(172123, totalsPerYear.get(2021), "Cases for 2021 should be 172123");
         assertEquals(0, totalsPerYear.get(2022), "Cases for 2022 should be 0");
         assertEquals(509, totalsPerYear.get(2023), "Cases for 2023 should be 509");
        assertNull(totalsPerYear.get(2024),"There should be no cases for PP-499 IN 2024");
    }

    @Test
    @DisplayName("Functionality 4:Funding for a pticular region elucidated")
    void testFundingPart() throws AppException
    {
        Map<Integer,RegionInterface> regions=loadData();
        RegionInterface pacific=regions.get(1);
        Map<String,Double>fundingTotals=new HashMap<>();
        for(Funding f:pacific.getAllFunding())
        {
        String source=f.getSource();
        double current=fundingTotals.getOrDefault(source, 0.0);
        fundingTotals.put(source,current+f.getAmount());
        }
        assertTrue(fundingTotals.containsKey("Government"));
         assertEquals(50000.00, fundingTotals.get("Government"), 0.001);
        assertTrue(fundingTotals.containsKey("Commercial"));
         assertEquals(25000.00, fundingTotals.get("Commercial"), 0.001);
         assertTrue(fundingTotals.containsKey("Charity"));
        assertEquals(14500.50, fundingTotals.get("Charity"), 0.001);

    }


       





}


