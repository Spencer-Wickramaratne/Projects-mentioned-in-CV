Name:Nallaperuma Aarachchilage Spencer Sterling Wickramaratne
CurtinID: 23120839

**File Structure Details

    main.c: Handles file I/O, thread creation, and final reporting.

    validators.c: Contains the logic for the four worker threads and the synchronized score updates.

    magic_square.h: The header file defining the shared data structures and function prototypes.

    valid_3.txt / invalid_3.txt/ valid_4.txt : Input files containing the matrix size n and the n×n grid
    
** Compilation Instructions

   The project uses a Makefile to automate the build process. Open your terminal in the project directory and run:
   

    * make

    What this does: Compiles main.c and validators.c into object files and links them to create the executable named magic_validator.

** Running the Program

   You can run the program manually or use the built-in Makefile shortcuts.

   Option A: Using Makefile Shortcuts (Recommended)
   To test with the provided sample files:

    For a Valid Magic Square with n=3:
  

    * make run_valid

    For an Invalid Magic Square with n=3:
  

    * make run_invalid

    For a Valid Magic Square with n=4:
   

    * make run_valid4

   Option B: Manual Execution
   To run the validator on any specific text file:
  

    * ./magic_validator <filename.txt>

     Example: ./magic_validator valid_3.txt


** Memory Leak Testing

    To ensure all dynamically allocated memory (matrix, status arrays, etc.) is properly freed, use Valgrind:
    

     * make check_leaks
    
    Below is the alternative
   

     * valgrind --leak-check=full ./magic_validator valid_3.txt

     Look for the message: All heap blocks were freed -- no leaks are possible.

** Cleanup

    To remove the compiled object files and the executable to start fresh:
    

     * make clean

