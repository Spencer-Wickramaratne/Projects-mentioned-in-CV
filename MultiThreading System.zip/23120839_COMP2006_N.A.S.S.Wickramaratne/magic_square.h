/*Name:Nallaperuma Arachchilage Spencer Sterling Wickramaratne
 *Curtin ID:23120839
 *File Name:magic_square.h
 *Purpose:It contains the definitions of the MagicSquareData  and Threadargs structures, as well as 
          function prototypes and constant macros (STATUS_PASS,STATUS_FAIL).By centralizing these definitions, we ensure that both the main
          driver and the validator functions are operating on the exact same data formats. The use of include guards (#ifndef,#define) 
          prevents compilation errors caused by double definitions.
 *Date:27.04.2026*/

#ifndef MAGIC_SQUARE_H
#define MAGIC_SQUARE_H
#include <pthread.h>
#include <stdbool.h>
#define STATUS_PASS 1
#define STATUS_FAIL 2

typedef struct{
    int **matrix;
    int n;
    int magic_constant;
    int global_score;
    pthread_mutex_t mutex;
    int *row_status;
    int *col_status;
    int *diag_status;
    int unique_status;


}MagicSquareData;

//struct to pass logical ID to threads
typedef struct {
    MagicSquareData *data;
    int logical_id;
} ThreadArgs;

void* check_rows(void* arg);
void* check_columns(void* arg);
void* check_diagonals(void* arg);
void* check_uniqueness(void* arg);
void update_score(MagicSquareData *data, bool success);
int get_tid(void);
#endif


