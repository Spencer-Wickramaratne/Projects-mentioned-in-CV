/*Name:Nallaperuma Arachchilage Spencer Sterling Wickramaratne
 *Curtin ID:23120839
 *File Name:validators.c
 *Purpose:Performs the validation functionality for rows,columns,diagonals and uniqueness.
          Isolating the worker logic here keeps the mathematical and multi-threading complexities separate from 
          the user interface and file handling logic. 
          This allows a developer to modify the validation rules (e.g. changing how a diagonal is summed)
          without touching the orchestration code in main.c.
 *Date:27.04.2026*/

#include "magic_square.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>


void update_score(MagicSquareData *data,bool success)
{   
  //ENTRY SECTION: Acquire mutex lock to ensure exclusive access to global_score 
    pthread_mutex_lock(&data->mutex);

    //CRITICAL SECTION: Modifying shared resource based on thread validation result
    if (success)
    {
        data->global_score+=1; // Requirement: increase if passed
    }
    else
    {    //Floor-at-zero logic: ensures score doesn't become negative if failures happen early
        // Only subtract if we have points to lose
        if (data->global_score > 0) 
        {
            data->global_score -= 1;// Requirement: decrease if failed
        }
    }
    pthread_mutex_unlock(&data->mutex);

    
}

void* check_rows(void* arg)
{
  ThreadArgs *t_arg = (ThreadArgs *)arg;
  MagicSquareData *data = t_arg->data;
  for(int i=0;i<data->n;i++)
  {
    int sum=0;
    for(int j=0;j<data->n;j++)
    {
        sum+=data->matrix[i][j];
    }
    // Check if current row matches the mathematical Magic Constant
    bool valid=(sum== data->magic_constant);

    // Simulate computational delay to observe thread interleaving 
    usleep(100000);

    // Store result in shared status array and update the global score
    data->row_status[i]=valid? STATUS_PASS:STATUS_FAIL;
    update_score(data,valid);

  } 
  printf("Thread ID-%d: Row checks completed.\n", t_arg->logical_id);
  return NULL; 
}

/*the below function is similar to the above one*/
void* check_columns(void* arg)
{
  ThreadArgs *t_arg = (ThreadArgs *)arg;
  MagicSquareData *data = t_arg->data;
  for(int j=0;j<data->n;j++)
  {
    int sum=0;
    for(int i=0;i<data->n;i++)
    {
        sum+=data->matrix[i][j];
    }
    bool valid=(sum== data->magic_constant);
    usleep(100000);
    data->col_status[j]=valid? STATUS_PASS:STATUS_FAIL;
    update_score(data,valid);

  } 
  printf("Thread ID-%d: Column checks completed.\n", t_arg->logical_id);
  return NULL; 
}

void* check_diagonals(void* arg)
{
  ThreadArgs *t_arg = (ThreadArgs *)arg;
  MagicSquareData *data = t_arg->data; 
  int m_sum=0,a_sum=0;

  //Single pass loop to calculate both diagonal sums concurrently
  for (int i=0;i<data->n;i++)
  {
    // Sum for Main Diagonal: indices (0,0), (1,1), (2,2)...
    m_sum+=data->matrix[i][i];
    // Sum for Anti-Diagonal: indices (0,n-1), (1,n-2), (2,n-3)...
    a_sum+=data->matrix[i][data->n-1-i];

  }
  //Artificial delay to simulate processing time and test thread synchronization
  usleep(100000);

  // Validate Main Diagonal
  bool mv =(m_sum==data->magic_constant);
  data->diag_status[0]=mv? STATUS_PASS:STATUS_FAIL;
  update_score(data,mv);

  // Validate Anti Diagonal
  bool av =(a_sum==data->magic_constant);
  data->diag_status[1]=av? STATUS_PASS:STATUS_FAIL;
  update_score(data,av);

  printf("Thread ID-%d: Diagonal checks completed.\n", t_arg->logical_id);
  return NULL;

}

void* check_uniqueness(void* arg)
{
  ThreadArgs *t_arg = (ThreadArgs *)arg;
  MagicSquareData *data = t_arg->data;
  //The set of numbers must be 1 to n^2
  int limit= data->n *data->n;

  //Allocation of a lookup table initialized to 0 to track seen numbers
  int *seen=(int *)calloc(limit+1, sizeof(int));
  bool unique=true;

  //Traverse the matrix to verify the range and presence of ecah number
  for(int i=0;i<data->n;i++)
  {
    for(int j=0;j<data->n;j++)
    {
        int val = data->matrix[i][j];
        //If value is out of range (e.g: 0 or > n^2) or already encountered, it's invalid
        if(val<1 || val>limit || seen[val]>0)
        {
            unique=false;
        }
        else
        { // Mark the number as seen in local lookup table
            seen[val]=1;

        }
    }
  }
  //Delay to allow other validation threads to interleave during the execution
  usleep(100000);

  // Final status update for the uniqueness requirment
  data->unique_status=unique?STATUS_PASS:STATUS_FAIL;
  update_score(data,unique);

  //Clean up thread local memory to prevent memory leaks
  free(seen);
  printf("Thread ID-%d: Uniqueness check completed.\n", t_arg->logical_id);
  return NULL;


}