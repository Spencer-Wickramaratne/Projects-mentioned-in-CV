/*Name:Nallaperuma Arachchilage Spencer Sterling Wickramaratne
 *Curtin ID:23120839
 *File Name:main.c
 *Purpose:This manages the program lifecycle, including command line argument parsing, file I/O (reading the matrix), dynamic memory allocation, 
          thread spawning/joining and final report generation.It acts as the manager thread. It sets up the environment for the worker threads to
          run and cleans up all resources (freeing memory and destroying the mutex) once the work is complete.
 *Date:27.04.2026*/

#include "magic_square.h"
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char*argv[])
{
    int exit_status=0;
    FILE *f=NULL;
    MagicSquareData data={0};
    
    // argc: Argument Count. Expects 2 (the program name and the input file path).
    // argv: Argument Vector. An array of strings containing the terminal inputs.
    if (argc!=2)
    {
        printf("Usage: %s <file>\n", argv[0]);
        exit_status=1;
    }
    else
    {
        // Attempt to open the file provided in argv[1] for reading ("r")
        f= fopen(argv[1],"r");
        if(!f)
        {
            perror
            ("File error");
            exit_status=1;
        }
    }
    if(exit_status==0)
    {   //Input Parsing: Check if file contains a valid integer for matrix size
        if (fscanf(f, "%d", &data.n) != 1) 
        {    
            // fscanf returns the number of successfully matched items and if not 1 the file is malformed
            fprintf(stderr, "Error: Invalid file format (Matrix size must be an integer).\n");
            fclose(f); //  close the file before exiting
            return 1;  // Stop execution immediately
        }

        // Logic to prevent n=0 or negative n from causing crashes
        if (data.n <= 0) 
        {
            fprintf(stderr, "Error: Matrix size must be greater than 0.\n");
            fclose(f);
            return 1;
        }
        data.magic_constant=(data.n*(data.n*data.n+1))/2;
        data.matrix=(int**)malloc(data.n* sizeof(int *));
        for(int i=0;i<data.n;i++)
        {
          data.matrix[i]=(int*)malloc(data.n* sizeof(int ));
          for(int j=0;j<data.n;j++)
          {
            fscanf(f,"%d",&data.matrix[i][j]);
          }
        }
        fclose(f);
        f=NULL;

        data.row_status=(int *)calloc(data.n,sizeof(int));
        data.col_status=(int *)calloc(data.n,sizeof(int));
        data.diag_status=(int *)calloc(2,sizeof(int));
        pthread_mutex_init(&data.mutex,NULL);

        
        // Initializing Thread Arguments
        pthread_t t[4];
        ThreadArgs args[4];

        // Array of function pointers to map threads to their specific validation tasks
        void* (*functions[4])(void*) = {check_rows, check_columns, check_diagonals, check_uniqueness};
        
        //Thread Creation: Spawning 4 worker threads to run concurrently
        for (int i = 0; i < 4; i++) {
            args[i].data = &data;
            args[i].logical_id = i + 1; // Assigns 1, 2, 3, 4
            pthread_create(&t[i], NULL, functions[i], &args[i]);
        }

        //Thread Joining: Block the main thread until all workers have finished their tasks 
        // This prevents the program from printing results before the score is fully updated.
        for(int i=0;i<4;i++)
        {
            pthread_join(t[i],NULL);

        }
        printf("\n--- Magic Square Report ---\nRows:  ");
        bool r_all=true;
        for(int i=0; i<data.n;i++)
        {
            if(data.row_status[i]==STATUS_FAIL)
            {
                printf("Row %d Invalid ", i+1);
                r_all=false;
            }
        }
        if(r_all)
        {
            printf("All Valid");

        }

        printf("\nCols:  ");
        bool c_all=true;
        for(int i=0; i<data.n;i++)
        {
            if(data.col_status[i]==STATUS_FAIL)
            {
                printf("Col %d Invalid ", i+1);
                c_all=false;
            }
        }
        if(c_all)
        {
            printf("All Valid");
        }

        printf("\nDiags: ");
        if(data.diag_status[0]== STATUS_PASS && data.diag_status[1] == STATUS_PASS)
        {
            printf("All Valid");
        }
        else
        {
            if(data.diag_status[0]== STATUS_FAIL)
            {
                printf("Main Diag Invalid ");

            }
             if(data.diag_status[1]== STATUS_FAIL)
            {
                printf("Anti-Diag Invalid");
                
            }
        }
        printf("\nUnique: %s", data.unique_status== STATUS_PASS? "Passed" : "Failed (Duplicates found)");
        int max_score= data.n+data.n+2+1;
        printf("\nFinal Score: %d / %d" , data.global_score, max_score);
        printf("\nRESULT: %s\n", (data.global_score ==max_score)? "VALID MAGIC SQUARE": "INVALID MAGIC SQUARE");


    }
    // Close the file stream if it was successfully opened
    if(f)
    {
        fclose(f);
    }
    // Free the 2D matrix: First free each individual row, then the array of pointers
    if(data.matrix)
    {
        for (int i=0;i<data.n; i++)
        {
           if(data.matrix[i])// Free individual row
           {
            free(data.matrix[i]);
           }  
        }
        free(data.matrix);// Free the main pointer array
    
    }
    // Free the shared status arrays used by the worker threads
    if(data.row_status)
    {
        free(data.row_status);
    
    }
     if(data.col_status)
    {
        free(data.col_status);
    
    }
     if(data.diag_status)
    {
        free(data.diag_status);
    
    }
    //Destroy the mutex to release system synchronization resources
    pthread_mutex_destroy(&data.mutex);

    // Return 0 for success or 1 for failure to the Operating System
    return exit_status;
}