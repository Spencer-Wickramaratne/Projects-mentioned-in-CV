/**
 * Provides facts and associations related to colors using parallel arrays.
 */
public class ColourFunFacts {

    // Using parallel arrays to store color names and their associated facts.
    private String[] colorNames = {"violet","blue","cyan","green","yellow","orange","red"};
    private String[] colourEmotions = { "Bravery","Calm","Calm","Peaceful","Happy","Happy","Confidence" };
    private String[] colourStones = {"Amethyst","Opal","Turquoise","Emerald","Topaz","Moonstone","Garnet" };
    private String[] colourMusicalNotes = {"B","A","G","F","E","D","C" };

    /**
     * Finds the index of a given color name in the colorNames array (case-insensitive search).
     * Demonstrates linear search using a for loop.

     */
    private int findColorIndex(String color) {
        // Check for null input immediately to prevent NullPointerException
        if (color == null) {
            return -1;
        }
        String lCaseColor = color.toLowerCase();

        for (int i = 0; i < colorNames.length; i++) {
            if (colorNames[i].equals(lCaseColor)) { // String comparison
                return i; // Return the index if a match is found
            }
        }
        return -1; // Return -1 if the color is not found in the array
    }


    /**
     * Returns emotion associated with a color using parallel arrays.
     * Retrieves the fact using the index found by findColorIndex.
    
     */
    public String getColourEmotion(String color) {
        int index = findColorIndex(color); // Find the corresponding index
        if (index != -1) {
            return colourEmotions[index];
        } else {
            return "Unknown emotion"; // Return default if color not found
        }
    }

    /**
     * Returns stones associated with a color using parallel arrays.
     * Retrieves the fact using the index found by findColorIndex.
     
     */
    public String getColourStone(String color) {
         int index = findColorIndex(color);
        if (index != -1) {
            return colourStones[index];
        } else {
            return "Unknown stone";
        }
    }

    /**
     * Returns a musical note associated with a color using parallel arrays.
     * Retrieves the fact using the index found by findColorIndex.

     */
    public String getColourMusicalNote(String color) {
         int index = findColorIndex(color);
        if (index != -1) {
            return colourMusicalNotes[index];
        } else {
            return "Unknown musical note";
        }
    }
}