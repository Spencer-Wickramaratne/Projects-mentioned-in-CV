import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.Objects;

public class MainTest {

    private static final InputStream originalSystemIn = System.in;
    private static final PrintStream originalSystemOut = System.out;
    private static ByteArrayOutputStream outputStreamCaptor;
    private static int testsRun = 0;
    private static int testsFailed = 0;

    // --- Helper methods for setting up and tearing down test environment ---

    private static void setUp() {
        outputStreamCaptor = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStreamCaptor));
    }

    private static void tearDown() {
        System.setIn(originalSystemIn);
        System.setOut(originalSystemOut);
        outputStreamCaptor = null;
    }

    private static void setInput(String data) {
        System.setIn(new ByteArrayInputStream(data.getBytes()));
    }

    // --- Simple Assertion Methods ---

    private static void assertEquals(Object expected, Object actual, String testName) {
        testsRun++;
        if (Objects.equals(expected, actual)) {
            System.out.println("PASS: " + testName);
        } else {
            testsFailed++;
            System.err.println("FAIL: " + testName + " - Expected: '" + expected + "', Actual: '" + actual + "'");
        }
    }

    private static void assertTrue(boolean condition, String testName, String failureMessage) {
        testsRun++;
        if (condition) {
            System.out.println("PASS: " + testName);
        } else {
            testsFailed++;
            System.err.println("FAIL: " + testName + " - " + failureMessage);
        }
    }

    // --- Test methods for Main class ---

    private static void testMain_ExitOption() {
        setUp();
        try {
            // Simulate input: 3 (Exit)
            setInput("3\n");
            Main.main(new String[]{});

            String actualOutput = outputStreamCaptor.toString();
            assertTrue(actualOutput.contains("Exiting program."), "testMain_ExitOption", "Expected exit message not found.");
            assertTrue(actualOutput.contains("Select an option:"), "testMain_ExitOption", "Expected menu prompt not found before exit.");
        } finally {
            tearDown();
        }
    }

    private static void testMain_InvalidChoiceThenExit() {
        setUp();
        try {
            // Simulate input: 99 (Invalid), then 3 (Exit)
            setInput("99\n3\n");
            Main.main(new String[]{});

            String actualOutput = outputStreamCaptor.toString();
            assertTrue(actualOutput.contains("Invalid choice. Please try again."), "testMain_InvalidChoiceThenExit", "Expected invalid choice message not found.");
            assertTrue(actualOutput.contains("Exiting program."), "testMain_InvalidChoiceThenExit", "Expected exit message not found.");
        } finally {
            tearDown();
        }
    }


    private static void testMain_ScenarioA_WavelengthToFrequency() {
        setUp();
        try {
            // Input: 1 (Scenario A), a (Wavelength to Freq), 500 (wavelength), 3 (Exit)
            setInput("1\na\n500\n3\n");
            Main.main(new String[]{});

            String actualOutput = outputStreamCaptor.toString();

            // Check for the initial menu
            assertTrue(actualOutput.contains("Software Engineering Assignment"), "testMain_ScenarioA_WavelengthToFrequency", "Expected program title not found.");
            assertTrue(actualOutput.contains("Select an option:"), "testMain_ScenarioA_WavelengthToFrequency", "Expected initial menu start not found.");
            assertTrue(actualOutput.contains("1. Analyze EM Spectrum (Scenario A)"), "testMain_ScenarioA_WavelengthToFrequency", "Expected initial menu option 1 not found.");
            assertTrue(actualOutput.contains("Enter your choice: "), "testMain_ScenarioA_WavelengthToFrequency", "Expected initial menu choice prompt not found.");

            // Check for the Scenario A menu after selecting option 1
            assertTrue(actualOutput.contains("Select analysis type:"), "testMain_ScenarioA_WavelengthToFrequency", "Expected Scenario A menu start not found.");
            assertTrue(actualOutput.contains("a. Convert Wavelength to Frequency"), "testMain_ScenarioA_WavelengthToFrequency", "Expected Scenario A option 'a' not found.");
            assertTrue(actualOutput.contains("Enter your choice (a-i): "), "testMain_ScenarioA_WavelengthToFrequency", "Expected Scenario A choice prompt not found."); // Updated prompt


            // Check for wavelength input prompt
            assertTrue(actualOutput.contains("Enter wavelength (in nm): "), "testMain_ScenarioA_WavelengthToFrequency", "Expected wavelength input prompt not found.");
            // Check the conversion output
            assertTrue(actualOutput.contains("Converted Frequency: 600.0 THz"), "testMain_ScenarioA_WavelengthToFrequency", "Expected wavelength to frequency conversion output not found.");

            // Check for exit message
            assertTrue(actualOutput.contains("Exiting program."), "testMain_ScenarioA_WavelengthToFrequency", "Expected exit message not found.");
        } finally {
            tearDown();
        }
    }

    private static void testMain_ScenarioA_FrequencyToWavelength() {
        setUp();
        try {
            // Input: 1 (Scenario A), b (Frequency to Wavelength), 600 (frequency), 3 (Exit)
            setInput("1\nb\n600\n3\n");
            Main.main(new String[]{});

            String actualOutput = outputStreamCaptor.toString();
            assertTrue(actualOutput.contains("Enter frequency (in THz): "), "testMain_ScenarioA_FrequencyToWavelength", "Expected frequency input prompt not found.");
            assertTrue(actualOutput.contains("Converted Wavelength: 500.0 nm"), "testMain_ScenarioA_FrequencyToWavelength", "Expected frequency to wavelength conversion output not found.");
            assertTrue(actualOutput.contains("Exiting program."), "testMain_ScenarioA_FrequencyToWavelength", "Expected exit message not found.");
        } finally {
            tearDown();
        }
    }


    private static void testMain_ScenarioA_GetEMSpectrumRange_Wavelength() {
        setUp();
        try {
            // Input: 1 (Scenario A), c (Get EM Spectrum Range), 550 (value), wavelength (type), 3 (Exit)
            setInput("1\nc\n550\nwavelength\n3\n");
            Main.main(new String[]{});

            String actualOutput = outputStreamCaptor.toString();

            // Check for initial menu
            assertTrue(actualOutput.contains("Select an option:"), "testMain_ScenarioA_GetEMSpectrumRange_Wavelength", "Expected initial menu start not found.");
            assertTrue(actualOutput.contains("1. Analyze EM Spectrum (Scenario A)"), "testMain_ScenarioA_GetEMSpectrumRange_Wavelength", "Expected initial menu option 1 not found.");
            assertTrue(actualOutput.contains("Enter your choice: "), "testMain_ScenarioA_GetEMSpectrumRange_Wavelength", "Expected initial menu choice prompt not found.");

            // Check for Scenario A menu
            assertTrue(actualOutput.contains("Select analysis type:"), "testMain_ScenarioA_GetEMSpectrumRange_Wavelength", "Expected Scenario A menu start not found.");
            assertTrue(actualOutput.contains("c. Get EM Spectrum Range"), "testMain_ScenarioA_GetEMSpectrumRange_Wavelength", "Expected Scenario A option 'c' not found.");
            assertTrue(actualOutput.contains("Enter your choice (a-i): "), "testMain_ScenarioA_GetEMSpectrumRange_Wavelength", "Expected Scenario A choice prompt not found."); // Updated prompt

            // Check for value/type prompts
            assertTrue(actualOutput.contains("Enter value (wavelength in nm, frequency in THz): "), "testMain_ScenarioA_GetEMSpectrumRange_Wavelength", "Expected value prompt not found.");
            assertTrue(actualOutput.contains("Enter type (wavelength/frequency): "), "testMain_ScenarioA_GetEMSpectrumRange_Wavelength", "Expected type prompt not found.");

            // Check the spectrum range output
            assertTrue(actualOutput.contains("EM Spectrum Range: Visible Light"), "testMain_ScenarioA_GetEMSpectrumRange_Wavelength", "Expected spectrum range output for wavelength not found.");

            // Check for exit message
            assertTrue(actualOutput.contains("Exiting program."), "testMain_ScenarioA_GetEMSpectrumRange_Wavelength", "Expected exit message not found.");
        } finally {
            tearDown();
        }
    }

    private static void testMain_ScenarioA_CompareFrequencies() {
        setUp();
        try {
            // Input: 1 (Scenario A), d (Compare Two Frequencies), 500 (freq1), 700 (freq2), 3 (Exit)
            setInput("1\nd\n500\n700\n3\n");
            Main.main(new String[]{});

            String actualOutput = outputStreamCaptor.toString();
            assertTrue(actualOutput.contains("Enter first frequency (in THz): "), "testMain_ScenarioA_CompareFrequencies", "Expected first frequency prompt not found.");
            assertTrue(actualOutput.contains("Enter second frequency (in THz): "), "testMain_ScenarioA_CompareFrequencies", "Expected second frequency prompt not found.");
            assertTrue(actualOutput.contains("Both frequencies are visible light. Frequency 1: Orange, Frequency 2: Violet."), "testMain_ScenarioA_CompareFrequencies", "Expected frequency comparison output not found.");
            assertTrue(actualOutput.contains("Exiting program."), "testMain_ScenarioA_CompareFrequencies", "Expected exit message not found.");
        } finally {
            tearDown();
        }
    }

    private static void testMain_ScenarioA_IsWavelengthVisible() {
        setUp();
        try {
            // Input: 1 (Scenario A), e (Is Wavelength Visible), 450 (wavelength), 3 (Exit)
            setInput("1\ne\n450\n3\n");
            Main.main(new String[]{});

            String actualOutput = outputStreamCaptor.toString();
            assertTrue(actualOutput.contains("Enter wavelength to check visibility (in nm): "), "testMain_ScenarioA_IsWavelengthVisible", "Expected wavelength visibility prompt not found.");
            assertTrue(actualOutput.contains("Is wavelength visible? Yes"), "testMain_ScenarioA_IsWavelengthVisible", "Expected wavelength visibility output not found.");
            assertTrue(actualOutput.contains("Exiting program."), "testMain_ScenarioA_IsWavelengthVisible", "Expected exit message not found.");
        } finally {
            tearDown();
        }
    }

    private static void testMain_ScenarioA_GetVisibleColorFromWavelength() {
        setUp();
        try {
            // Input: 1 (Scenario A), f (Get Visible Color from Wavelength), 550 (wavelength), 3 (Exit)
            setInput("1\nf\n550\n3\n");
            Main.main(new String[]{});

            String actualOutput = outputStreamCaptor.toString();
            assertTrue(actualOutput.contains("Enter wavelength to get color (in nm): "), "testMain_ScenarioA_GetVisibleColorFromWavelength", "Expected wavelength for color prompt not found.");
            assertTrue(actualOutput.contains("Color for 550.0 nm: Green"), "testMain_ScenarioA_GetVisibleColorFromWavelength", "Expected color from wavelength output not found.");
            assertTrue(actualOutput.contains("Exiting program."), "testMain_ScenarioA_GetVisibleColorFromWavelength", "Expected exit message not found.");
        } finally {
            tearDown();
        }
    }

    private static void testMain_ScenarioA_IsFrequencyVisible() {
        setUp();
        try {
            // Input: 1 (Scenario A), g (Is Frequency Visible), 500 (frequency), 3 (Exit)
            setInput("1\ng\n500\n3\n");
            Main.main(new String[]{});

            String actualOutput = outputStreamCaptor.toString();
            assertTrue(actualOutput.contains("Enter frequency to check visibility (in THz): "), "testMain_ScenarioA_IsFrequencyVisible", "Expected frequency visibility prompt not found.");
            assertTrue(actualOutput.contains("Is frequency visible? Yes"), "testMain_ScenarioA_IsFrequencyVisible", "Expected frequency visibility output not found.");
            assertTrue(actualOutput.contains("Exiting program."), "testMain_ScenarioA_IsFrequencyVisible", "Expected exit message not found.");
        } finally {
            tearDown();
        }
    }

    private static void testMain_ScenarioA_GetColorFromFrequency() {
        setUp();
        try {
            // Input: 1 (Scenario A), h (Get Color from Frequency), 700 (frequency), 3 (Exit)
            setInput("1\nh\n700\n3\n");
            Main.main(new String[]{});

            String actualOutput = outputStreamCaptor.toString();
            assertTrue(actualOutput.contains("Enter frequency to get color (in THz): "), "testMain_ScenarioA_GetColorFromFrequency", "Expected frequency for color prompt not found.");
            assertTrue(actualOutput.contains("Color for 700.0 THz: Violet"), "testMain_ScenarioA_GetColorFromFrequency", "Expected color from frequency output not found.");
            assertTrue(actualOutput.contains("Exiting program."), "testMain_ScenarioA_GetColorFromFrequency", "Expected exit message not found.");
        } finally {
            tearDown();
        }
    }

    private static void testMain_ScenarioA_GetFrequencyRangeForColor() {
        setUp();
        try {
            // Input: 1 (Scenario A), i (Get Frequency Range for Color), Red (color), 3 (Exit)
            setInput("1\ni\nRed\n3\n");
            Main.main(new String[]{});

            String actualOutput = outputStreamCaptor.toString();
            assertTrue(actualOutput.contains("Enter color name to get frequency range: "), "testMain_ScenarioA_GetFrequencyRangeForColor", "Expected color name prompt not found.");
            assertTrue(actualOutput.contains("Frequency range for Red: 400.0 THz - 480.0 THz"), "testMain_ScenarioA_GetFrequencyRangeForColor", "Expected frequency range for color output not found.");
            assertTrue(actualOutput.contains("Exiting program."), "testMain_ScenarioA_GetFrequencyRangeForColor", "Expected exit message not found.");
        } finally {
            tearDown();
        }
    }


    private static void testMain_ScenarioB_GetColourFacts() {
        setUp();
        try {
            // Input: 2 (Scenario B), Red (color name), 3 (Exit)
            setInput("2\nRed\n3\n");
            Main.main(new String[]{});

            String actualOutput = outputStreamCaptor.toString();
            assertTrue(actualOutput.contains("Facts for Red:"), "testMain_ScenarioB_GetColourFacts", "Expected facts header not found.");
            assertTrue(actualOutput.contains("Emotion: Confidence"), "testMain_ScenarioB_GetColourFacts", "Expected emotion fact not found.");
            assertTrue(actualOutput.contains("Associated Stone: Garnet"), "testMain_ScenarioB_GetColourFacts", "Expected stone fact not found.");
            assertTrue(actualOutput.contains("Associated Musical Note: C"), "testMain_ScenarioB_GetColourFacts", "Expected musical note fact not found.");
        } finally {
            tearDown();
        }
    }

    // --- Main method to run all tests ---

    public static void main(String[] args) {
        System.out.println("--- Running Main Class Tests ---");

        testMain_ExitOption();
        testMain_InvalidChoiceThenExit();
        testMain_ScenarioA_WavelengthToFrequency();
        testMain_ScenarioA_FrequencyToWavelength(); // New Test
        testMain_ScenarioA_GetEMSpectrumRange_Wavelength();
        testMain_ScenarioA_CompareFrequencies(); // New Test
        testMain_ScenarioA_IsWavelengthVisible(); // New Test
        testMain_ScenarioA_GetVisibleColorFromWavelength(); // New Test
        testMain_ScenarioA_IsFrequencyVisible(); // New Test
        testMain_ScenarioA_GetColorFromFrequency(); // New Test
        testMain_ScenarioA_GetFrequencyRangeForColor(); // New Test
        testMain_ScenarioB_GetColourFacts();

        System.out.println("\n--- Test Summary ---");
        System.out.println("Tests Run: " + testsRun);
        System.out.println("Tests Failed: " + testsFailed);

        if (testsFailed == 0) {
            System.out.println("All Main class tests passed!");
        } else {
            System.out.println("Some Main class tests failed. Please review the output above.");
        }
    }
}