
Production code files:
EMSpectrumAnalyzer.java
ColourFunfacts.java
InputHandler.java
OutputHandler.java
Main.java

Test code files:
EMSpectrumAnalyzerTest.java
ColourFunfactsTest.java
InputHandlerTest.java
OutputHandlerTest.java
MainTest.java

Markdown file : Documentation.md
PDF file : SpencerWickramaratne_23120839_ISEReport.pdf

Declaration of originality: DeclarationOfOriginality_v1.2.pdf

Version Controlling: .git

