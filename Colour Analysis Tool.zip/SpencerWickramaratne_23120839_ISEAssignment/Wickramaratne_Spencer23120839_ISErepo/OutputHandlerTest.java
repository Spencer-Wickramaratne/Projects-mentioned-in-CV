
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.Objects;

public class OutputHandlerTest {

    private static final InputStream originalSystemIn = System.in; // Not strictly needed for OutputHandler, but good practice for consistency
    private static final PrintStream originalSystemOut = System.out;
    private static ByteArrayOutputStream outputStreamCaptor;
    private static int testsRun = 0;
    private static int testsFailed = 0;

    // --- Helper methods for setting up and tearing down test environment ---

    private static void setUp() {
        outputStreamCaptor = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStreamCaptor));
    }

    private static void tearDown() {
        System.setIn(originalSystemIn); // Restore original System.in
        System.setOut(originalSystemOut); // Restore original System.out
        outputStreamCaptor = null; // Clear the captor
    }

    private static String getCapturedOutput() {
        return outputStreamCaptor.toString();
    }

    // --- Simple Assertion Methods ---

    private static void assertEquals(Object expected, Object actual, String testName) {
        testsRun++;
        if (Objects.equals(expected, actual)) {
            System.out.println("PASS: " + testName);
        } else {
            testsFailed++;
            System.err.println("FAIL: " + testName + " - Expected: '" + expected + "', Actual: '" + actual + "'");
        }
    }

   

    // --- Test Methods for OutputHandler ---

    public static void testPrintMessage() {
        setUp();
        try {
            OutputHandler outputHandler = new OutputHandler();
            String message = "Hello, World!";
            outputHandler.printMessage(message);
            assertEquals(message + System.lineSeparator(), getCapturedOutput(), "testPrintMessage Output");
        } finally {
            tearDown();
        }
    }

    public static void testPrintFormattedMessage() {
        setUp();
        try {
            OutputHandler outputHandler = new OutputHandler();
            String format = "Name: %s, Age: %d\n";
            String name = "Alice";
            int age = 30;
            outputHandler.printFormattedMessage(format, name, age);
            assertEquals(String.format(format, name, age), getCapturedOutput(), "testPrintFormattedMessage Output");
        } finally {
            tearDown();
        }
    }

    public static void testPrintNewLine() {
        setUp();
        try {
            OutputHandler outputHandler = new OutputHandler();
            outputHandler.printNewLine();
            assertEquals(System.lineSeparator(), getCapturedOutput(), "testPrintNewLine Output");
        } finally {
            tearDown();
        }
    }

    public static void testPrintMessageMultipleCalls() {
        setUp();
        try {
            OutputHandler outputHandler = new OutputHandler();
            outputHandler.printMessage("Line 1");
            outputHandler.printMessage("Line 2");
            String expected = "Line 1" + System.lineSeparator() + "Line 2" + System.lineSeparator();
            assertEquals(expected, getCapturedOutput(), "testPrintMessageMultipleCalls Output");
        } finally {
            tearDown();
        }
    }

    // --- Main method to run all tests ---

    public static void main(String[] args) {
        System.out.println("--- Running OutputHandler Simple Tests ---");

        testPrintMessage();
        testPrintFormattedMessage();
        testPrintNewLine();
        testPrintMessageMultipleCalls();

        System.out.println("\n--- Test Summary ---");
        System.out.println("Tests Run: " + testsRun);
        System.out.println("Tests Failed: " + testsFailed);

        if (testsFailed == 0) {
            System.out.println("All tests passed!");
        } else {
            System.out.println("Some tests failed. Please review the output above.");
        }
    }
}