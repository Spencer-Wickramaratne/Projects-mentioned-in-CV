
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.Objects;

public class ColourFunFactsTest {

    private static final InputStream originalSystemIn = System.in;
    private static final PrintStream originalSystemOut = System.out;
    private static ByteArrayOutputStream outputStreamCaptor; // Not strictly needed for ColourFunFacts, but for consistency
    private static int testsRun = 0;
    private static int testsFailed = 0;

    // --- Helper methods for setting up and tearing down test environment ---

    private static void setUp() {
        outputStreamCaptor = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStreamCaptor));
    }

    private static void tearDown() {
        System.setIn(originalSystemIn);
        System.setOut(originalSystemOut);
        outputStreamCaptor = null;
    }

    // --- Simple Assertion Methods ---

    private static void assertEquals(Object expected, Object actual, String testName) {
        testsRun++;
        if (Objects.equals(expected, actual)) {
            System.out.println("PASS: " + testName);
        } else {
            testsFailed++;
            System.err.println("FAIL: " + testName + " - Expected: '" + expected + "', Actual: '" + actual + "'");
        }
    }

    private static void assertTrue(boolean condition, String testName, String failureMessage) {
        testsRun++;
        if (condition) {
            System.out.println("PASS: " + testName);
        } else {
            testsFailed++;
            System.err.println("FAIL: " + testName + " - " + failureMessage);
        }
    }

    // --- Test Methods for ColourFunFacts ---

    public static void testGetColourEmotion_ValidColors() {
        setUp();
        try {
            ColourFunFacts facts = new ColourFunFacts();
            assertEquals("Bravery", facts.getColourEmotion("Violet"), "testGetColourEmotion_Violet");
            assertEquals("Calm", facts.getColourEmotion("blue"), "testGetColourEmotion_Blue"); // Case-insensitive
            assertEquals("Happy", facts.getColourEmotion("YELLOW"), "testGetColourEmotion_Yellow"); // Case-insensitive
        } finally {
            tearDown();
        }
    }

    public static void testGetColourEmotion_UnknownColor() {
        setUp();
        try {
            ColourFunFacts facts = new ColourFunFacts();
            assertEquals("Unknown emotion", facts.getColourEmotion("Black"), "testGetColourEmotion_Unknown");
            assertEquals("Unknown emotion", facts.getColourEmotion(""), "testGetColourEmotion_EmptyString");
            assertEquals("Unknown emotion", facts.getColourEmotion(null), "testGetColourEmotion_Null");
        } finally {
            tearDown();
        }
    }

    public static void testGetColourStone_ValidColors() {
        setUp();
        try {
            ColourFunFacts facts = new ColourFunFacts();
            assertEquals("Amethyst", facts.getColourStone("Violet"), "testGetColourStone_Violet");
            assertEquals("Turquoise", facts.getColourStone("Cyan"), "testGetColourStone_Cyan");
            assertEquals("Garnet", facts.getColourStone("red"), "testGetColourStone_Red");
        } finally {
            tearDown();
        }
    }

    public static void testGetColourStone_UnknownColor() {
        setUp();
        try {
            ColourFunFacts facts = new ColourFunFacts();
            assertEquals("Unknown stone", facts.getColourStone("White"), "testGetColourStone_Unknown");
        } finally {
            tearDown();
        }
    }

    public static void testGetColourMusicalNote_ValidColors() {
        setUp();
        try {
            ColourFunFacts facts = new ColourFunFacts();
            assertEquals("B", facts.getColourMusicalNote("Violet"), "testGetColourMusicalNote_Violet");
            assertEquals("G", facts.getColourMusicalNote("Cyan"), "testGetColourMusicalNote_Cyan");
            assertEquals("C", facts.getColourMusicalNote("Red"), "testGetColourMusicalNote_Red");
        } finally {
            tearDown();
        }
    }

    public static void testGetColourMusicalNote_UnknownColor() {
        setUp();
        try {
            ColourFunFacts facts = new ColourFunFacts();
            assertEquals("Unknown musical note", facts.getColourMusicalNote("Brown"), "testGetColourMusicalNote_Unknown");
        } finally {
            tearDown();
        }
    }

    // --- Main method to run all tests ---

    public static void main(String[] args) {
        System.out.println("--- Running ColourFunFacts Simple Tests ---");

        testGetColourEmotion_ValidColors();
        testGetColourEmotion_UnknownColor();
        testGetColourStone_ValidColors();
        testGetColourStone_UnknownColor();
        testGetColourMusicalNote_ValidColors();
        testGetColourMusicalNote_UnknownColor();

        System.out.println("\n--- Test Summary ---");
        System.out.println("Tests Run: " + testsRun);
        System.out.println("Tests Failed: " + testsFailed);

        if (testsFailed == 0) {
            System.out.println("All tests passed!");
        } else {
            System.out.println("Some tests failed. Please review the output above.");
        }
    }
}