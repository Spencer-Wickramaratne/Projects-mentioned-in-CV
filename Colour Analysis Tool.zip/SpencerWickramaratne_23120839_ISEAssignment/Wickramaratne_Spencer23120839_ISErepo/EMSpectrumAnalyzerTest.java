// EMSpectrumAnalyzerTest.java
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.Objects;
import java.util.Arrays; // Import for comparing double arrays

public class EMSpectrumAnalyzerTest {

    private static final InputStream originalSystemIn = System.in;
    private static final PrintStream originalSystemOut = System.out;
    private static ByteArrayOutputStream outputStreamCaptor;
    private static int testsRun = 0;
    private static int testsFailed = 0;

    // --- Helper methods for setting up and tearing down test environment ---

    private static void setUp() {
        outputStreamCaptor = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStreamCaptor));
    }

    private static void tearDown() {
        System.setIn(originalSystemIn);
        System.setOut(originalSystemOut);
        outputStreamCaptor = null;
    }

    // --- Simple Assertion Methods ---

    private static void assertEquals(Object expected, Object actual, String testName) {
        testsRun++;
        if (Objects.equals(expected, actual)) {
            System.out.println("PASS: " + testName);
        } else {
            testsFailed++;
            System.err.println("FAIL: " + testName + " - Expected: '" + expected + "', Actual: '" + actual + "'");
        }
    }

    private static void assertEquals(double expected, double actual, double delta, String testName) {
        testsRun++;
        if (Math.abs(expected - actual) < delta) {
            System.out.println("PASS: " + testName);
        } else {
            testsFailed++;
            System.err.println("FAIL: " + testName + " - Expected: '" + expected + "', Actual: '" + actual + "', Delta: " + delta);
        }
    }

    private static void assertArrayEquals(double[] expected, double[] actual, double delta, String testName) {
        testsRun++;
        boolean arraysEqual = true;
        if (expected == null && actual == null) {
            arraysEqual = true;
        } else if (expected == null || actual == null || expected.length != actual.length) {
            arraysEqual = false;
        } else {
            for (int i = 0; i < expected.length; i++) {
                if (Math.abs(expected[i] - actual[i]) >= delta) {
                    arraysEqual = false;
                    break;
                }
            }
        }

        if (arraysEqual) {
            System.out.println("PASS: " + testName);
        } else {
            testsFailed++;
            System.err.println("FAIL: " + testName + " - Expected: " + Arrays.toString(expected) + ", Actual: " + Arrays.toString(actual) + ", Delta: " + delta);
        }
    }

    // --- Test methods for EMSpectrumAnalyzer ---

    private static void testGetVisibleColor_Violet() {
        setUp();
        try {
            EMSpectrumAnalyzer analyzer = new EMSpectrumAnalyzer();
            assertEquals("Violet", analyzer.getVisibleColor(380.0), "getVisibleColor_Violet_Min");
            assertEquals("Violet", analyzer.getVisibleColor(400.0), "getVisibleColor_Violet_Mid");
            assertEquals("Violet", analyzer.getVisibleColor(429.9), "getVisibleColor_Violet_JustBelowMax");
        } finally {
            tearDown();
        }
    }

    private static void testGetVisibleColor_Blue() {
        setUp();
        try {
            EMSpectrumAnalyzer analyzer = new EMSpectrumAnalyzer();
            assertEquals("Blue", analyzer.getVisibleColor(430.0), "getVisibleColor_Blue_Min");
            assertEquals("Blue", analyzer.getVisibleColor(440.0), "getVisibleColor_Blue_Mid");
            assertEquals("Blue", analyzer.getVisibleColor(449.9), "getVisibleColor_Blue_JustBelowMax");
        } finally {
            tearDown();
        }
    }

    private static void testGetVisibleColor_Cyan() {
        setUp();
        try {
            EMSpectrumAnalyzer analyzer = new EMSpectrumAnalyzer();
            assertEquals("Cyan", analyzer.getVisibleColor(450.0), "getVisibleColor_Cyan_Min");
            assertEquals("Cyan", analyzer.getVisibleColor(475.0), "getVisibleColor_Cyan_Mid");
            assertEquals("Cyan", analyzer.getVisibleColor(499.9), "getVisibleColor_Cyan_JustBelowMax");
        } finally {
            tearDown();
        }
    }

    private static void testGetVisibleColor_Green() {
        setUp();
        try {
            EMSpectrumAnalyzer analyzer = new EMSpectrumAnalyzer();
            assertEquals("Green", analyzer.getVisibleColor(500.0), "getVisibleColor_Green_Min");
            assertEquals("Green", analyzer.getVisibleColor(530.0), "getVisibleColor_Green_Mid");
            assertEquals("Green", analyzer.getVisibleColor(569.9), "getVisibleColor_Green_JustBelowMax");
        } finally {
            tearDown();
        }
    }

    private static void testGetVisibleColor_Yellow() {
        setUp();
        try {
            EMSpectrumAnalyzer analyzer = new EMSpectrumAnalyzer();
            assertEquals("Yellow", analyzer.getVisibleColor(570.0), "getVisibleColor_Yellow_Min");
            assertEquals("Yellow", analyzer.getVisibleColor(580.0), "getVisibleColor_Yellow_Mid");
            assertEquals("Yellow", analyzer.getVisibleColor(589.9), "getVisibleColor_Yellow_JustBelowMax");
        } finally {
            tearDown();
        }
    }

    private static void testGetVisibleColor_Orange() {
        setUp();
        try {
            EMSpectrumAnalyzer analyzer = new EMSpectrumAnalyzer();
            assertEquals("Orange", analyzer.getVisibleColor(590.0), "getVisibleColor_Orange_Min");
            assertEquals("Orange", analyzer.getVisibleColor(600.0), "getVisibleColor_Orange_Mid");
            assertEquals("Orange", analyzer.getVisibleColor(624.9), "getVisibleColor_Orange_JustBelowMax");
        } finally {
            tearDown();
        }
    }

    private static void testGetVisibleColor_Red() {
        setUp();
        try {
            EMSpectrumAnalyzer analyzer = new EMSpectrumAnalyzer();
            assertEquals("Red", analyzer.getVisibleColor(625.0), "getVisibleColor_Red_Min");
            assertEquals("Red", analyzer.getVisibleColor(700.0), "getVisibleColor_Red_Mid");
            assertEquals("Red", analyzer.getVisibleColor(750.0), "getVisibleColor_Red_Max");
        } finally {
            tearDown();
        }
    }

    private static void testGetVisibleColor_BelowRange() {
        setUp();
        try {
            EMSpectrumAnalyzer analyzer = new EMSpectrumAnalyzer();
            assertEquals("not visible light", analyzer.getVisibleColor(379.9), "getVisibleColor_BelowRange");
        } finally {
            tearDown();
        }
    }

    private static void testGetVisibleColor_AboveRange() {
        setUp();
        try {
            EMSpectrumAnalyzer analyzer = new EMSpectrumAnalyzer();
            assertEquals("not visible light", analyzer.getVisibleColor(750.1), "getVisibleColor_AboveRange");
        } finally {
            tearDown();
        }
    }

    private static void testConvertWavelengthToFrequency() {
        setUp();
        try {
            EMSpectrumAnalyzer analyzer = new EMSpectrumAnalyzer();
            double wavelength = 500.0; // nm
            double expectedFrequency = 300000.0 / 500.0; // THz
            assertEquals(expectedFrequency, analyzer.convertWavelengthToFrequency(wavelength), 0.01, "convertWavelengthToFrequency_500nm");

            wavelength = 750.0; // nm
            expectedFrequency = 300000.0 / 750.0; // THz (400 THz)
            assertEquals(expectedFrequency, analyzer.convertWavelengthToFrequency(wavelength), 0.01, "convertWavelengthToFrequency_750nm");
        } finally {
            tearDown();
        }
    }

    private static void testConvertFrequencyToWavelength() {
        setUp();
        try {
            EMSpectrumAnalyzer analyzer = new EMSpectrumAnalyzer();
            double frequency = 600.0; // THz
            double expectedWavelength = 300000.0 / 600.0; // nm
            assertEquals(expectedWavelength, analyzer.convertFrequencyToWavelength(frequency), 0.01, "convertFrequencyToWavelength_600THz");

            frequency = 400.0; // THz
            expectedWavelength = 300000.0 / 400.0; // nm (750 nm)
            assertEquals(expectedWavelength, analyzer.convertFrequencyToWavelength(frequency), 0.01, "convertFrequencyToWavelength_400THz");
        } finally {
            tearDown();
        }
    }

    private static void testGetColourFromFrequency() {
        setUp();
        try {
            EMSpectrumAnalyzer analyzer = new EMSpectrumAnalyzer();
            // Test visible colors
            assertEquals("Red", analyzer.getColourFromFrequency(400.0), "getColourFromFrequency_Red_Min");
            assertEquals("Red", analyzer.getColourFromFrequency(450.0), "getColourFromFrequency_Red_Mid");
            assertEquals("Red", analyzer.getColourFromFrequency(480.0), "getColourFromFrequency_Red_Max");

            assertEquals("Orange", analyzer.getColourFromFrequency(480.1), "getColourFromFrequency_Orange_Min");
            assertEquals("Orange", analyzer.getColourFromFrequency(500.0), "getColourFromFrequency_Orange_Mid");
            assertEquals("Orange", analyzer.getColourFromFrequency(510.0), "getColourFromFrequency_Orange_Max");

            assertEquals("Yellow", analyzer.getColourFromFrequency(510.1), "getColourFromFrequency_Yellow_Min");
            assertEquals("Yellow", analyzer.getColourFromFrequency(525.0), "getColourFromFrequency_Yellow_Mid");
            assertEquals("Yellow", analyzer.getColourFromFrequency(540.0), "getColourFromFrequency_Yellow_Max");

            assertEquals("Green", analyzer.getColourFromFrequency(540.1), "getColourFromFrequency_Green_Min");
            assertEquals("Green", analyzer.getColourFromFrequency(570.0), "getColourFromFrequency_Green_Mid");
            assertEquals("Green", analyzer.getColourFromFrequency(600.0), "getColourFromFrequency_Green_Max");

            assertEquals("Cyan", analyzer.getColourFromFrequency(600.1), "getColourFromFrequency_Cyan_Min");
            assertEquals("Cyan", analyzer.getColourFromFrequency(625.0), "getColourFromFrequency_Cyan_Mid");
            assertEquals("Cyan", analyzer.getColourFromFrequency(650.0), "getColourFromFrequency_Cyan_Max");

            assertEquals("Blue", analyzer.getColourFromFrequency(650.1), "getColourFromFrequency_Blue_Min");
            assertEquals("Blue", analyzer.getColourFromFrequency(670.0), "getColourFromFrequency_Blue_Mid");
            assertEquals("Blue", analyzer.getColourFromFrequency(690.0), "getColourFromFrequency_Blue_Max");

            assertEquals("Violet", analyzer.getColourFromFrequency(690.1), "getColourFromFrequency_Violet_Min");
            assertEquals("Violet", analyzer.getColourFromFrequency(750.0), "getColourFromFrequency_Violet_Mid");
            assertEquals("Violet", analyzer.getColourFromFrequency(789.5), "getColourFromFrequency_Violet_Max"); // Upper boundary

            // Test non-visible frequencies
            assertEquals("not visible light", analyzer.getColourFromFrequency(399.9), "getColourFromFrequency_BelowVisible");
            assertEquals("not visible light", analyzer.getColourFromFrequency(789.6), "getColourFromFrequency_AboveVisible");
            assertEquals("not visible light", analyzer.getColourFromFrequency(0.0), "getColourFromFrequency_Zero"); // Invalid frequency handled by isFrequencyVisible
            assertEquals("not visible light", analyzer.getColourFromFrequency(-10.0), "getColourFromFrequency_Negative"); // Invalid frequency handled by isFrequencyVisible
        } finally {
            tearDown();
        }
    }

    private static void testGetFrequencyRangeForColor() {
        setUp();
        try {
            EMSpectrumAnalyzer analyzer = new EMSpectrumAnalyzer();

            // Test valid colors
            assertArrayEquals(new double[]{400.0, 480.0}, analyzer.getFrequencyRangeForColor("Red"), 0.01, "getFrequencyRangeForColor_Red");
            assertArrayEquals(new double[]{480.1, 510.0}, analyzer.getFrequencyRangeForColor("Orange"), 0.01, "getFrequencyRangeForColor_Orange");
            assertArrayEquals(new double[]{510.1, 540.0}, analyzer.getFrequencyRangeForColor("Yellow"), 0.01, "getFrequencyRangeForColor_Yellow");
            assertArrayEquals(new double[]{540.1, 600.0}, analyzer.getFrequencyRangeForColor("Green"), 0.01, "getFrequencyRangeForColor_Green");
            assertArrayEquals(new double[]{600.1, 650.0}, analyzer.getFrequencyRangeForColor("Cyan"), 0.01, "getFrequencyRangeForColor_Cyan");
            assertArrayEquals(new double[]{650.1, 690.0}, analyzer.getFrequencyRangeForColor("Blue"), 0.01, "getFrequencyRangeForColor_Blue");
            assertArrayEquals(new double[]{690.1, 789.5}, analyzer.getFrequencyRangeForColor("Violet"), 0.01, "getFrequencyRangeForColor_Violet");

            // Test case-insensitivity
            assertArrayEquals(new double[]{400.0, 480.0}, analyzer.getFrequencyRangeForColor("red"), 0.01, "getFrequencyRangeForColor_red_lowercase");
            assertArrayEquals(new double[]{690.1, 789.5}, analyzer.getFrequencyRangeForColor("VIOLET"), 0.01, "getFrequencyRangeForColor_VIOLET_uppercase");

            // Test invalid color
            assertArrayEquals(null, analyzer.getFrequencyRangeForColor("Black"), 0.01, "getFrequencyRangeForColor_InvalidColor");
            assertArrayEquals(null, analyzer.getFrequencyRangeForColor("Infrared"), 0.01, "getFrequencyRangeForColor_NonVisibleColor");
            assertArrayEquals(null, analyzer.getFrequencyRangeForColor(null), 0.01, "getFrequencyRangeForColor_NullInput");

        } finally {
            tearDown();
        }
    }


    private static void testGetEMSpectrumRange_Wavelength() {
        setUp();
        try {
            EMSpectrumAnalyzer analyzer = new EMSpectrumAnalyzer();
            assertEquals("Radio Wave", analyzer.getEMSpectrumRange(2.0E9, "wavelength"), "getEMSpectrumRange_Radio_Wavelength"); // > 1m
            assertEquals("Microwave", analyzer.getEMSpectrumRange(5.0E7, "wavelength"), "getEMSpectrumRange_Microwave_Wavelength"); // 1mm to 1m
            assertEquals("Infrared", analyzer.getEMSpectrumRange(1000.0, "wavelength"), "getEMSpectrumRange_Infrared_Wavelength"); // 750nm to 1mm
            assertEquals("Visible Light", analyzer.getEMSpectrumRange(550.0, "wavelength"), "getEMSpectrumRange_Visible_Wavelength"); // 380nm to 750nm
            assertEquals("Ultraviolet", analyzer.getEMSpectrumRange(200.0, "wavelength"), "getEMSpectrumRange_UV_Wavelength"); // 10nm to 380nm
            assertEquals("X-ray", analyzer.getEMSpectrumRange(5.0, "wavelength"), "getEMSpectrumRange_Xray_Wavelength"); // 0.01nm to 10nm
            assertEquals("Gamma Ray", analyzer.getEMSpectrumRange(0.005, "wavelength"), "getEMSpectrumRange_Gamma_Wavelength"); // < 0.01nm
            assertEquals("Unknown", analyzer.getEMSpectrumRange(0.0, "wavelength"), "getEMSpectrumRange_Zero_Wavelength");
            assertEquals("Unknown", analyzer.getEMSpectrumRange(-100.0, "wavelength"), "getEMSpectrumRange_Negative_Wavelength");
        } finally {
            tearDown();
        }
    }

    private static void testGetEMSpectrumRange_Frequency() {
        setUp();
        try {
            EMSpectrumAnalyzer analyzer = new EMSpectrumAnalyzer();
            assertEquals("Radio Wave", analyzer.getEMSpectrumRange(1.0E-4, "frequency"), "getEMSpectrumRange_Radio_Frequency"); // < 0.3 GHz
            assertEquals("Microwave", analyzer.getEMSpectrumRange(0.1, "frequency"), "getEMSpectrumRange_Microwave_Frequency"); // 0.3 GHz to 300 GHz
            assertEquals("Infrared", analyzer.getEMSpectrumRange(100.0, "frequency"), "getEMSpectrumRange_Infrared_Frequency"); // 0.3 THz to 400 THz
            assertEquals("Visible Light", analyzer.getEMSpectrumRange(600.0, "frequency"), "getEMSpectrumRange_Visible_Frequency"); // 400 THz to 789.5 THz
            assertEquals("Ultraviolet", analyzer.getEMSpectrumRange(1.0E5, "frequency"), "getEMSpectrumRange_UV_Frequency"); // 789.5 THz to 3 PHz (3x10^6 THz)
            assertEquals("X-ray", analyzer.getEMSpectrumRange(1.0E7, "frequency"), "getEMSpectrumRange_Xray_Frequency"); // 3 PHz to 300 PHz
            assertEquals("Gamma Ray", analyzer.getEMSpectrumRange(5.0E8, "frequency"), "getEMSpectrumRange_Gamma_Frequency"); // > 300 PHz
            assertEquals("Unknown", analyzer.getEMSpectrumRange(0.0, "frequency"), "getEMSpectrumRange_Zero_Frequency");
            assertEquals("Unknown", analyzer.getEMSpectrumRange(-10.0, "frequency"), "getEMSpectrumRange_Negative_Frequency");
        } finally {
            tearDown();
        }
    }

    private static void testGetEMSpectrumRange_InvalidType() {
        setUp();
        try {
            EMSpectrumAnalyzer analyzer = new EMSpectrumAnalyzer();
            assertEquals("Unknown", analyzer.getEMSpectrumRange(500.0, "invalid"), "getEMSpectrumRange_InvalidType");
            assertEquals("Unknown", analyzer.getEMSpectrumRange(500.0, null), "getEMSpectrumRange_NullType");
        } finally {
            tearDown();
        }
    }

    private static void testCompareFrequencies_BothVisible() {
        setUp();
        try {
            EMSpectrumAnalyzer analyzer = new EMSpectrumAnalyzer();
            String result = analyzer.compareFrequencies(550.0, 700.0); // Green and Violet
            assertEquals("Both frequencies are visible light. Frequency 1: Green, Frequency 2: Violet.", result, "compareFrequencies_BothVisible");
        } finally {
            tearDown();
        }
    }

    private static void testCompareFrequencies_OneVisibleOneNot() {
        setUp();
        try {
            EMSpectrumAnalyzer analyzer = new EMSpectrumAnalyzer();
            String result1 = analyzer.compareFrequencies(550.0, 300.0); // Green, then Infrared
            assertEquals("Frequency 1 represents the color: Green. Frequency 2 is lower than that of red (not visible light).", result1, "compareFrequencies_OneVisibleOneNot_Low");

            String result2 = analyzer.compareFrequencies(700.0, 800.0); // Violet, then UV
            assertEquals("Frequency 1 represents the color: Violet. Frequency 2 is higher than that of violet (not visible light).", result2, "compareFrequencies_OneVisibleOneNot_High");

            String result3 = analyzer.compareFrequencies(300.0, 550.0); // Infrared, then Green
            assertEquals("Frequency 2 represents the color: Green. Frequency 1 is lower than that of red (not visible light).", result3, "compareFrequencies_OneNotVisibleOneVisible_Low");

            String result4 = analyzer.compareFrequencies(800.0, 700.0); // UV, then Violet
            assertEquals("Frequency 2 represents the color: Violet. Frequency 1 is higher than that of violet (not visible light).", result4, "compareFrequencies_OneNotVisibleOneVisible_High");
        } finally {
            tearDown();
        }
    }

    private static void testCompareFrequencies_BothNotVisible() {
        setUp();
        try {
            EMSpectrumAnalyzer analyzer = new EMSpectrumAnalyzer();
            String result = analyzer.compareFrequencies(300.0, 900.0); // Infrared, UV
            assertEquals("Both frequencies are not within the visible light range. Frequency 1: lower than that of red (not visible light). Frequency 2: higher than that of violet (not visible light).", result, "compareFrequencies_BothNotVisible_Mixed");

            String result2 = analyzer.compareFrequencies(200.0, 100.0); // Both Infrared (lower)
            assertEquals("Both frequencies are not within the visible light range. Frequency 1: lower than that of red (not visible light). Frequency 2: lower than that of red (not visible light).", result2, "compareFrequencies_BothNotVisible_BothLow");

            String result3 = analyzer.compareFrequencies(900.0, 1000.0); // Both UV (higher)
            assertEquals("Both frequencies are not within the visible light range. Frequency 1: higher than that of violet (not visible light). Frequency 2: higher than that of violet (not visible light).", result3, "compareFrequencies_BothNotVisible_BothHigh");
        } finally {
            tearDown();
        }
    }

    private static void testCompareFrequencies_BoundaryVisible() {
        setUp();
        try {
            EMSpectrumAnalyzer analyzer = new EMSpectrumAnalyzer();
            String result1 = analyzer.compareFrequencies(400.0, 789.5); // Red_Min, Violet_Max
            assertEquals("Both frequencies are visible light. Frequency 1: Red, Frequency 2: Violet.", result1, "compareFrequencies_BoundaryVisible_MinMax");

            String result2 = analyzer.compareFrequencies(399.9, 789.5); // Just below visible, Violet_Max
            assertEquals("Frequency 2 represents the color: Violet. Frequency 1 is lower than that of red (not visible light).", result2, "compareFrequencies_BoundaryVisible_BelowMin");

            String result3 = analyzer.compareFrequencies(400.0, 789.6); // Red_Min, Just above visible
            assertEquals("Frequency 1 represents the color: Red. Frequency 2 is higher than that of violet (not visible light).", result3, "compareFrequencies_BoundaryVisible_AboveMax");
        } finally {
            tearDown();
        }
    }

    // --- Main method to run all tests ---

    public static void main(String[] args) {
        System.out.println("--- Running EMSpectrumAnalyzer Tests ---");

        testGetVisibleColor_Violet();
        testGetVisibleColor_Blue();
        testGetVisibleColor_Cyan();
        testGetVisibleColor_Green();
        testGetVisibleColor_Yellow();
        testGetVisibleColor_Orange();
        testGetVisibleColor_Red();
        testGetVisibleColor_BelowRange();
        testGetVisibleColor_AboveRange();
        testConvertWavelengthToFrequency();
        testConvertFrequencyToWavelength();
        testGetColourFromFrequency();
        testGetFrequencyRangeForColor(); // New test for the new method
        testGetEMSpectrumRange_Wavelength();
        testGetEMSpectrumRange_Frequency();
        testGetEMSpectrumRange_InvalidType();
        testCompareFrequencies_BothVisible();
        testCompareFrequencies_OneVisibleOneNot();
        testCompareFrequencies_BothNotVisible();
        testCompareFrequencies_BoundaryVisible();


        System.out.println("\n--- Test Summary ---");
        System.out.println("Tests Run: " + testsRun);
        System.out.println("Tests Failed: " + testsFailed);

        if (testsFailed == 0) {
            System.out.println("All EMSpectrumAnalyzer tests passed!");
        } else {
            System.out.println("Some EMSpectrumAnalyzer tests failed. Please review the output above.");
        }
    }
}