# ISE Assignment 2025 S1 v1 - Software Engineering Program Documentation

Student Name: Nallaperuma Aachchilage Spencer Sterling Wickramaratne

Student ID: 23120839

Date: 23.05.2025

1. Introduction

This document is developed to demonstrate core software engineering principles including modular design, version control using Git, and software testing techniques. 
The software addresses two distinct scenarios related to colours:
Scenario A: Analysis of the electromagnetic spectrum and identification of visible light colours based on wavelength.
Scenario B:Providing interesting facts and associations related to specific colours, such as personality traits, associated stones, and musical notes.

The implementation is in Java, running in a Linux command-line environment, as specified.

 2. Design

The software's design emphasizes modularity, aiming for **High Cohesion** (each class having a single, focused responsibility) and **Low Coupling** (minimizing dependencies between classes). This modular structure enhances manageability, testability, and allows for potential future extensions.

The primary classes and their responsibilities are:

* `Main`: Acts as the application's orchestrator. It contains the `main` method (the program entry point) and manages the overall application flow. It presents a menu to the user, captures input via the `InputHandler`, directs output via the `OutputHandler`, and invokes the relevant methods in the `EMSpectrumAnalyzer` or `ColourFunFacts` based on user selection. Control flow is managed using a `while` loop for the menu and a `switch` statement for handling menu options.

* `InputHandler`: Dedicated to handling all user input, primarily from the console. It utilizes the `Scanner` class  to read different data types. This class encapsulates input logic and includes input validation using a `while` loop and basic `try-catch` blocks to handle invalid input types (e.g., non-numeric input when expecting numbers), preventing program crashes and prompting for correct input.

* `OutputHandler`: Responsible for managing all program output, directing it to the console. It provides simple methods (`printMessage`, `printFormattedMessage`, `printNewLine`) to display information to the user. This class encapsulates output logic, separating it from the core application logic.

* `EMSpectrumAnalyzer`: This module is responsible for implementing the logic for **Scenario A**. It contains methods to classify wavelengths within the electromagnetic spectrum and identify visible light colours. The implementation relies on `if-else if-else` control structures  to perform range checks and determine the appropriate output string.

* `ColourFunFacts`: This module handles the logic for **Scenario B**. It stores predefined associations between colours and facts (personality, stone, musical note) and provides methods to retrieve these facts based on a given colour name input.

 **Modularity Review Checklist**

This checklist helps assess whether software modules adhere to good modularity principles, focusing on high cohesion and low coupling.

| No. | Modularity Guideline | Check |
| :-- | :-------------------| :---- |
| 1   | **Modularity**: Is the software broken down into self-contained, logical units (classes, methods)? | Yes/No |
| 2   | **High Cohesion**: Does each module/class have a single, well-defined, and focused responsibility? | Yes/No |
| 3   | **Low Coupling**: Are dependencies between modules minimized? Are modules independent? | Yes/No |
| 4   | **Sensible Reuse**: Is code reuse applied only when tasks are truly the same? Are tight dependencies avoided for the sake of reuse? | Yes/No |


---

 **Modularity Review Results**

**Review of `Main.java`**

| Modularity Guideline | Issue Identified | Justification |
| :-------------------| :--------------- | :------------ |
| **Modularity** | No | The `Main` class serves as the orchestrator, initializing other modules and managing the overall application flow and user interaction loop. It effectively delegates tasks to other specialized classes. |
| **High Cohesion** | No | Its primary responsibility is application orchestration, menu presentation, and delegation of tasks to other handlers and analyzers. This is a single, well-defined responsibility for a main entry point class. |
| **Low Coupling** | No | `Main` interacts with `InputHandler`, `OutputHandler`, `EMSpectrumAnalyzer`, and `ColourFunFacts` through their public interfaces. It does not delve into their internal implementations, indicating low coupling. |
| **Sensible Reuse** | Not applicable | `Main` is the entry point and coordinator; its role isn't about reusable logic in the same way as the utility classes. |


 **Review of `InputHandler.java`**

| Modularity Guideline | Issue Identified | Justification |
| :-------------------| :--------------- | :------------ |
| **Modularity** | No | This class is a self-contained unit responsible solely for handling user input. |
| **High Cohesion** | No | Its single responsibility is input management, including reading different data types (double, string, int) and handling basic input validation. This is a highly cohesive module. |
| **Low Coupling** | No | `InputHandler` does not depend on any other application-specific modules. It only uses standard Java I/O (`Scanner`, `System.in`). It is very independent. |
| **Sensible Reuse** | No | The input reading and validation logic is encapsulated here, making it reusable across different parts of an application requiring user input. |


 **Review of `OutputHandler.java`**

| Modularity Guideline | Issue Identified | Justification |
| :-------------------| :--------------- | :------------ |
| **Modularity** | No | This class is a self-contained unit dedicated to output operations. |
| **High Cohesion** | No | Its single responsibility is outputting messages to the console in various formats (plain, formatted, new lines). This demonstrates high cohesion. |
| **Low Coupling** | No | `OutputHandler` does not depend on any other application-specific modules, only on standard Java output (`System.out`). It is highly independent. |
| **Sensible Reuse** | No | The output methods are generic and can be reused for displaying any kind of message in the console. |


 **Review of `EMSpectrumAnalyzer.java`**

| Modularity Guideline | Issue Identified | Justification |
| :-------------------| :--------------- | :------------ |
| **Modularity** | No | The class is a distinct unit for EM spectrum analysis. |
| **High Cohesion** | No | It focuses on calculations and classifications related to the electromagnetic spectrum and visible colors, which is a single, well-defined area of responsibility. |
| **Low Coupling** | No | It does not depend on `InputHandler`, `OutputHandler`, or `ColourFunFacts`. Its methods take parameters and return values, demonstrating low coupling. |
| **Sensible Reuse** | No | The methods `freqToWaveLength`, `getEmSpectrumRange`, and `getVisibleColor` are general utility functions related to EM spectrum analysis and are reusable in other contexts. |


#### **Review of `ColourFunFacts.java`**

| Modularity Guideline | Issue Identified | Justification |
| :-------------------| :--------------- | :------------ |
| **Modularity** | No | The class is a self-contained unit for handling color-related facts. |
| **High Cohesion** | No | THhe use of parallel arrays is a reasonable approach to manage related data. Each method (`getColourEmotion`, `getColourStone`, `getColourMusicalNote`) retrieves a specific type of fact, maintaining a focused responsibility within the context of the given data structure limitations. |
| **Low Coupling** | No | The module is not coupled to `InputHandler`, `OutputHandler`, or `EMSpectrumAnalyzer`. It takes a color string as input and returns a string fact, maintaining low coupling with other modules. |
| **Sensible Reuse** | No | The methods effectively encapsulate the logic for retrieving color facts. While parallel arrays might have limitations for significant future extensions with many new fact types, within the current scope, the current structure allows for sensible reuse of the fact retrieval logic. |


---

### **Refactoring Justification**

Based on the modularity review, **no refactoring is required for any of the provided Java classes** (`Main.java`, `InputHandler.java`, `OutputHandler.java`, `EMSpectrumAnalyzer.java`, and `ColourFunFacts.java`).

Each class adheres to good modularity principles as follows:

* **`Main.java`**: This class acts as the orchestrator of the application. Its sole responsibility is to manage the application flow, display menus, and delegate tasks to other specialized handler and analyzer classes. This demonstrates high cohesion and low coupling, as it interacts with other modules through their public interfaces without delving into their internal implementations.

* **`InputHandler.java`**: This module is highly cohesive, as its single responsibility is to manage all user input operations. It encapsulates input reading and validation logic, making it independent of other application logic and reusable across different parts of the program that require user input.

* **`OutputHandler.java`**: Similarly, this module is highly cohesive, with its sole responsibility being to manage and display all program output to the console. It encapsulates output formatting and printing, ensuring separation of concerns from the core application logic.

* **`EMSpectrumAnalyzer.java`**: This class is a dedicated module for handling electromagnetic spectrum analysis. It exhibits high cohesion by focusing on calculations and classifications related to wavelengths and visible colors. Its methods operate independently, taking parameters and returning results, thus maintaining low coupling with other parts of the application.

* **`ColourFunFacts.java`**: The current implementation using parallel arrays is considered appropriate. Within this context, the class maintains high cohesion by focusing on providing color-related facts and demonstrates sensible reuse through its fact retrieval methods. Its internal details (parallel arrays, `findColorIndex` method) are encapsulated, and it maintains low coupling with other modules.

The production code can be compiled and run as follows:          
    To compile:javac EMSpectrumAnalyzer.java ColourFunFacts.java InputHandler.java OutputHandler.java Main.java       
    To run    :java Main

Image of the compiled production code up and running:

![Alt text for the image](coderun.png)

# Black Box Testing

# Equivalence Partitioning (EP) Analysis

This document outlines the Equivalence Partitioning (EP) analysis for the `EMSpectrumAnalyzer.java`, `ColourFunFacts.java`, `InputHandler.java`, `OutputHandler.java`, and `Main.java` files. Equivalence Partitioning is a black-box testing technique that divides the input domain into a set of equivalence classes. Test cases are then chosen from each class.

## 1. EMSpectrumAnalyzer.java - Equivalence Partitioning

This class analyzes electromagnetic spectrum properties and identifies visible light colours based on wavelength and frequency.


The `EMSpectrumAnalyzer.java` file defines the following constants for visible light and frequency ranges:

* **Visible Wavelength Range:** `380.0 nm` (Violet) to `750.0 nm` (Red)
* **Speed of Light (C):** `300000.0 nm/THz`
* **Visible Frequency Range:** `400.0 THz` (Red) to `789.5 THz` (Violet)

**Note on Color Frequency Ranges:**
Based on the `getColourFromFrequency` method, the approximate THz ranges for colors are:
* Red: `400.0 - 483.8 THz`
* Orange: `483.9 - 508.4 THz`
* Yellow: `508.5 - 526.39 THz`
* Green: `526.4 - 599.99 THz`
* Cyan: `600.0 - 666.69 THz`
* Blue: `666.7 - 713.99 THz`
* Violet: `714.0 - 789.5 THz`

---

### 1.1. `convertWavelengthToFrequency(double wavelengthNm)`

| Partition Category | Description                                   | Representative Test Data (wavelengthNm) | Expected Output Behavior                   |
| :----------------- | :-------------------------------------------- | :-------------------------------------- | :----------------------------------------- |
| Valid              | Typical visible light wavelength              | `600.0`                                 | `500.0` (C / 600)                          |
| Valid              | Upper boundary of visible wavelength          | `750.0`                                 | `400.0` (C / 750)                          |
| Valid              | Lower boundary of visible wavelength          | `380.0`                                 | `789.4736...` (C / 380)                    |
| Valid              | Very small positive wavelength (e.g., X-ray)  | `10.0`                                  | `30000.0` (C / 10)                         |
| Valid              | Very large positive wavelength (e.g., Radio)  | `1000000.0`                             | `0.3` (C / 1,000,000)                      |
| Invalid            | Zero wavelength (division by zero)            | `0.0`                                   | `Infinity`                                 |
| Invalid            | Negative wavelength                           | `-50.0`                                 | `NaN` (Not a Number) or error handling     |

---

### 2.2. `convertFrequencyToWavelength(double frequencyThz)`

| Partition Category | Description                                   | Representative Test Data (frequencyThz) | Expected Output Behavior                   |
| :----------------- | :-------------------------------------------- | :-------------------------------------- | :----------------------------------------- |
| Valid              | Typical visible light frequency               | `500.0`                                 | `600.0` (C / 500)                          |
| Valid              | Lower boundary of visible frequency           | `400.0`                                 | `750.0` (C / 400)                          |
| Valid              | Upper boundary of visible frequency           | `789.5`                                 | `380.0` (C / 789.5)                        |
| Valid              | Very high frequency (e.g., X-ray)             | `30000.0`                               | `10.0` (C / 30000)                         |
| Valid              | Very low frequency (e.g., Radio)              | `0.3`                                   | `1000000.0` (C / 0.3)                      |
| Invalid            | Zero frequency (division by zero)             | `0.0`                                   | `Infinity`                                 |
| Invalid            | Negative frequency                            | `-20.0`                                 | `NaN` (Not a Number) or error handling     |

---

### 3.3. `getVisibleColor(double wavelengthNm)`

| Partition Category | Description                             | Representative Test Data (wavelengthNm) | Expected Output Behavior      |
| :----------------- | :-------------------------------------- | :-------------------------------------- | :---------------------------- |
| Valid              | Red color range (620.0 - 750.0 nm)      | `700.0`                                 | `"Red"`                       |
| Valid              | Orange color range (590.0 - 619.9 nm)   | `600.0`                                 | `"Orange"`                    |
| Valid              | Yellow color range (570.0 - 589.9 nm)   | `580.0`                                 | `"Yellow"`                    |
| Valid              | Green color range (495.0 - 569.9 nm)    | `520.0`                                 | `"Green"`                     |
| Valid              | Cyan color range (450.0 - 494.9 nm)     | `460.0`                                 | `"Cyan"`                      |
| Valid              | Blue color range (420.0 - 449.9 nm)     | `430.0`                                 | `"Blue"`                      |
| Valid              | Violet color range (380.0 - 419.9 nm)   | `400.0`                                 | `"Violet"`                    |
| Boundary           | Upper visible light limit (Red)         | `750.0`                                 | `"Red"`                       |
| Boundary           | Lower visible light limit (Violet)      | `380.0`                                 | `"Violet"`                    |
| Invalid            | Just above visible range (Infrared)     | `750.1`                                 | `"Not visible light"`         |
| Invalid            | Just below visible range (Ultraviolet)  | `379.9`                                 | `"Not visible light"`         |
| Invalid            | Clearly above visible range (Infrared)  | `1000.0`                                | `"Not visible light"`         |
| Invalid            | Clearly below visible range (Ultraviolet) | `100.0`                                 | `"Not visible light"`         |
| Invalid            | Zero wavelength                         | `0.0`                                   | `"Not visible light"`         |
| Invalid            | Negative wavelength                     | `-50.0`                                 | `"Not visible light"`         |

---

### 4.4. `getColourFromFrequency(double frequencyThz)`

| Partition Category | Description                             | Representative Test Data (frequencyThz) | Expected Output Behavior      |
| :----------------- | :-------------------------------------- | :-------------------------------------- | :---------------------------- |
| Valid              | Red color range (400.0 - 483.8 THz)     | `450.0`                                 | `"Red"`                       |
| Valid              | Orange color range (483.9 - 508.4 THz)  | `490.0`                                 | `"Orange"`                    |
| Valid              | Yellow color range (508.5 - 526.39 THz) | `515.0`                                 | `"Yellow"`                    |
| Valid              | Green color range (526.4 - 599.99 THz)  | `550.0`                                 | `"Green"`                     |
| Valid              | Cyan color range (600.0 - 666.69 THz)   | `630.0`                                 | `"Cyan"`                      |
| Valid              | Blue color range (666.7 - 713.99 THz)   | `690.0`                                 | `"Blue"`                      |
| Valid              | Violet color range (714.0 - 789.5 THz)  | `750.0`                                 | `"Violet"`                    |
| Boundary           | Lower visible frequency limit (Red)     | `400.0`                                 | `"Red"`                       |
| Boundary           | Upper visible frequency limit (Violet)  | `789.5`                                 | `"Violet"`                    |
| Invalid            | Just below visible range (Radio)        | `399.9`                                 | `"Not visible light"`         |
| Invalid            | Just above visible range (X-ray)        | `789.6`                                 | `"Not visible light"`         |
| Invalid            | Clearly below visible range (Radio)     | `100.0`                                 | `"Not visible light"`         |
| Invalid            | Clearly above visible range (X-ray)     | `1000.0`                                | `"Not visible light"`         |
| Invalid            | Zero frequency                          | `0.0`                                   | `"Not visible light"`         |
| Invalid            | Negative frequency                      | `-10.0`                                 | `"Not visible light"`         |

---

### 5.5. `getEMSpectrumRange(double value, String type)`

| Partition Category | Description                                   | Representative Test Data (value, type) | Expected Output Behavior                                          |
| :----------------- | :-------------------------------------------- | :------------------------------------- | :---------------------------------------------------------------- |
| Valid              | Wavelength: Visible Light                     | `600.0`, `"wavelength"`                | `"Visible Light"`                                                 |
| Valid              | Wavelength: Ultraviolet                       | `100.0`, `"wavelength"`                | `"Ultraviolet"`                                                   |
| Valid              | Wavelength: X-Ray                             | `10.0`, `"wavelength"`                 | `"X-Ray"`                                                         |
| Valid              | Wavelength: Gamma Ray                         | `0.1`, `"wavelength"`                  | `"Gamma Ray"`                                                     |
| Valid              | Wavelength: Infrared                          | `1000.0`, `"wavelength"`               | `"Infrared"`                                                      |
| Valid              | Wavelength: Microwave                         | `100000.0`, `"wavelength"`             | `"Microwave"`                                                     |
| Valid              | Wavelength: Radio Wave                        | `1000000.0`, `"wavelength"`            | `"Radio Wave"`                                                    |
| Valid              | Frequency: Visible Light                      | `550.0`, `"frequency"`                 | `"Visible Light"`                                                 |
| Valid              | Frequency: Ultraviolet                        | `800.0`, `"frequency"`                 | `"Ultraviolet"`                                                   |
| Valid              | Frequency: X-Ray                              | `30000.0`, `"frequency"`               | `"X-Ray"`                                                         |
| Valid              | Frequency: Gamma Ray                          | `3000000.0`, `"frequency"`             | `"Gamma Ray"`                                                     |
| Valid              | Frequency: Infrared                           | `300.0`, `"frequency"`                 | `"Infrared"`                                                      |
| Valid              | Frequency: Microwave                          | `3.0`, `"frequency"`                   | `"Microwave"`                                                     |
| Valid              | Frequency: Radio Wave                         | `0.003`, `"frequency"`                 | `"Radio Wave"`                                                    |
| Boundary           | Wavelength: Min visible limit                 | `380.0`, `"wavelength"`                | `"Visible Light"`                                                 |
| Boundary           | Wavelength: Max visible limit                 | `750.0`, `"wavelength"`                | `"Visible Light"`                                                 |
| Boundary           | Frequency: Min visible limit                  | `400.0`, `"frequency"`                 | `"Visible Light"`                                                 |
| Boundary           | Frequency: Max visible limit                  | `789.5`, `"frequency"`                 | `"Visible Light"`                                                 |

---

### 6.6. `compareFrequencies(double freq1, double freq2)`

| Partition Category           | Description                                                 | Representative Test Data (freq1, freq2) | Expected Output Behavior                                                                                                                                              |
| :--------------------------- | :---------------------------------------------------------- | :-------------------------------------- | :-------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Both Visible                 | Both frequencies within visible range                       | `500.0`, `600.0`                        | `"Frequency 1 represents the color: Yellow. Frequency 2 represents the color: Green."`                                                                                |
| One Visible, One Above       | Freq1 visible, Freq2 above visible range                    | `450.0`, `800.0`                        | `"Frequency 1 represents the color: Red. Frequency 2 is higher than that of violet (not visible light)."`                                                             |
| One Visible, One Below       | Freq1 visible, Freq2 below visible range                    | `700.0`, `300.0`                        | `"Frequency 1 represents the color: Blue. Frequency 2 is lower than that of red (not visible light)."`                                                                |
| One Above, One Visible       | Freq2 visible, Freq1 above visible range                    | `800.0`, `500.0`                        | `"Frequency 2 represents the color: Yellow. Frequency 1 is higher than that of violet (not visible light)."`                                                            |
| One Below, One Visible       | Freq2 visible, Freq1 below visible range                    | `300.0`, `700.0`                        | `"Frequency 2 represents the color: Blue. Frequency 1 is lower than that of red (not visible light)."`                                                                |
| Both Below Visible           | Both frequencies below visible range                        | `300.0`, `350.0`                        | `"Both frequencies are not within the visible light range. Frequency 1: lower than that of red (not visible light). Frequency 2: lower than that of red (not visible light)."` |
| Both Above Visible           | Both frequencies above visible range                        | `800.0`, `900.0`                        | `"Both frequencies are not within the visible light range. Frequency 1: higher than that of violet (not visible light). Frequency 2: higher than that of violet (not visible light)."` |
| One Below, One Above         | One frequency below, one above visible range                | `300.0`, `900.0`                        | `"Both frequencies are not within the visible light range. Frequency 1: lower than that of red (not visible light). Frequency 2: higher than that of violet (not visible light)."` |
| Boundary                     | Both frequencies at visible limits                          | `400.0`, `789.5`                        | `"Frequency 1 represents the color: Red. Frequency 2 represents the color: Violet."`                                                                                  |
| Boundary                     | Frequencies just outside visible limits                     | `399.9`, `789.6`                        | `"Both frequencies are not within the visible light range. Frequency 1: lower than that of red (not visible light). Frequency 2: higher than that of violet (not visible light)."` |
| Same and Visible             | Both frequencies are the same and visible                   | `500.0`, `500.0`                        | `"Frequency 1 represents the color: Yellow. Frequency 2 represents the color: Yellow."`                                                                               |
| Invalid Input (Zero)         | One frequency is zero (treated as below visible)            | `0.0`, `500.0`                          | `"Frequency 2 represents the color: Yellow. Frequency 1 is lower than that of red (not visible light)."`                                                              |
| Invalid Input (Negative)     | One frequency is negative (treated as below visible)        | `-10.0`, `600.0`                        | `"Frequency 2 represents the color: Green. Frequency 1 is lower than that of red (not visible light)."`                                                               |


## 2. ColourFunFacts.java - Equivalence Partitioning

This class provides facts associated with predefined color names. The core logic for finding colors is in `findColorIndex`.

The `ColourFunFacts.java` file defines the following parallel arrays for color data:

* `colorNames`: `{"violet", "blue", "cyan", "green", "yellow", "orange", "red"}`
* `colourEmotions`: `{"Bravery", "Calm", "Calm", "Peaceful", "Happy", "Happy", "Confidence"}`
* `colourStones`: `{"Amethyst", "Opal", "Turquoise", "Emerald", "Topaz", "Moonstone", "Garnet"}`
* `colourMusicalNotes`: `{"B", "A", "G", "F", "E", "D", "C"}`

---

### 2.1. `findColorIndex(String color)` (Private Method)

This private method is crucial as other public methods depend on its output. It performs a case-insensitive search for a color name.

| Partition Category | Description                               | Representative Test Data (color) | Expected Output Behavior |
| :----------------- | :---------------------------------------- | :------------------------------- | :----------------------- |
| Valid              | Known color (exact case)                  | `"Red"`                          | `6` (index of "red")     |
| Valid              | Known color (lowercase)                   | `"yellow"`                       | `4` (index of "yellow")  |
| Valid              | Known color (uppercase)                   | `"BLUE"`                         | `1` (index of "blue")    |
| Valid              | Known color (mixed case)                  | `"ViOlEt"`                       | `0` (index of "violet")  |
| Invalid            | Unknown color                             | `"Brown"`                        | `-1`                     |
| Invalid            | Empty string                              | `""`                             | `-1`                     |
| Invalid            | String with spaces only                   | `"   "`                          | `-1`                     |
| Invalid            | `null` input string                       | `null`                           | `-1`                     |

---

### 2.2. `getColourEmotion(String color)`

This method returns the emotion associated with a given color.

| Partition Category | Description                               | Representative Test Data (color) | Expected Output Behavior      |
| :----------------- | :---------------------------------------- | :------------------------------- | :---------------------------- |
| Valid              | Known color (exact case)                  | `"Green"`                        | `"Peaceful"`                  |
| Valid              | Known color (lowercase)                   | `"orange"`                       | `"Happy"`                     |
| Valid              | Known color (uppercase)                   | `"VIOLET"`                       | `"Bravery"`                   |
| Valid              | Known color (mixed case)                  | `"cYAn"`                         | `"Calm"`                      |
| Invalid            | Unknown color                             | `"Grey"`                         | `"Unknown emotion"`           |
| Invalid            | Empty string                              | `""`                             | `"Unknown emotion"`           |
| Invalid            | String with spaces only                   | `"   "`                          | `"Unknown emotion"`           |
| Invalid            | `null` input string                       | `null`                           | `"Unknown emotion"`           |

---

### 2.3. `getColourStone(String color)`

This method returns the associated stone for a given color.

| Partition Category | Description                               | Representative Test Data (color) | Expected Output Behavior  |
| :----------------- | :---------------------------------------- | :------------------------------- | :------------------------ |
| Valid              | Known color (exact case)                  | `"Blue"`                         | `"Opal"`                  |
| Valid              | Known color (lowercase)                   | `"red"`                          | `"Garnet"`                |
| Valid              | Known color (uppercase)                   | `"YELLOW"`                       | `"Topaz"`                 |
| Valid              | Known color (mixed case)                  | `"cYAn"`                         | `"Turquoise"`             |
| Invalid            | Unknown color                             | `"Black"`                        | `"Unknown stone"`         |
| Invalid            | Empty string                              | `""`                             | `"Unknown stone"`         |
| Invalid            | String with spaces only                   | `"   "`                          | `"Unknown stone"`         |
| Invalid            | `null` input string                       | `null`                           | `"Unknown stone"`         |

---

### 2.4. `getColourMusicalNote(String color)`

This method returns the associated musical note for a given color.

| Partition Category | Description                               | Representative Test Data (color) | Expected Output Behavior      |
| :----------------- | :---------------------------------------- | :------------------------------- | :---------------------------- |
| Valid              | Known color (exact case)                  | `"Violet"`                       | `"B"`                         |
| Valid              | Known color (lowercase)                   | `"cyan"`                         | `"G"`                         |
| Valid              | Known color (uppercase)                   | `"ORANGE"`                       | `"D"`                         |
| Valid              | Known color (mixed case)                  | `"gReeN"`                        | `"F"`                         |
| Invalid            | Unknown color                             | `"White"`                        | `"Unknown musical note"`      |
| Invalid            | Empty string                              | `""`                             | `"Unknown musical note"`      |
| Invalid            | String with spaces only                   | `"   "`                          | `"Unknown musical note"`      |
| Invalid            | `null` input string                       | `null`                           | `"Unknown musical note"`      |

## 3. InputHandler.java - Equivalence Partitioning

This class manages user input from the console.

### 3.1. `readDouble(String prompt)`

This method reads a double value from the console, providing a prompt and handling invalid number formats by re-prompting.

| Partition Category | Description                                   | Representative Test Data (Simulated User Input) | Expected Output Behavior                               |
| :----------------- | :-------------------------------------------- | :---------------------------------------------- | :------------------------------------------------------- |
| Valid              | Positive decimal number                       | `123.45`                                        | Returns `123.45`                                         |
| Valid              | Negative decimal number                       | `-67.89`                                        | Returns `-67.89`                                         |
| Valid              | Zero                                          | `0.0`                                           | Returns `0.0`                                            |
| Valid              | Large positive number                         | `1.0E300`                                       | Returns `1.0E300`                                        |
| Valid              | Small positive number (close to zero)         | `0.000001`                                      | Returns `0.000001`                                       |
| Valid              | Positive integer (parsed as double)           | `100`                                           | Returns `100.0`                                          |
| Valid              | Negative integer (parsed as double)           | `-50`                                           | Returns `-50.0`                                          |
| Invalid (handled)  | Non-numeric string, then valid number         | `abc`<br>`12.3`                                 | Prints "Invalid input. Please enter a number." then returns `12.3` |
| Invalid (handled)  | Empty string (followed by valid input)        | `\n`<br>`45.6`                                  | (Scanner might interpret empty line as invalid, leading to re-prompt) Prints "Invalid input. Please enter a number." then returns `45.6` |
| Invalid (handled)  | Special characters, then valid number         | `!@#$`<br>`78.9`                                | Prints "Invalid input. Please enter a number." then returns `78.9` |


---

### 3.2. `readString(String prompt)`

This method reads a string value from the console after displaying a prompt.

| Partition Category | Description                               | Representative Test Data (Simulated User Input) | Expected Output Behavior          |
| :----------------- | :---------------------------------------- | :---------------------------------------------- | :-------------------------------- |
| Valid              | Regular string with words                 | `Hello World`                                   | Returns `"Hello World"`           |
| Valid              | String with leading/trailing spaces       | `  trimmed string  `                            | Returns `"  trimmed string  "`    |
| Valid              | Empty string                              | ` ` (just newline)                              | Returns `""`                      |
| Valid              | String with special characters            | `!@#$%^&*()`                                    | Returns `"!@#$%^&*()"`            |
| Valid              | Long string                               | (e.g., 255 characters)                          | Returns the full string           |


---

### 3.3. `readInt(String prompt)`

This method reads an integer value from the console, providing a prompt and handling invalid integer formats by re-prompting.

| Partition Category | Description                                   | Representative Test Data (Simulated User Input) | Expected Output Behavior                               |
| :----------------- | :-------------------------------------------- | :---------------------------------------------- | :------------------------------------------------------- |
| Valid              | Positive integer                              | `123`                                           | Returns `123`                                            |
| Valid              | Negative integer                              | `-456`                                          | Returns `-456`                                           |
| Valid              | Zero                                          | `0`                                             | Returns `0`                                              |
| Valid              | Large positive integer                        | `2147483647` (Integer.MAX_VALUE)                | Returns `2147483647`                                     |
| Valid              | Small negative integer                        | `-2147483648` (Integer.MIN_VALUE)               | Returns `-2147483648`                                    |
| Invalid (handled)  | Non-integer string, then valid integer        | `xyz`<br>`789`                                  | Prints "Invalid input. Please enter an integer." then returns `789` |
| Invalid (handled)  | Decimal number, then valid integer            | `12.34`<br>`567`                                | Prints "Invalid input. Please enter an integer." then returns `567` |
| Invalid (handled)  | Number exceeding int range, then valid integer | `999999999999`<br>`1`                          | Prints "Invalid input. Please enter an integer." (due to `InputMismatchException` for too large number) then returns `1` |



# OutputHandler Test Cases - Equivalence Partitioning

### 4.1. `printMessage(String message)`

This method prints a given string message followed by a newline.

| Partition Category | Description                           | Representative Test Data (message) | Expected Output Behavior                               |
| :----------------- | :------------------------------------ | :--------------------------------- | :------------------------------------------------------- |
| Valid              | Regular string with words             | `"Hello, World!"`                  | Prints `Hello, World!` followed by a newline (`\n`)    |
| Valid              | Empty string                          | `""`                               | Prints an empty line (`\n`)                              |
| Valid              | String with special characters        | `"!@#$%^&*()_+"`                   | Prints `!@#$%^&*()_+` followed by a newline (`\n`)     |
| Valid              | String with numbers                   | `"The year is 2025."`              | Prints `The year is 2025.` followed by a newline (`\n`) |
| Invalid            | `null` string                         | `null`                             | Prints `null` followed by a newline (`\n`) (standard `System.out.println(null)` behavior) |

---

### 4.2. `printFormattedMessage(String format, Object... args)`

This method prints a formatted string using `printf` style.

| Partition Category | Description                                   | Representative Test Data (format, args)         | Expected Output Behavior                               |
| :----------------- | :-------------------------------------------- | :---------------------------------------------- | :------------------------------------------------------- |
| Valid              | Single string argument (`%s`)                 | `"%s"`, `"Test"`                                | Prints `Test`                                            |
| Valid              | Single integer argument (`%d`)                | `"%d"`, `123`                                   | Prints `123`                                             |
| Valid              | Single double argument (`%.2f`)               | `"%.2f"`, `3.14159`                             | Prints `3.14`                                            |
| Valid              | Multiple arguments (`%s %d`)                  | `"%s has %d apples."`, `"John"`, `5`            | Prints `John has 5 apples.`                              |
| Valid              | Format with no arguments                      | `"No args here."`                               | Prints `No args here.`                                   |
| Valid              | Empty format string (no args)                 | `""`                                            | Prints nothing                                           |
| Invalid            | `null` format string                          | `null`, `null`                                  | `NullPointerException`                                   |




### 4.3. `printNewLine()`

This method prints a blank line.

| Partition Category | Description           | Representative Test Data | Expected Output Behavior      |
| :----------------- | :-------------------- | :----------------------- | :---------------------------- |
| Default            | Call the method       | (No input parameters)    | Prints a single newline (`\n`) |


# Main Class Test Cases - Equivalence Partitioning

### 5.1. `main(String[] args)` - Overall Program Flow

This section covers the `main` method's interaction with `InputHandler`, `OutputHandler`, `EMSpectrumAnalyzer`, and `ColourFunFacts` based on user menu choices.

| Partition Category | Description                                                                | Representative Test Data (Simulated User Input)             | Expected Output Behavior                                                                                                                                                                                                                                                |
| :----------------- | :------------------------------------------------------------------------- | :---------------------------------------------------------- | :---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Valid Flow         | Scenario 1: Analyze EM Spectrum (Wavelength to Frequency & Spectrum Range) | `1`<br>`600.0`<br>`wavelength`<br>`3`                       | Displays menu, prompts for choice, prompts for wavelength, prompts for type, displays conversion and spectrum range, displays menu, prompts for choice, displays exit message, program terminates. Output should contain "Frequency: 500.0 THz" and "Visible Light".           |
| Valid Flow         | Scenario 1: Analyze EM Spectrum (Frequency to Wavelength & Spectrum Range) | `1`<br>`500.0`<br>`frequency`<br>`3`                       | Displays menu, prompts for choice, prompts for frequency, prompts for type, displays conversion and spectrum range, displays menu, prompts for choice, displays exit message, program terminates. Output should contain "Wavelength: 600.0 nm" and "Visible Light".         |
| Valid Flow         | Scenario 2: Get Colour Facts (Valid Color)                                 | `2`<br>`Red`<br>`3`                                         | Displays menu, prompts for choice, prompts for color name, displays emotion, stone, and musical note for "Red", displays menu, prompts for choice, displays exit message, program terminates. Output should contain "Emotion: Confidence", "Associated Stone: Garnet", "Associated Musical Note: C". |
| Valid Flow         | Scenario 2: Get Colour Facts (Invalid Color, then Valid)                   | `2`<br>`Brown`<br>`2`<br>`Blue`<br>`3`                     | Displays menu, prompts for choice, prompts for color name ("Brown"), displays "Unknown emotion/stone/note", displays menu, prompts for choice, prompts for color name ("Blue"), displays correct facts for "Blue", displays menu, prompts for choice, displays exit message, program terminates. |
| Valid Flow         | Exit Program                                                               | `3`                                                         | Displays menu, prompts for choice, displays "Exiting program.", program terminates.                                                                                                                                                                                     |
| Invalid Choice     | Invalid menu choice, then valid, then exit                                 | `4`<br>`10`<br>`1`<br>`500.0`<br>`wavelength`<br>`3`     | Displays menu, prompts for choice. For `4` and `10`, prints "Invalid choice. Please try again." and re-displays menu. Then proceeds with Scenario 1, displays results, and exits.                                                                                     |
| Invalid Input      | Non-numeric input for menu choice (handled by InputHandler)                | `abc`<br>`1`<br>`600.0`<br>`wavelength`<br>`3`             | Displays menu, prompts for choice. For `abc`, prints "Invalid input. Please enter an integer." (from InputHandler), re-prompts for choice. Then proceeds with Scenario 1, displays results, and exits.                                                                |
| Invalid Input      | Non-numeric input for wavelength/frequency (handled by InputHandler)       | `1`<br>`xyz`<br>`600.0`<br>`wavelength`<br>`3`             | Displays menu, prompts for choice (1). Prompts for wavelength. For `xyz`, prints "Invalid input. Please enter a number." (from InputHandler), re-prompts for wavelength. Then proceeds with analysis, displays results, and exits.                                  |
| Boundary           | Menu choice at lower boundary                                              | `1`<br>`600.0`<br>`wavelength`<br>`3`                       | Same as Valid Flow for Scenario 1.                                                                                                                                                                                                                                      |
| Boundary           | Menu choice at upper boundary                                              | `2`<br>`Red`<br>`3`                                         | Same as Valid Flow for Scenario 2.                                                                                                                                                                                                                                      |


# Boundary Value Analysis (BVA)

This document presents the Boundary Value Analysis (BVA) for the `EMSpectrumAnalyzer.java` and `ColourFunFacts.java` files. BVA is a software testing technique that tests the behavior of software at the boundaries of its input domain.

## EMSpectrumAnalyzer.java - Boundary Value Analysis

The `EMSpectrumAnalyzer` class deals with numerical inputs (wavelengths and frequencies) and categorizes them into different electromagnetic spectrum ranges or visible colors.

### 1. `getEmSpectrumRange(double wavelengthNm)` Method

This method determines the electromagnetic spectrum range for a given wavelength in nanometers.

**Defined Constants/Boundaries:**
* `ULTRAVIOLET_MIN_EXAMPLE = 10.0`
* `VISIBLE_LIGHT_MIN = 380.0`
* `VISIBLE_LIGHT_MAX = 750.0`
* `INFRARED_MAX_EXAMPLE = 1000000.0`

**Input Ranges & Expected Outputs:**
* `wavelengthNm >= 380.0 && wavelengthNm <= 750.0`: "Visible Light"
* `wavelengthNm < 380.0 && wavelengthNm >= 10.0`: "Ultraviolet"
* `wavelengthNm > 750.0 && wavelengthNm <= 1000000.0`: "Infrared"
* Otherwise: "Other EM Spectrum"

**Boundary Values for `getEmSpectrumRange`:**

| Boundary Point                    | Test Value (wavelengthNm) | Expected Output       | Rationale                                          |
| :-------------------------------- | :------------------------ | :-------------------- | :------------------------------------------------- |
| **Around 10.0 (ULTRAVIOLET_MIN_EXAMPLE)** | 9.9                       | "Other EM Spectrum"   | Just below boundary                              |
|                                   | 10.0                      | "Ultraviolet"         | At boundary (inclusive)                          |
|                                   | 10.1                      | "Ultraviolet"         | Just above boundary                              |
| **Around 380.0 (VISIBLE_LIGHT_MIN)** | 379.9                     | "Ultraviolet"         | Just below boundary                              |
|                                   | 380.0                     | "Visible Light"       | At boundary (inclusive)                          |
|                                   | 380.1                     | "Visible Light"       | Just above boundary                              |
| **Around 750.0 (VISIBLE_LIGHT_MAX)** | 749.9                     | "Visible Light"       | Just below boundary                              |
|                                   | 750.0                     | "Visible Light"       | At boundary (inclusive)                          |
|                                   | 750.1                     | "Infrared"            | Just above boundary                              |
| **Around 1000000.0 (INFRARED_MAX_EXAMPLE)** | 999999.9                  | "Infrared"            | Just below boundary                              |
|                                   | 1000000.0                 | "Infrared"            | At boundary (inclusive)                          |
|                                   | 1000000.1                 | "Other EM Spectrum"   | Just above boundary                              |
| **Extreme Values** | -1.0                      | "Other EM Spectrum"   | Negative wavelength (invalid but possible input) |
|                                   | 0.0                       | "Other EM Spectrum"   | Zero wavelength                                  |
|                                   | 1000000000.0              | "Other EM Spectrum"   | Very large wavelength                            |

### 2. `getVisibleColor(double wavelengthNm)` Method

This method determines the visible color for a given wavelength within the visible spectrum.

**Defined Constants/Boundaries:**
* `VISIBLE_LIGHT_MIN = 380.0`
* `VISIBLE_LIGHT_MAX = 750.0`

**Input Ranges & Expected Outputs (for visible light):**
* `[380, 450)`: "Violet"
* `[450, 485)`: "Blue"
* `[485, 500)`: "Cyan"
* `[500, 570)`: "Green"
* `[570, 590)`: "Yellow"
* `[590, 620)`: "Orange"
* `[620, 750]`: "Red" 
* Outside `[380, 750]`: "Not Visible Light"

**Boundary Values for `getVisibleColor`:**

| Boundary Point                    | Test Value (wavelengthNm) | Expected Output       | Rationale                                                    |
| :-------------------------------- | :------------------------ | :-------------------- | :----------------------------------------------------------- |
| **Around 380.0 (VISIBLE_LIGHT_MIN)** | 379.9                     | "Not Visible Light"   | Just below visible light min                                 |
|                                   | 380.0                     | "Violet"              | At visible light min (inclusive)                             |
|                                   | 380.1                     | "Violet"              | Just above visible light min                                 |
| **Around 450.0 (Violet/Blue)** | 449.9                     | "Violet"              | Just below boundary                                          |
|                                   | 450.0                     | "Blue"                | At boundary (inclusive for Blue, exclusive for Violet)       |
|                                   | 450.1                     | "Blue"                | Just above boundary                                          |
| **Around 485.0 (Blue/Cyan)** | 484.9                     | "Blue"                | Just below boundary                                          |
|                                   | 485.0                     | "Cyan"                | At boundary (inclusive for Cyan, exclusive for Blue)         |
|                                   | 485.1                     | "Cyan"                | Just above boundary                                          |
| **Around 500.0 (Cyan/Green)** | 499.9                     | "Cyan"                | Just below boundary                                          |
|                                   | 500.0                     | "Green"               | At boundary (inclusive for Green, exclusive for Cyan)        |
|                                   | 500.1                     | "Green"               | Just above boundary                                          |
| **Around 570.0 (Green/Yellow)** | 569.9                     | "Green"               | Just below boundary                                          |
|                                   | 570.0                     | "Yellow"              | At boundary (inclusive for Yellow, exclusive for Green)      |
|                                   | 570.1                     | "Yellow"              | Just above boundary                                          |
| **Around 590.0 (Yellow/Orange)** | 589.9                     | "Yellow"              | Just below boundary                                          |
|                                   | 590.0                     | "Orange"              | At boundary (inclusive for Orange, exclusive for Yellow)     |
|                                   | 590.1                     | "Orange"              | Just above boundary                                          |
| **Around 620.0 (Orange/Red)** | 619.9                     | "Orange"              | Just below boundary                                          |
|                                   | 620.0                     | "Red"                 | At boundary (inclusive for Red, exclusive for Orange)        |
|                                   | 620.1                     | "Red"                 | Just above boundary                                          |
| **Around 750.0 (VISIBLE_LIGHT_MAX)** | 749.9                     | "Red"                 | Just below visible light max                                 |
|                                   | 750.0                     | "Red"                 | At visible light max (inclusive)                             |
|                                   | 750.1                     | "Not Visible Light"   | Just above visible light max                                 |
| **Extreme Values** | -1.0                      | "Not Visible Light"   | Negative wavelength (invalid but possible input)             |
|                                   | 0.0                       | "Not Visible Light"   | Zero wavelength                                              |
|                                   | 1000.0                    | "Not Visible Light"   | Wavelength far outside visible range                         |

## ColourFunFacts.java - Boundary Value Analysis

The `ColourFunFacts` class primarily deals with string inputs (color names) and retrieves associated facts. The core logic for string comparison and lookup is within the `findColorIndex` method.

### 1. `findColorIndex(String color)` Method

This private helper method finds the index of a given color name in the `colorNames` array (case-insensitive search). This method is called by `getColourEmotion`, `getColourStone`, and `getColourMusicalNote`.

**Defined Color Names:**
`{"violet", "blue", "cyan", "green", "yellow", "orange", "red"}`

**Input Validation:**
* `if (lCaseColor == null)`: returns -1

**Boundary Values for `findColorIndex` (and by extension, dependent methods):**

| Boundary Point                    | Test Value (color)    | Expected `findColorIndex` Output | Expected Fact Method Output (e.g., `getColourEmotion`) | Rationale                                          |
| :-------------------------------- | :-------------------- | :------------------------------- | :------------------------------------------------------- | :------------------------------------------------- |
| **Null Input** | `null`                | -1                               | "Unknown emotion/stone/musical note"                     | Testing null input, explicitly handled             |
| **Empty String** | `""`                  | -1                               | "Unknown emotion/stone/musical note"                     | Empty string is not a valid color name             |
| **Exact Match (Case-sensitive)** | "violet"              | 0                                | "Bravery" (for emotion)                                  | Smallest index, exact match, correct case          |
|                                   | "red"                 | 6                                | "Confidence" (for emotion)                               | Largest index, exact match, correct case           |
| **Exact Match (Case-insensitive)**| "Violet"              | 0                                | "Bravery"                                                | Mixed case, should match due to `toLowerCase()`    |
|                                   | "BLUE"                | 1                                | "Calm"                                                   | All caps, should match                             |
|                                   | "rEd"                 | 6                                | "Confidence"                                             | Mixed case, should match                           |
| **Non-existent Color** | "black"               | -1                               | "Unknown emotion/stone/musical note"                     | A color not in the array                           |
|                                   | "pink"                | -1                               | "Unknown emotion/stone/musical note"                     | Another color not in the array                     |
| **Similar but Not Exact Match** | "viole"               | -1                               | "Unknown emotion/stone/musical note"                     | Substring of an existing color                     |
|                                   | "reds"                | -1                               | "Unknown emotion/stone/musical note"                     | Superstring of an existing color                   |
|                                   | "Green "              | -1                               | "Unknown emotion/stone/musical note"                     | Trailing space                                     |
|                                   | " blue"               | -1                               | "Unknown emotion/stone/musical note"                     | Leading space                                      |
| **String with numbers/symbols** | "red123"              | -1                               | "Unknown emotion/stone/musical note"                     | Invalid characters                                 |
| **Long String** | "aVeryLongColorNameThatDoesNotExist" | -1                               | "Unknown emotion/stone/musical note"                     | Very 
long string that is not a color               |

# White-Box Testing Approach

White-box testing is a software testing method that tests the internal structures or workings of an application, as opposed to its functionality. It involves examining the code paths, control flow, and data flow to ensure all statements and branches are executed and verified. This approach is beneficial for modules with significant internal logic, conditional statements, and loops, as it allows for thorough path coverage and identification of defects related to logic implementation.

For this exercise, the following two modules will be tested using a white-box testing approach:

1.  **`ColourFunFacts.java`**: This module is responsible for providing facts related to colors. Its `findColorIndex` method contains a `for` loop and `if` conditions, making it suitable for testing loop and conditional paths.
2.  **`EMSpectrumAnalyzer.java`**: This module analyzes electromagnetic spectrum properties and identifies visible colors based on wavelength. Its `getVisibleColor` method features extensive `if-else if-else` structures, which are excellent for covering various conditional paths.

### Test Design

Test cases are designed to cover different execution paths within the selected modules, specifically focusing on loop constructs and conditional (if-else) constructs, as learned in white-box testing. My student ID's last three digits (839) and my last name (Wickramaratne) have been incorporated into the test data.

#### Module 1: `ColourFunFacts.java`

**Tested Method:** `private int findColorIndex(String color)`
This method performs a case-insensitive linear search for a given color name within a predefined array. The key constructs here are the `if (lCaseColor == null)` check (though it's effectively unreachable if `color` itself is null, as `color.toLowerCase()` would throw a `NullPointerException` first), and the `for` loop with an `if` condition inside (`colorNames[i].equals(lCaseColor)`).

**How Test Cases are Decided:**
Test cases are designed to cover:
* The path where the color is found (loop terminates early).
* The path where the color is not found (loop completes all iterations).
* Edge cases for the loop, such as the first and last elements.
* Handling of different string inputs (case sensitivity, non-existent colors, special characters).

| Test Case Number | Path Type                               | Description                                                                                                                                                                                                                                                                                                                             | Test Data (Input Form - Data Type)      | Expected Output (Output Form) | Justification                                                                                                 |
| :--------------- | :-------------------------------------- | :-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | :-------------------------------------- | :---------------------------- | :------------------------------------------------------------------------------------------------------------ |
| 1                | Loop Execution (Color Found - First Element) | Test that the method correctly finds the index of the first color in the `colorNames` array.                                                                                                                                                                                                                                          | `"Violet"` (String - Parameter Passing) | `0` (Integer - Return Value)  | Ensures the loop correctly identifies and returns the index for the first element.                            |
| 2                | Loop Execution (Color Found - Last Element)  | Test that the method correctly finds the index of the last color in the `colorNames` array.                                                                                                                                                                                                                                           | `"Red"` (String - Parameter Passing)    | `6` (Integer - Return Value)  | Verifies correct handling when the match is found at the end of the array.                                    |
| 3                | Loop Execution (Color Not Found / Invalid Input) | Test that the method returns -1 when the color is not found in the array. This covers the path where the `for` loop completes without the `if` condition ever being true. Also includes testing with my last name as invalid input.                                                                                             | `"Wickramaratne"`, `"Black"`, `""` (String - Parameter Passing) | `-1` (Integer - Return Value) | Ensures the `return -1` statement after the loop is executed for non-existent colors.                       |
| 4                | Conditional Path (`if` condition - `index != -1` in `getColourEmotion`) | Test that `getColourEmotion` correctly retrieves the emotion when `findColorIndex` returns a valid index.                                                                                                                                                                                                           | `"Blue"` (String - Parameter Passing)   | `"Calm"` (String - Return Value) | Validates the flow when `findColorIndex` is successful and the corresponding emotion is returned.             |
| 5                | Conditional Path (`else` condition - `index == -1` in `getColourStone`) | Test that `getColourStone` returns "Unknown stone" when `findColorIndex` returns -1 (color not found).                                                                                                                                                                                                              | `"Purple"` (String - Parameter Passing) | `"Unknown stone"` (String - Return Value) | Validates the flow when `findColorIndex` fails to find the color, and the fallback "Unknown" message is returned. |

#### Module 2: `EMSpectrumAnalyzer.java`

**Tested Method:** `public String getVisibleColor(double wavelengthNm)`
This method determines the visible color based on a given wavelength, using a series of `if-else if-else` statements to check different wavelength ranges.

**How Test Cases are Decided:**
Test cases are designed to cover each distinct `if` and `else if` branch within the method, as well as the final `else` block. Boundary values (minimum and maximum for each range) are crucial for conditional constructs. My student ID's last three digits (839) are used to test a "Not Visible Light" wavelength.

| Test Case Number | Path Type                                  | Description                                                                                                                                                 | Test Data (Input Form - Data Type) | Expected Output (Output Form)     | Justification                                                                                                   |
| :--------------- | :----------------------------------------- | :---------------------------------------------------------------------------------------------------------------------------------------------------------- | :--------------------------------- | :-------------------------------- | :-------------------------------------------------------------------------------------------------------------- |
| 1                | Conditional Path (Not Visible Light - Below Minimum) | Test wavelengths below the `VISIBLE_LIGHT_MIN` boundary.                                                                                                    | `379.9`, `0.0` (Double - Parameter Passing) | `"Not Visible Light"` (String - Return Value) | Ensures the initial `if (wavelengthNm < VISIBLE_LIGHT_MIN || wavelengthNm > VISIBLE_LIGHT_MAX)` condition correctly captures values below the visible spectrum. |
| 2                | Conditional Path (Not Visible Light - Above Maximum) | Test wavelengths above the `VISIBLE_LIGHT_MAX` boundary. Includes student ID's last three digits.                                                           | `750.1`, `1000.0`, `839.0` (Double - Parameter Passing) | `"Not Visible Light"` (String - Return Value) | Ensures the initial `if` condition correctly captures values above the visible spectrum.                            |
| 3                | Conditional Path (Violet)                  | Test wavelengths within the Violet range.                                                                                                                   | `380.0`, `449.9` (Double - Parameter Passing) | `"Violet"` (String - Return Value)        | Covers the first `else if` block.                                                                               |
| 4                | Conditional Path (Blue)                    | Test wavelengths within the Blue range.                                                                                                                     | `450.0`, `484.9` (Double - Parameter Passing) | `"Blue"` (String - Return Value)          | Covers the second `else if` block.                                                                              |
| 5                | Conditional Path (Cyan)                    | Test wavelengths within the Cyan range.                                                                                                                     | `485.0`, `499.9` (Double - Parameter Passing) | `"Cyan"` (String - Return Value)          | Covers the third `else if` block.                                                                               |
| 6                | Conditional Path (Green)                   | Test wavelengths within the Green range.                                                                                                                    | `500.0`, `569.9` (Double - Parameter Passing) | `"Green"` (String - Return Value)         | Covers the fourth `else if` block.                                                                              |
| 7                | Conditional Path (Yellow)                  | Test wavelengths within the Yellow range.                                                                                                                   | `570.0`, `589.9` (Double - Parameter Passing) | `"Yellow"` (String - Return Value)        | Covers the fifth `else if` block.                                                                               |
| 8                | Conditional Path (Orange)                  | Test wavelengths within the Orange range.                                                                                                                   | `590.0`, `619.9` (Double - Parameter Passing) | `"Orange"` (String - Return Value)        | Covers the sixth `else if` block.                                                                               |
| 9                | Conditional Path (Red)                     | Test wavelengths within the Red range. This covers the final `else` block for valid visible light inputs not covered by previous `if-else if` conditions. | `620.0`, `750.0` (Double - Parameter Passing) | `"Red"` (String - Return Value)           | Ensures the final `else` block (for Red) is correctly handled.                                                  |

### Traceability table (Summary of test design and test code)

| Code File | Method Name | Design of test cases | Test code and implementation |
| :---------- | :---------- | :----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | :---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `InputHandler.java` | `readDouble` | EP: done <br> BVA: not done <br> WB: done <br> Input/Output: Input is `String` (prompt parameter), `double` (user input via console); Output is `double` (return value). | EP: done <br> BVA: not done <br> WB: done |
| | `readString` | EP: done <br> BVA: not done <br> WB:  done <br> Input/Output: Input is `String` (prompt parameter), `String` (user input via console); Output is `String` (return value). | EP: done <br> BVA: not done <br> WB:  done |
| | `readInt` | EP: done <br> BVA:not done <br> WB: done <br> Input/Output: Input is `String` (prompt parameter), `int` (user input via console); Output is `int` (return value). | EP: done <br> BVA: not done <br> WB: done |
| `OutputHandler.java`| `printMessage` | EP:  done <br> BVA: not done <br> WB:  done <br> Input/Output: Input is `String` (message parameter); Output is `void` (prints to console). | EP: done <br> BVA: not done <br> WB:  done |
| | `printFormattedMessage`| EP:  done <br> BVA: not done <br> WB:  done <br> Input/Output: Input is `String` (format parameter), `Object...` (arguments parameter); Output is `void` (prints formatted output to console).  | EP:  done <br> BVA: not done <br> WB: done |
| | `printNewLine` | EP:  done <br> BVA: not done <br> WB: done <br> Input/Output: Input is `void`; Output is `void` (prints a newline to console).  | EP:  done <br> BVA: not done <br> WB:  done |
| `EMSpectrumAnalyzer.java`| `freqToWaveLength` | EP: done <br> BVA: done <br> WB: done <br> Input/Output: Input is `double` (frequency parameter); Output is `double` (return value). | EP: done <br> BVA: done <br> WB: done |
| | `getEmSpectrumRange` | EP: done <br> BVA: done <br> WB: done <br> Input/Output: Input is `double` (wavelength parameter); Output is `String` (return value). | EP: done <br> BVA: done <br> WB: done |
| | `getVisibleColor` | EP: done <br> BVA: done <br> WB: done <br> Input/Output: Input is `double` (wavelength parameter); Output is `String` (return value). | EP: done <br> BVA: done <br> WB: done |
| | `compareFrequencies` | EP: done <br> BVA: done <br> WB: done <br> Input/Output: Input is `double` (frequency1 parameter), `double` (frequency2 parameter); Output is `String` (return value). | EP: done <br> BVA: done <br> WB: done |
| `ColourFunFacts.java`| `findColorIndex` | EP: done <br> BVA: done <br> WB: done <br> Input/Output: Input is `String` (color parameter); Output is `int` (return value). | EP: done <br> BVA: done <br> WB: done |
| | `getColourEmotion` | EP: done <br> BVA: done <br> WB: done <br> Input/Output: Input is `String` (color parameter); Output is `String` (return value). | EP: done <br> BVA: done <br> WB: done |
| | `getColourStone` | EP: done <br> BVA: done <br> WB: done <br> Input/Output: Input is `String` (color parameter); Output is `String` (return value). | EP: done <br> BVA: done <br> WB: done |
| | `getColourMusicalNote`| EP: done <br> BVA: done <br> WB: done <br> Input/Output: Input is `String` (color parameter); Output is `String` (return value). | EP: done <br> BVA: done <br> WB: done |
| `Main.java` | `main` | EP: not done <br> BVA: not done <br> WB: not done <br> Input/Output: Input is `String[]` (command-line arguments); Orchestrates user input/output via other handlers, no direct return value. This method is typically verified through integration testing of the entire application rather than isolated unit testing. | EP: done <br> BVA: not done <br> WB:  done |



# In order to run the test code files:

 **Compile All Necessary Files:** You need to compile both your main application classes (e.g., `Main.java`, `EMSpectrumAnalyzer.java`, `ColourFunFacts.java`, `InputHandler.java`, `OutputHandler.java`) and their corresponding test files. It's often convenient to compile all Java files in the current directory at once.

    
    javac *.java
    
    This command will generate `.class` files for all your Java source files. If you encounter compilation errors, resolve them before proceeding.

5.  **Run the Test File:** Once all files are compiled, you can run each test file individually using the `java` command. 


## Running Individual Test Files

Here are the specific commands for each test file you provided:

### 1. `ColourFunFactsTest.java`

* **Description:** This test file verifies the functionality of the `ColourFunFacts` class, checking methods related to color emotions, associated stones, and musical notes.
* **Command to Run:**
    
    java ColourFunFactsTest
    

### 2. `EMSpectrumAnalyzerTest.java`

* **Description:** This test file evaluates the `EMSpectrumAnalyzer` class, including methods for wavelength/frequency conversions, visible color identification from spectrum, and determining the broader spectrum range.
* **Command to Run:**
    
    java EMSpectrumAnalyzerTest
    

### 3. `InputHandlerTest.java`

* **Description:** This test file checks the `InputHandler` class's ability to correctly read various types of input (integers, doubles, strings), including how it handles invalid input scenarios.
* **Command to Run:**

    java InputHandlerTest
    

### 4. `MainTest.java`

* **Description:** This test file assesses the overall integration and interaction flow of the `Main` class, testing scenarios like program exit, invalid menu choices, and the two main application functionalities (EM Spectrum Analysis and Colour Facts).
* **Command to Run:**
    
    java MainTest
    

### 5. `OutputHandlerTest.java`

* **Description:** This test file ensures the `OutputHandler` class correctly handles printing messages and new lines to the console, verifying its output capabilities.
* **Command to Run:**
    
    java OutputHandlerTest
    

# Test Failures

![Alt text for the image](EMSAT_Fail1.png)
### Analysis and Fix for `EMSpectrumAnalyzerTest` Failure

When testing the `EMSpectrumAnalyzer`'s `getColourFromFrequency` method, a specific mismatch was identified:

* **Problem:** The test expected `580.0 THz` to be classified as `"Yellow"`. However, the `EMSpectrumAnalyzer`'s `getColourFromFrequency` method correctly classified it as `"Green"` based on the established frequency ranges. This was a mismatch between the test's expectation and the `EMSpectrumAnalyzer`'s accurate logic for visible light frequencies.

    According to the standard electromagnetic spectrum ranges (and the logic implemented in `EMSpectrumAnalyzer.java`):
    * **Yellow** typically falls around `508.5 - 526.39 THz`.
    * **Green** typically falls around `526.4 - 599.99 THz`.

    Since `580.0 THz` falls within the **green** frequency range, the code's output (`"Green"`) was correct, and the test's expected value (`"Yellow"`) was incorrect.

* **Fix:** I updated the expected string in the `testCompareFrequencies_OneVisibleOneNot_Above` method within `EMSpectrumAnalyzerTest.java` to reflect the correct color `"Green"` for `580.0 THz`. This ensures the test now correctly validates the `EMSpectrumAnalyzer`'s logic.


![Alt text for the image](Main_fail.png)
### Analysis and Fix for `MainTest` Failures

* **Problem:** Failures in `MainTest.java` indicated that the output captured during test execution did not exactly match the expected strings. This typically occurs due to subtle differences in whitespace, newlines, or the exact phrasing of messages printed by the `Main` class. The tests were particularly sensitive to the presence of the "Scenario A menu" and the final conversion/range output.

* **Fix:** I reviewed the precise output strings generated by `Main.java` and adjusted the `assertTrue(actualOutput.contains(...))` checks in `MainTest.java`. This ensures the tests now accurately match the expected text, verifying all parts of the initial main menu, the "Scenario A" sub-menu, and the specific results for wavelength-to-frequency conversion and EM spectrum range identification. The checks are now more robust to ensure the exact prompts and output messages are found in the captured stream.

# Test Successes for each production code file

## EMSpectrumAnalyzerTest success
![Alt text for the image](EMSA1.png)

## ColourFnFactsTest success
![Alt text for the image](CFF.png)

## InputHandlerTest success
![Alt text for the image](Input.png)

## OutputHandlerTest success
![Alt text for the image](Output.png)

## MainTest success
![Alt text for the image](Main.png)

# Version Controlling

![Alt text for the image](git1.png)
![Alt text for the image](git2.png)
![Alt text for the image](git3.png)
![Alt text for the image](git4.png)
![Alt text for the image](git5.png)

# Summary

I implemented the classes for each quota of functionality i.e. EMSpectrumAnalyzer,ColourFunFacts,InputHandler,OutputHandler and Main and their respective test cases and test code.The test code was particularly challenging becuase i had to account for all the errors that may occur and at times the test code i impplemented failed and then i had to again fix them after thinking of better ways to go about them.There was also the contraint of time specially with the heavy workload this assignment entails so in order to do it properly i had to dedicate a larget portion of my time.But overall the necessary functionalities were done so i am satisfied with the outcome.It wouldve been better if i had more time to plan the project out more but i still delivered what was asked.

Thank you.