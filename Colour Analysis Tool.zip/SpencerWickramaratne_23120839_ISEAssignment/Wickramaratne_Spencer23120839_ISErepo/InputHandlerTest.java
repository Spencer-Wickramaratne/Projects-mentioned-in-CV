import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.Objects; // For Objects.equals() and Objects.deepEquals()

public class InputHandlerTest {

    private static final InputStream originalSystemIn = System.in;
    private static final PrintStream originalSystemOut = System.out;
    private static ByteArrayOutputStream outputStreamCaptor;
    private static int testsRun = 0;
    private static int testsFailed = 0;

    // --- Helper methods for setting up and tearing down test environment ---

    private static void setUp() {
        outputStreamCaptor = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStreamCaptor));
    }

    private static void tearDown() {
        System.setIn(originalSystemIn);
        System.setOut(originalSystemOut);
        outputStreamCaptor = null; // Clear the captor
    }

    private static void setSimulatedInput(String input) {
        System.setIn(new ByteArrayInputStream(input.getBytes()));
    }

    private static String getCapturedOutput() {
        return outputStreamCaptor.toString();
    }

    // --- Simple Assertion Methods ---

    private static void assertEquals(Object expected, Object actual, String testName) {
        testsRun++;
        if (Objects.equals(expected, actual)) {
            System.out.println("PASS: " + testName);
        } else {
            testsFailed++;
            System.err.println("FAIL: " + testName + " - Expected: '" + expected + "', Actual: '" + actual + "'");
        }
    }

    private static void assertTrue(boolean condition, String testName, String failureMessage) {
        testsRun++;
        if (condition) {
            System.out.println("PASS: " + testName);
        } else {
            testsFailed++;
            System.err.println("FAIL: " + testName + " - " + failureMessage);
        }
    }

    // --- Test Methods for InputHandler ---

    public static void testReadInt_ValidInput() {
        setUp();
        try {
            setSimulatedInput("123\n");
            InputHandler inputHandler = new InputHandler();
            int result = inputHandler.readInt("Enter a number: ");
            assertEquals(123, result, "testReadInt_ValidInput Value");
            assertTrue(getCapturedOutput().contains("Enter a number: "), "testReadInt_ValidInput Prompt", "Prompt not found.");
        } finally {
            tearDown();
        }
    }

    public static void testReadInt_InvalidThenValidInput() {
        setUp();
        try {
            setSimulatedInput("abc\n456\n");
            InputHandler inputHandler = new InputHandler();
            int result = inputHandler.readInt("Enter an integer: ");
            assertEquals(456, result, "testReadInt_InvalidThenValidInput Value");
            String consoleOutput = getCapturedOutput();
            assertTrue(consoleOutput.contains("Enter an integer: "), "testReadInt_InvalidThenValidInput Prompt", "Prompt not found.");
            assertTrue(consoleOutput.contains("Invalid input. Please enter an integer."), "testReadInt_InvalidThenValidInput Error Message", "Error message not found.");
        } finally {
            tearDown();
        }
    }

    public static void testReadDouble_ValidInput() {
        setUp();
        try {
            setSimulatedInput("12.34\n");
            InputHandler inputHandler = new InputHandler();
            double result = inputHandler.readDouble("Enter a double: ");
            assertEquals(12.34, result, "testReadDouble_ValidInput Value"); // Note: Double comparison needs tolerance for real tests, but for simple equality check, this works
            assertTrue(getCapturedOutput().contains("Enter a double: "), "testReadDouble_ValidInput Prompt", "Prompt not found.");
        } finally {
            tearDown();
        }
    }

    public static void testReadDouble_InvalidThenValidInput() {
        setUp();
        try {
            setSimulatedInput("hello\n78.90\n");
            InputHandler inputHandler = new InputHandler();
            double result = inputHandler.readDouble("Enter a number: ");
            assertEquals(78.90, result, "testReadDouble_InvalidThenValidInput Value");
            String consoleOutput = getCapturedOutput();
            assertTrue(consoleOutput.contains("Enter a number: "), "testReadDouble_InvalidThenValidInput Prompt", "Prompt not found.");
            assertTrue(consoleOutput.contains("Invalid input. Please enter a number."), "testReadDouble_InvalidThenValidInput Error Message", "Error message not found.");
        } finally {
            tearDown();
        }
    }

    public static void testReadString_ValidInput() {
        setUp();
        try {
            setSimulatedInput("Test String\n");
            InputHandler inputHandler = new InputHandler();
            String result = inputHandler.readString("Enter text: ");
            assertEquals("Test String", result, "testReadString_ValidInput Value");
            assertTrue(getCapturedOutput().contains("Enter text: "), "testReadString_ValidInput Prompt", "Prompt not found.");
        } finally {
            tearDown();
        }
    }

    public static void testReadString_AfterReadInt() {
        setUp();
        try {
            String simulatedIntInput = "10\n";
            String simulatedStringInput = "Another String\n";
            setSimulatedInput(simulatedIntInput + simulatedStringInput);
            InputHandler inputHandler = new InputHandler();
            
            // First, read an integer
            inputHandler.readInt("Enter an int: ");
            
            // Then, read a string
            String result = inputHandler.readString("Enter a string: ");
            assertEquals("Another String", result, "testReadString_AfterReadInt Value");
            String consoleOutput = getCapturedOutput();
            assertTrue(consoleOutput.contains("Enter an int: "), "testReadString_AfterReadInt Int Prompt", "Int prompt not found.");
            assertTrue(consoleOutput.contains("Enter a string: "), "testReadString_AfterReadInt String Prompt", "String prompt not found.");
        } finally {
            tearDown();
        }
    }

    public static void testReadString_AfterReadDouble() {
        setUp();
        try {
            String simulatedDoubleInput = "5.5\n";
            String simulatedStringInput = "Final String\n";
            setSimulatedInput(simulatedDoubleInput + simulatedStringInput);
            InputHandler inputHandler = new InputHandler();

            // First, read a double
            inputHandler.readDouble("Enter a double: ");

            // Then, read a string
            String result = inputHandler.readString("Enter a string: ");
            assertEquals("Final String", result, "testReadString_AfterReadDouble Value");
            String consoleOutput = getCapturedOutput();
            assertTrue(consoleOutput.contains("Enter a double: "), "testReadString_AfterReadDouble Double Prompt", "Double prompt not found.");
            assertTrue(consoleOutput.contains("Enter a string: "), "testReadString_AfterReadDouble String Prompt", "String prompt not found.");
        } finally {
            tearDown();
        }
    }

    // --- Main method to run all tests ---

    public static void main(String[] args) {
        System.out.println("--- Running InputHandler Simple Tests ---");

        testReadInt_ValidInput();
        testReadInt_InvalidThenValidInput();
        testReadDouble_ValidInput();
        testReadDouble_InvalidThenValidInput();
        testReadString_ValidInput();
        testReadString_AfterReadInt();
        testReadString_AfterReadDouble();

        System.out.println("\n--- Test Summary ---");
        System.out.println("Tests Run: " + testsRun);
        System.out.println("Tests Failed: " + testsFailed);

        if (testsFailed == 0) {
            System.out.println("All tests passed!");
        } else {
            System.out.println("Some tests failed. Please review the output above.");
        }
    }
}