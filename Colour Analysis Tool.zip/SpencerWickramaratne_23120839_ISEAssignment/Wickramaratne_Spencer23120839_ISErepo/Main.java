/**
 * The main class and entry point for the Software Engineering Assignment program.
 * Orchestrates interactions between InputHandler, OutputHandler,
 * EMSpectrumAnalyzer, and ColourFunFacts.
 */
public class Main {

    public static void main(String[] args) {
        InputHandler inputHandler = new InputHandler();
        OutputHandler outputHandler = new OutputHandler();
        EMSpectrumAnalyzer spectrumAnalyzer = new EMSpectrumAnalyzer();
        ColourFunFacts colourFact = new ColourFunFacts();

        // Display program title and menu
        outputHandler.printMessage("Software Engineering Assignment ");
        outputHandler.printNewLine(); // Print a blank line (using OutputHandler method)

        int choice = -1; // Variable to store the user's menu choice

        // Use a while loop to keep the program running until the user chooses to exit
        while (choice != 3) {
            outputHandler.printMessage("Select an option:");
            outputHandler.printMessage("1. Analyze EM Spectrum (Scenario A)");
            outputHandler.printMessage("2. Get Colour Facts (Scenario B)");
            outputHandler.printMessage("3. Exit");
            outputHandler.printMessage("Enter your choice: ");

            // Get user input for the menu choice using InputHandler's readInt method
            choice = inputHandler.readInt(""); // readInt handles invalid integer input within InputHandler


            switch (choice) {
                case 1: // Analyze EM Spectrum (Scenario A)
                    outputHandler.printMessage("Select analysis type:");
                    outputHandler.printMessage("a. Convert Wavelength to Frequency");
                    outputHandler.printMessage("b. Convert Frequency to Wavelength");
                    outputHandler.printMessage("c. Get EM Spectrum Range");
                    outputHandler.printMessage("d. Compare Two Frequencies");
                    outputHandler.printMessage("e. Check if Wavelength is Visible");
                    outputHandler.printMessage("f. Get Visible Color from Wavelength");
                    outputHandler.printMessage("g. Check if Frequency is Visible");
                    outputHandler.printMessage("h. Get Color from Frequency");
                    outputHandler.printMessage("i. Get Frequency Range for a Color");
                    outputHandler.printMessage("Enter your choice (a-i): ");

                    String analysisChoice = inputHandler.readString("").toLowerCase();

                    switch (analysisChoice) {
                        case "a":
                            double wavelengthInput = inputHandler.readDouble("Enter wavelength (in nm): ");
                            double convertedFrequency = spectrumAnalyzer.convertWavelengthToFrequency(wavelengthInput); // Corrected method call
                            outputHandler.printMessage("Converted Frequency: " + convertedFrequency + " THz");
                            break;
                        case "b":
                            double frequencyInput = inputHandler.readDouble("Enter frequency (in THz): ");
                            double convertedWavelength = spectrumAnalyzer.convertFrequencyToWavelength(frequencyInput); // Corrected method call
                            outputHandler.printMessage("Converted Wavelength: " + convertedWavelength + " nm");
                            break;
                        case "c":
                            outputHandler.printMessage("Enter value (wavelength in nm, frequency in THz): ");
                            double value = inputHandler.readDouble("");
                            outputHandler.printMessage("Enter type (wavelength/frequency): ");
                            String type = inputHandler.readString("");
                            String range = spectrumAnalyzer.getEMSpectrumRange(value, type);
                            outputHandler.printMessage("EM Spectrum Range: " + range);
                            break;
                        case "d":
                            double freq1 = inputHandler.readDouble("Enter first frequency (in THz): ");
                            double freq2 = inputHandler.readDouble("Enter second frequency (in THz): ");
                            String comparisonResult = spectrumAnalyzer.compareFrequencies(freq1, freq2);
                            outputHandler.printMessage(comparisonResult);
                            break;
                        case "e": // New case for isWavelengthVisible
                            double checkWavelength = inputHandler.readDouble("Enter wavelength to check visibility (in nm): ");
                            boolean isVisibleW = spectrumAnalyzer.isWavelengthVisible(checkWavelength);
                            outputHandler.printMessage("Is wavelength visible? " + (isVisibleW ? "Yes" : "No"));
                            break;
                        case "f": // New case for getVisibleColor
                            double colorWavelength = inputHandler.readDouble("Enter wavelength to get color (in nm): ");
                            String colorNameW = spectrumAnalyzer.getVisibleColor(colorWavelength);
                            outputHandler.printMessage("Color for " + colorWavelength + " nm: " + colorNameW);
                            break;
                        case "g": // New case for isFrequencyVisible
                            double checkFrequency = inputHandler.readDouble("Enter frequency to check visibility (in THz): ");
                            boolean isVisibleF = spectrumAnalyzer.isFrequencyVisible(checkFrequency);
                            outputHandler.printMessage("Is frequency visible? " + (isVisibleF ? "Yes" : "No"));
                            break;
                        case "h": // New case for getColourFromFrequency
                            double colorFrequency = inputHandler.readDouble("Enter frequency to get color (in THz): ");
                            String colorNameF = spectrumAnalyzer.getColourFromFrequency(colorFrequency);
                            outputHandler.printMessage("Color for " + colorFrequency + " THz: " + colorNameF);
                            break;
                        case "i": // New case for getFrequencyRangeForColor
                            String colorForRange = inputHandler.readString("Enter color name to get frequency range: ");
                            double[] freqRange = spectrumAnalyzer.getFrequencyRangeForColor(colorForRange);
                            if (freqRange != null) {
                                outputHandler.printMessage("Frequency range for " + colorForRange + ": " + freqRange[0] + " THz - " + freqRange[1] + " THz");
                            } else {
                                outputHandler.printMessage("Color not recognized or no frequency range available.");
                            }
                            break;
                        default:
                            outputHandler.printMessage("Invalid analysis choice. Please try again.");
                    }
                    outputHandler.printNewLine(); // Print a blank line
                    break;

                case 2: // User selected Scenario B
                    outputHandler.printNewLine();
                    // Get color name input from the user using InputHandler's readString
                    String color = inputHandler.readString("Enter a color name (e.g., Red, Blue): ");

                    // Call methods from the ColourFunFacts
                    String emotion = colourFact.getColourEmotion(color); // Get color emotion
                    String stone = colourFact.getColourStone(color); // Get color stone
                    String musicalNote = colourFact.getColourMusicalNote(color); // Get color musical note

                    // Display results using OutputHandler
                    outputHandler.printMessage("Facts for " + color + ":");
                    outputHandler.printMessage("  Emotion: " + emotion);
                    outputHandler.printMessage("  Associated Stone: " + stone);
                    outputHandler.printMessage("  Associated Musical Note: " + musicalNote);
                    outputHandler.printNewLine(); // Print a blank line
                    break;

                case 3:
                    outputHandler.printMessage("Exiting program.");
                    break;

                default:
                    outputHandler.printMessage("Invalid choice. Please try again.");
                    outputHandler.printNewLine();
            }
        }
    }
}