
/**
 * Handles program output to the console using standard output streams.
 * Provides methods for printing messages and formatted output.
 */
public class OutputHandler {

    /**
     * Prints a message,followed by a newline.
     */
    public void printMessage(String message) {
        System.out.println(message); 
    }

    /**
     * Prints a formatted message to the standard output stream (console).
     */
    public void printFormattedMessage(String format, Object... args) {
        System.out.printf(format, args); // Using formatted output
    }

    /**
     * Prints a blank line \ for visual separation.
     */
    public void printNewLine() {
        System.out.println(); // Printing an empty line
    }
}