import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * Handles user input from the console or other input streams using Scanner.
 */
public class InputHandler {

    private Scanner scanner;

    /**
     * Constructs an InputHandler to read from the standard input stream (console).
     */
    public InputHandler() {
        scanner = new Scanner(System.in);
    }

    /**
     * Reads a double value from the input stream after prompting the user.
     * Implements input validation using a while loop and try-catch block
     */
    public double readDouble(String prompt) {
        while (true) { // Loop until valid input is received
            System.out.print(prompt); // Output prompt
            try { // Try block for potential exceptions
                double value = scanner.nextDouble();
                scanner.nextLine(); // IMPORTANT: Consume the leftover newline character after reading the double
                return value;
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.nextLine(); // Consume the entire invalid input line
            }
        }
    }

    /**
     * Reads a string value from the input stream after prompting the user.
     */
    public String readString(String prompt) {
        System.out.print(prompt);
        // IMPORTANT: With readInt/readDouble now correctly consuming newlines,
        // this method can be simplified to just read the next full line.
        // The previous conditional nextLine() was problematic for direct string reads.
        return scanner.nextLine();
    }

    /**
     * Reads an integer value from the input stream after prompting the user.
     * Implements input validation using a while loop and try-catch block.
     */
    public int readInt(String prompt) {
         while (true) { // Loop until valid input
            System.out.print(prompt);
            try { // Try block for potential exceptions
                int value = scanner.nextInt();
                scanner.nextLine(); // IMPORTANT: Consume the leftover newline character after reading the integer
                return value;
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter an integer.");
                scanner.nextLine(); // Consume the entire invalid input line
            }
        }
    }
}